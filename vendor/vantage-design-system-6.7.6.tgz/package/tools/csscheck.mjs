/**
 * Parse every stylesheet in the system with postcss.
 *
 * Catches the class of breakage that has actually happened here: an unterminated
 * block comment swallowing the declarations after it, so a whole theme silently
 * stops being defined. The browser reports nothing — it just drops what it
 * cannot parse.
 *
 *   node csscheck.mjs
 *
 * Paths resolve against THIS FILE, not the shell's cwd, so it works from
 * anywhere — including the handoff bundle, where the layout differs.
 */
import postcss from "postcss";
import { readFileSync, existsSync } from "node:fs";
import { dirname, join, isAbsolute } from "node:path";
import { fileURLToPath } from "node:url";

const HERE = dirname(fileURLToPath(import.meta.url));

const files = [
  "../tokens/colors_and_type.css",
  "../tokens/tokens.css",
  "../tokens/shadcn.css",
  "../src/styles/kit.css",
];

let bad = 0;
for (const f of files) {
  const p = isAbsolute(f) ? f : join(HERE, f);
  if (!existsSync(p)) {
    bad++;
    console.log("  ✗", f, "— file not found");
    continue;
  }
  try {
    postcss.parse(readFileSync(p, "utf8"), { from: p });
    console.log("  ✓", f);
  } catch (e) {
    bad++;
    const where = e.line != null ? ` at line ${e.line}` : "";
    console.log("  ✗", f, "—", e.reason ?? e.message ?? e, where);
  }
}
console.log(bad ? `\n  ${bad} of ${files.length} failed` : `\n  all ${files.length} parse clean`);
process.exit(bad ? 1 : 0);
