/**
 * Fail the build on a Tailwind utility that compiles to NOTHING.
 *
 * WHY THIS EXISTS. Tailwind drops a class it cannot resolve in silence — no
 * rule, no warning, no error. The element simply has no background, and the
 * gap only shows up if someone happens to look at that state in that theme.
 * Seventeen tint usages across seven components shipped unstyled that way:
 * `bg-teal/10` on a hex token had no alpha slot to fill, so it emitted nothing.
 * `hexToken` in tailwind.config.ts fixed that class of failure; this script
 * makes the NEXT one loud, whatever its cause — a typo, a renamed token, a
 * scale that never got added to the config.
 *
 * Run it AFTER building demo/demo.css, which is the sheet the whole kit and
 * every demo page compile into. Any at-risk utility appearing in src/ or demo/
 * but not in that sheet is reported with its call sites.
 */
import { readFileSync, readdirSync, statSync, existsSync } from "fs";
import { join, extname, dirname, resolve } from "path";
import { fileURLToPath } from "url";

const KIT = resolve(dirname(fileURLToPath(import.meta.url)), "..");  // bundle root, not tools/
const SHEET = join(KIT, "demo/demo.css");

if (!existsSync(SHEET)) {
  console.error("✗ demo/demo.css not found — run `npm run build:demo:css` first.");
  process.exit(1);
}

/**
 * Every class selector in the compiled sheet.
 *
 * The escape alternative MUST be tried before the negated character class.
 * A negated class that still permits `\` consumes it greedily, so
 * `.hover\:bg-surface-hover` is captured as `hover` and every variant utility
 * in the kit reads as missing. That produced 33 phantom findings on the first
 * run of this script.
 */
const css = readFileSync(SHEET, "utf8");
const present = new Set();
for (const m of css.matchAll(/\.((?:\\.|[^\s{};:,>+~()[\]"'\\])+)/g)) {
  present.add(m[1].replace(/\\/g, ""));
}

/**
 * Blank out comments, preserving line numbers.
 *
 * This codebase documents its own past bugs by quoting the broken class in a
 * comment — `bg-[var(--gsc-blue)]/80`, `bg-teal/5`, `bg-teal-hover`. Scanning
 * comment text turns every one of those cautionary notes into a fresh finding,
 * and a guard that cries wolf is a guard people learn to skip. Only real code
 * is scanned.
 */
function stripComments(src) {
  let out = "";
  let state = "code"; // code | line | block | sq | dq | tpl
  for (let i = 0; i < src.length; ) {
    const c = src[i];
    const d = src[i + 1];
    if (state === "code") {
      if (c === "/" && d === "/") { state = "line"; out += "  "; i += 2; continue; }
      if (c === "/" && d === "*") { state = "block"; out += "  "; i += 2; continue; }
      if (c === "'") state = "sq";
      else if (c === '"') state = "dq";
      else if (c === "`") state = "tpl";
      out += c; i++; continue;
    }
    if (state === "line") {
      if (c === "\n") { state = "code"; out += c; } else out += " ";
      i++; continue;
    }
    if (state === "block") {
      if (c === "*" && d === "/") { state = "code"; out += "  "; i += 2; continue; }
      out += c === "\n" ? "\n" : " ";
      i++; continue;
    }
    // inside a string literal
    if (c === "\\") { out += c + (d ?? ""); i += 2; continue; }
    if ((state === "sq" && c === "'") || (state === "dq" && c === '"') || (state === "tpl" && c === "`")) {
      state = "code";
    }
    out += c; i++;
  }
  return out;
}

const walk = (dir, out = []) => {
  for (const e of readdirSync(dir)) {
    if (e === "node_modules") continue;
    const p = join(dir, e);
    if (statSync(p).isDirectory()) walk(p, out);
    else if ([".ts", ".tsx"].includes(extname(p))) out.push(p);
  }
  return out;
};

/** Utility families that read from the colors/shadow maps — the ones that can silently miss. */
const AT_RISK =
  /^(bg|text|border|border-[trblxy]|ring|ring-offset|fill|stroke|from|via|to|outline|decoration|divide|accent|caret|placeholder|shadow)-/;

const findings = new Map();
for (const file of [...walk(join(KIT, "src")), ...walk(join(KIT, "demo"))]) {
  stripComments(readFileSync(file, "utf8")).split("\n").forEach((line, i) => {
    for (const lit of line.matchAll(/["'`]([^"'`\n]*)["'`]/g)) {
      for (const raw of lit[1].split(/\s+/)) {
        if (!raw) continue;
        // Arbitrary values legitimately contain parens (`bg-[var(--bg-dark-active)]`,
        // `w-[calc(100%-1px)]`), so blank bracketed segments before the junk test.
        // Testing `raw` directly skipped EVERY arbitrary utility in the kit —
        // including the one hiding a genuinely invisible GSC status dot.
        if (/[${}<>()*]/.test(raw.replace(/\[[^\]]*\]/g, "[]"))) continue;
        // Strip variants (`hover:`, `data-[open]:`, `md:`) to test the base family.
        if (!AT_RISK.test(raw.replace(/^(?:[a-z-]+(?:\[[^\]]*\])?:)+/, ""))) continue;
        if (present.has(raw)) continue;
        if (!findings.has(raw)) findings.set(raw, new Set());
        findings.get(raw).add(`${file.replace(KIT + "/", "")}:${i + 1}`);
      }
    }
  });
}

if (!findings.size) {
  console.log("  ✓ deadclass — every color/shadow utility in src/ and demo/ resolves to a rule.");
  process.exit(0);
}

console.log(`  ✗ deadclass — ${findings.size} utility(ies) used in source but absent from demo.css:\n`);
for (const [cls, where] of [...findings].sort()) {
  console.log(`      ${cls}`);
  for (const w of where) console.log(`          ${w}`);
}
console.log("\n  These render as nothing. Fix the token/config or remove the class.");
process.exit(1);
