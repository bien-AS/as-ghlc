#!/usr/bin/env node
/**
 * Static server for the Vantage design system.
 *
 * Serves this folder so both surfaces work off one origin:
 *   /                  landing page
 *   /preview/          the 5-page brand board (tokens, colour, type, components, motion)
 *   /kit/demo/         the live React component kit, both themes
 *
 * No-cache headers throughout: the preview pages and the kit demo are rebuilt
 * constantly while the system is being worked on, and a cached stylesheet here
 * costs more debugging time than it ever saves in load time.
 */
import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { extname, join, normalize, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = resolve(fileURLToPath(new URL("..", import.meta.url)));  // bundle root, not tools/
const PORT = Number(process.env.PORT ?? 4321);

const TYPES = {
  ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8", ".svg": "image/svg+xml",
  ".png": "image/png", ".jpg": "image/jpeg", ".webp": "image/webp",
  ".woff2": "font/woff2", ".md": "text/plain; charset=utf-8",
};

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://localhost:${PORT}`);
    // normalize() + the prefix check keeps `../` out of the served tree
    let path = join(ROOT, normalize(decodeURIComponent(url.pathname)));
    if (!path.startsWith(ROOT)) {
      res.writeHead(403).end("Forbidden");
      return;
    }
    let info = await stat(path).catch(() => null);
    if (info?.isDirectory()) {
      path = join(path, "index.html");
      info = await stat(path).catch(() => null);
    }
    if (!info) {
      res.writeHead(404, { "content-type": "text/html; charset=utf-8" })
         .end(`<pre style="font:14px ui-monospace;padding:24px">404 ${url.pathname}\n\nTry <a href="/">/</a></pre>`);
      return;
    }
    res.writeHead(200, {
      "content-type": TYPES[extname(path)] ?? "application/octet-stream",
      "cache-control": "no-store, must-revalidate",
    });
    res.end(await readFile(path));
  } catch (err) {
    res.writeHead(500).end(String(err));
  }
});

// Fall forward to the next free port instead of dying. Two things made this
// worth handling: an EADDRINUSE here is an unhandled 'error' event, so the
// whole output is a Node stack trace with no hint of the cause — and the
// quieter failure is worse. Another copy of this system on the same port
// serves a DIFFERENT tree at the same URL, so someone who skips the console
// and just opens :4321 sees the wrong system and has no way to tell.
const MAX_PORT_TRIES = 12;
function listen(port, attempt = 0) {
  server.once("error", (err) => {
    if (err.code !== "EADDRINUSE" || attempt >= MAX_PORT_TRIES) {
      console.error(`\n  Cannot serve on port ${port}: ${err.message}\n`);
      process.exit(1);
    }
    console.log(`  port ${port} is busy (something else is already serving there) — trying ${port + 1}`);
    listen(port + 1, attempt + 1);
  });
  server.listen(port);
}

function announce(port) {
  console.log(`\n  Vantage design system\n  http://localhost:${port}\n`);
  console.log(`  /            landing`);
  console.log(`  /preview/    brand board`);
  console.log(`  /kit/demo/   component kit (dark-first)\n`);
}

server.on("listening", () => announce(server.address().port));
listen(PORT);
