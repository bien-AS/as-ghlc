/**
 * @vantage/kit — Authority Solutions Vantage design system.
 *
 * DARK-FIRST. :root carries the dark palette; `.light` derives the light one.
 * Import the stylesheet once at the app root:
 *
 *     import "@vantage/kit/styles";
 *
 * and wrap the tree in next-themes with `attribute="class"` and
 * `defaultTheme="dark"`. Components read tokens, so they are correct in both
 * themes without per-theme classes.
 */

// ---- tokens & helpers ----
export { cn } from "./lib/cn";
export * from "./lib/icons";
export * from "./lib/surfaces";
export * from "./lib/rank";
export {
  useDebouncedValue, usePersistentState, useDismissable, compareValues,
  type SortState, type SortDirection,
} from "./lib/use-table";

// ---- primitives ----
export {
  scoreLevel, SCORE_LABEL, SCORE_TONE, SCORE_THRESHOLDS, type ScoreLevel,
} from "./components/primitives";
export { KpiTile, ScoreGauge, type KpiTileProps, type KpiDelta, type ScoreGaugeProps } from "./components/kpi-tile";
export {
  Card, CardHeader, CardTitle, CardFooter, Eyebrow, Button,
  DeltaPill, ScoreBadge, Sparkline,
  type CardProps, type ButtonProps, type DeltaPillProps,
  type ScoreBadgeProps, type SparklineProps,
} from "./components/primitives";

// ---- badges & pills ----
export {
  StatusPill, SourceBadge, RunStatePill, RankPill, SeverityDot,
  RolePill, ScopePill, RunScopePill,
  ROLE_META, ROLES, SCOPES, RUN_SCOPES,
  type Role, type Scope, type RunScope,
  type StatusPillProps, type SourceBadgeProps, type RankPillProps,
} from "./components/pills";

export {
  SurfaceBadge, SurfaceDot, SurfaceIcon,
  type SurfaceBadgeProps, type SurfaceDotProps,
} from "./components/surface-badge";

// ---- composite ----
export { SurfaceMatrix, SurfaceMatrixCell, type MatrixRow, type CellState } from "./components/surface-matrix";
export { SurfaceSelector, SurfaceSelectorCard, SurfaceCategoryHeader } from "./components/surface-selector";
export { CostPreview, type CostPreviewProps } from "./components/cost-preview";
export {
  DataTable,
  type DataTableProps, type Column, type TableFilter, type Density,
} from "./components/data-table";
export { Popover, CheckRow, type PopoverProps } from "./components/popover";

// ---- charts ----
// In Next.js import these with `dynamic(..., { ssr: false })` — Recharts
// measures the DOM, and the token resolver needs a real computed style.
export {
  TimeSeries,
  type TimeSeriesProps, type Series, type SignalMarker,
} from "./components/charts/time-series";
export {
  useChartTokens, usePrefersReducedMotion, SERIES_ORDER, MAX_READABLE_SERIES,
  RANK_TOKEN, type ChartTokens,
} from "./lib/use-chart-tokens";
export { SovBars, type SovBarsProps, type SovRow } from "./components/charts/sov-bars";
export { BucketArea, type BucketAreaProps } from "./components/charts/bucket-area";
export {
  PositionLine, DualAxisTraffic,
  type PositionLineProps, type DualAxisTrafficProps, type TrafficSeries,
} from "./components/charts/presets";
export {
  HeatGrid,
  type HeatGridProps, type HeatRow, type HeatColumn, type HeatCell, type HeatSort,
} from "./components/charts/heat-grid";
export {
  algoUpdatesInRange, rollingMean, pctChange, shortDate,
  ALGO_TOKEN, ALGO_LABEL,
  type AlgoUpdate, type AlgoType, type AlgoUpdatesFile,
} from "./lib/algo-updates";
export { AIInsightsCard, AIInsightTile, AIInsightsSparkle, type AIInsight } from "./components/ai-insights-card";
export { ScopeBanner, ParentDomainStrip, GSCSyncStrip, type GscState } from "./components/strips";

// ---- domain panels ----
export {
  EmptyState, PanelSkeleton, NotMeasured, EMPTY_STATE_VARIANTS,
  type EmptyStateProps, type EmptyStateVariant,
  type PanelSkeletonProps, type NotMeasuredProps,
} from "./components/domain/empty-state";
export { AlertList, alertTime, type AlertListProps, type AlertItem } from "./components/domain/alert-list";
export { RoadblockPanel, daysBlocked, type RoadblockPanelProps, type RoadblockItem } from "./components/domain/roadblock-panel";
export { MoversPanel, type MoversPanelProps, type MoverItem } from "./components/domain/movers-panel";
export { AuditItemCard, type AuditItemCardProps } from "./components/domain/audit-item-card";

// ---- shell ----
export {
  CommandPalette, type CommandPaletteProps, type CommandGroup, type CommandItem,
} from "./components/shell/command-palette";
export {
  DateRangePicker, resolveDateRange, formatDateRange, dayCount, todayISO,
  DATE_RANGE_PRESETS, DATE_RANGE_LABEL,
  type DateRangePickerProps, type DateRange, type DateRangePreset, type FixedDateRangePreset,
} from "./components/shell/date-range-picker";
export {
  ThemeToggle, THEME_STORAGE_KEY, THEME_CHOICES, resolveTheme, applyTheme,
  type ThemeToggleProps, type ThemeChoice, type ResolvedTheme,
} from "./components/shell/theme-toggle";
export {
  NotificationBell, NOTIFICATION_BADGE_CAP,
  type NotificationBellProps, type AppNotification,
} from "./components/shell/notification-bell";
export { Sidebar, NavRow, NavGroupLabel, type NavItem, type NavGroup, type SidebarProps } from "./components/sidebar";
export { TopBar, AutoSaveIndicator, LastSyncIndicator, type Crumb, type SaveState } from "./components/topbar";
