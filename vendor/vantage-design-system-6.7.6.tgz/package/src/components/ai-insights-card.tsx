"use client";

import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { cn } from "../lib/cn";
import { actionIcon, navIcon, ICON_SIZE, type SourceId } from "../lib/icons";
import { Card, Eyebrow } from "./primitives";
import { SourceBadge } from "./pills";

/**
 * AIInsightsCard — the Insight Engine's surface ("the brain").
 *
 * Non-negotiable from the project brief: insights are grounded and cited,
 * never fabricated. That is enforced here structurally — an insight cannot
 * render without a `source`, and the citation is part of the component rather
 * than something a caller remembers to add. If the engine cannot attribute a
 * claim, it does not get to make it.
 */
export interface AIInsight {
  id: string;
  /** The claim. One sentence, specific, no hedging. */
  headline: string;
  /** Why it matters / what to do. */
  detail?: ReactNode;
  /** Where the claim came from. Required — see the note above. */
  source: SourceId;
  /** Optional metric that anchors the claim. */
  evidence?: string;
  onAct?: () => void;
  actLabel?: string;
}

export function AIInsightsSparkle({ className }: { className?: string }) {
  return (
    <actionIcon.aiAction
      size={ICON_SIZE.dense}
      className={cn("shrink-0 text-teal", className)}
      aria-hidden
    />
  );
}

export function AIInsightTile({ insight }: { insight: AIInsight }) {
  return (
    <li className="flex flex-col gap-2 border-l-[3px] border-l-teal bg-teal/5 px-4 py-3">
      <div className="flex items-start gap-2">
        <AIInsightsSparkle className="mt-0.5" />
        <p className="text-small font-semibold leading-snug text-ink">{insight.headline}</p>
      </div>

      {insight.detail && (
        <p className="pl-6 text-meta leading-relaxed text-ink-2">{insight.detail}</p>
      )}

      <div className="flex flex-wrap items-center gap-2 pl-6">
        <SourceBadge source={insight.source} size="sm" />
        {insight.evidence && (
          <span className="font-mono text-meta tabular-nums text-ink-3">{insight.evidence}</span>
        )}
        {insight.onAct && (
          <button
            type="button"
            onClick={insight.onAct}
            className="ml-auto inline-flex items-center gap-1 rounded text-meta font-bold text-teal-ink transition-colors duration-fast hover:text-teal-hover focus-visible:outline-none focus-visible:shadow-focus"
          >
            {insight.actLabel ?? "Act on this"}
            <navIcon.forward size={ICON_SIZE.dense} aria-hidden />
          </button>
        )}
      </div>
    </li>
  );
}

export interface AIInsightsCardProps extends ComponentPropsWithoutRef<"div"> {
  title?: string;
  insights?: AIInsight[];
  /** Rendered instead of the empty state when there are no insights. */
  children?: ReactNode;
  showSparkle?: boolean;
}

export function AIInsightsCard({
  title = "AI insights", insights = [], children, showSparkle = true,
  className, ...props
}: AIInsightsCardProps) {
  const empty = insights.length === 0 && !children;

  return (
    <Card padding="none" tone="teal" className={cn("overflow-hidden", className)} {...props}>
      <div className="flex items-center gap-2 px-4 pb-2 pt-4">
        {showSparkle && <AIInsightsSparkle />}
        <Eyebrow className="text-teal-ink">{title}</Eyebrow>
        {insights.length > 0 && (
          <span className="ml-auto font-mono text-meta tabular-nums text-ink-3">
            {insights.length}
          </span>
        )}
      </div>

      {empty ? (
        // Honest empty state: says what is true, and what would change it.
        // Never invents an insight to fill the space.
        <p className="px-4 pb-4 text-meta leading-relaxed text-ink-3">
          No insights this cycle. The engine surfaces one only when it can cite
          the data behind it — an empty card means nothing crossed the threshold,
          not that nothing was checked.
        </p>
      ) : children ? (
        <div className="px-4 pb-4">{children}</div>
      ) : (
        <ul className="flex flex-col gap-px pb-1">
          {insights.map((insight) => (
            <AIInsightTile key={insight.id} insight={insight} />
          ))}
        </ul>
      )}
    </Card>
  );
}
