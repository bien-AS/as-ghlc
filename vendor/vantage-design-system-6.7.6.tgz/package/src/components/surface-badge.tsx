import { cva, type VariantProps } from "class-variance-authority";
import type { ComponentPropsWithoutRef, ReactElement } from "react";
import { cn } from "../lib/cn";
import { SURFACE_META, getSurface, type SurfaceId } from "../lib/surfaces";

/**
 * Vendor marks for the 6 AI surfaces.
 *
 * These are hand-authored rather than Lucide, because they identify real
 * third-party products and a generic glyph would misattribute them. This is
 * the one sanctioned exception to the Lucide-only icon rule — see
 * `lib/icons.ts`. Drawn on a 48x48 canvas; `currentColor` throughout so the
 * mark inherits whatever colour the badge sets.
 *
 * AI Overviews and AI Mode deliberately share Google Blue and are told apart
 * by their mark alone (stacked summary bars vs chat bubble + sparkle).
 */
const MARKS: Record<SurfaceId, ReactElement> = {
  perplexity: (
    <>
      <g stroke="currentColor" strokeWidth={3} strokeLinecap="round" fill="none">
        <line x1={24} y1={8} x2={24} y2={40} />
        <line x1={8} y1={24} x2={40} y2={24} />
        <line x1={12.7} y1={12.7} x2={35.3} y2={35.3} />
        <line x1={35.3} y1={12.7} x2={12.7} y2={35.3} />
      </g>
      <circle cx={24} cy={24} r={3} fill="currentColor" />
    </>
  ),
  chatgpt: (
    <g fill="none" stroke="currentColor" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round">
      <ellipse cx={24} cy={24} rx={6.5} ry={13.5} />
      <ellipse cx={24} cy={24} rx={6.5} ry={13.5} transform="rotate(60 24 24)" />
      <ellipse cx={24} cy={24} rx={6.5} ry={13.5} transform="rotate(120 24 24)" />
    </g>
  ),
  gemini: (
    <path
      d="M24 9 C24 18.5 25.5 22.5 39 24 C25.5 25.5 24 29.5 24 39 C24 29.5 22.5 25.5 9 24 C22.5 22.5 24 18.5 24 9 Z"
      fill="currentColor"
    />
  ),
  claude: (
    <g fill="currentColor">
      <path d="M24 8 L26 22 L24 24 L22 22 Z" />
      <path d="M24 40 L26 26 L24 24 L22 26 Z" />
      <path d="M8 24 L22 22 L24 24 L22 26 Z" />
      <path d="M40 24 L26 22 L24 24 L26 26 Z" />
    </g>
  ),
  "ai-overviews": (
    <>
      <g stroke="currentColor" strokeWidth={3} strokeLinecap="round" fill="none">
        <line x1={11} y1={17} x2={33} y2={17} />
        <line x1={11} y1={24} x2={30} y2={24} />
        <line x1={11} y1={31} x2={25} y2={31} />
      </g>
      <path d="M38 8.5 L39.4 11.9 L42.8 13.3 L39.4 14.7 L38 18.1 L36.6 14.7 L33.2 13.3 L36.6 11.9 Z" fill="currentColor" />
    </>
  ),
  "ai-mode": (
    <>
      <path
        d="M14 11 H34 a4 4 0 0 1 4 4 V29 a4 4 0 0 1 -4 4 H23 L16 39 V33 H14 a4 4 0 0 1 -4 -4 V15 a4 4 0 0 1 4 -4 Z"
        fill="none" stroke="currentColor" strokeWidth={2.6} strokeLinejoin="round"
      />
      <path d="M24 16 L25.6 20.4 L30 22 L25.6 23.6 L24 28 L22.4 23.6 L18 22 L22.4 20.4 Z" fill="currentColor" />
    </>
  ),
};

export interface SurfaceIconProps
  extends Omit<ComponentPropsWithoutRef<"svg">, "children"> {
  surface: string;
  size?: number;
}

export function SurfaceIcon({ surface, size = 16, className, ...props }: SurfaceIconProps) {
  const meta = getSurface(surface);
  if (!meta) return null;
  return (
    <svg
      width={size} height={size} viewBox="0 0 48 48"
      className={cn("shrink-0", className)} aria-hidden focusable="false"
      {...props}
    >
      {MARKS[meta.id]}
    </svg>
  );
}

const badge = cva(
  "inline-flex items-center gap-1.5 rounded-full font-bold whitespace-nowrap",
  {
    variants: {
      size: {
        sm: "px-2 py-0.5 text-nano gap-1",
        md: "px-2.5 py-1 text-micro",
        lg: "px-3 py-1.5 text-meta",
      },
      interactive: {
        true: "cursor-pointer transition-opacity duration-fast hover:opacity-80 focus-visible:outline-none focus-visible:shadow-focus",
        false: "",
      },
    },
    defaultVariants: { size: "md", interactive: false },
  },
);

export interface SurfaceBadgeProps
  extends Omit<ComponentPropsWithoutRef<"span">, "color">,
    VariantProps<typeof badge> {
  surface: string;
  showCost?: boolean;
  showGlyph?: boolean;
}

export function SurfaceBadge({
  surface, size, showCost = false, showGlyph = true, interactive,
  className, style, ...props
}: SurfaceBadgeProps) {
  const meta = getSurface(surface);
  if (!meta) return null;
  const iconSize = size === "lg" ? 16 : size === "sm" ? 11 : 13;

  return (
    <span
      className={cn(badge({ size, interactive }), className)}
      // Vendor colours are per-surface data, not design tokens, so they are
      // set inline rather than through a Tailwind class.
      //
      // TEXT uses the vendor's DARK variant, not its base: the base colour on
      // its own soft chip measures 2.2-3.7:1 and fails. The dark variant lands
      // at 4.0-5.9:1 on the same chip, and the chip stays light in both themes
      // (the -soft tokens are vendor data and do not flip), so one pairing is
      // correct everywhere. The mark keeps the base colour — it is an identity
      // glyph, not text.
      style={{ background: meta.soft, color: meta.colorDark, ...style }}
      {...props}
    >
      <SurfaceIcon surface={meta.id} size={iconSize} style={{ color: meta.color }} />
      {showGlyph ? meta.glyph : meta.name}
      {showCost && (
        <span className="font-mono font-medium tabular-nums opacity-75">
          ${meta.cost.toFixed(3)}
        </span>
      )}
    </span>
  );
}

export interface SurfaceDotProps extends ComponentPropsWithoutRef<"span"> {
  surface: string;
  size?: number;
}

export function SurfaceDot({ surface, size = 8, className, style, ...props }: SurfaceDotProps) {
  const meta = getSurface(surface);
  if (!meta) return null;
  return (
    <span
      className={cn("inline-block shrink-0 rounded-full", className)}
      style={{ width: size, height: size, background: meta.color, ...style }}
      title={meta.name}
      {...props}
    />
  );
}

export { SURFACE_META };
