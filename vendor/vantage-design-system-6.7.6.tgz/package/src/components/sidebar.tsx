"use client";

import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { cn } from "../lib/cn";
import { ICON_SIZE, type LucideIcon } from "../lib/icons";
import { RolePill, type Role } from "./pills";

/**
 * Sidebar — always-dark chrome, in BOTH themes.
 *
 * Two rules here are behavioural, not cosmetic:
 *
 * 1. SCOPE-GATING. A module that needs a selected client renders at reduced
 *    opacity with a tooltip explaining why, rather than vanishing. The
 *    operator can see the app has the capability and learn what unlocks it.
 *
 * 2. ROLE-GATING IS OMISSION, NOT HIDING. Items a role may not use are not
 *    rendered at all — `hidden` items never reach the DOM. Do not "hide" them
 *    with CSS: this is an access-control boundary, and a class is not one.
 *    The caller is still responsible for enforcing the same rule server-side;
 *    this only stops the UI from advertising what it must not.
 *
 * Because the sidebar is always dark, its text uses the `ink-on-dark*` tokens,
 * which are intentionally NOT overridden per theme. Never style it with
 * `--fg-1` or a surface token — those flip, and the sidebar does not.
 */

export interface NavItem {
  id: string;
  label: string;
  icon: LucideIcon;
  badge?: string | number;
  /** Requires a selected client/domain. Renders dimmed + tooltip when absent. */
  requiresScope?: boolean;
  /** Not permitted for the active role — omitted from the DOM entirely. */
  hidden?: boolean;
}

export interface NavGroup {
  id: string;
  label?: string;
  items: NavItem[];
  /** Whole group omitted for this role. */
  hidden?: boolean;
}

export interface NavRowProps extends Omit<ComponentPropsWithoutRef<"button">, "id"> {
  item: NavItem;
  active?: boolean;
  scoped?: boolean;
}

export function NavRow({ item, active = false, scoped = true, className, ...props }: NavRowProps) {
  const Icon = item.icon;
  const gated = Boolean(item.requiresScope) && !scoped;

  return (
    <button
      type="button"
      aria-current={active ? "page" : undefined}
      aria-disabled={gated || undefined}
      title={gated ? "Select a client to open this module" : undefined}
      className={cn(
        "group relative mx-2 flex items-center gap-2.5 rounded-md px-3 py-2 text-small transition-colors duration-fast ease-standard",
        "focus-visible:outline-none focus-visible:shadow-focus",
        // `--bg-dark-active`, not `--bg-dark-hover`. The active row used to
        // borrow the hover token, so hovering ANY inactive row painted it the
        // exact same ground as the active one — two different states, one
        // colour — while `--bg-dark-active` sat defined and unused. Active is
        // now the quieter persistent lift and hover stays the brighter
        // transient one, which is what the three-token ramp was built for.
        active
          ? "bg-[var(--bg-dark-active)] font-bold text-ink-on-dark hover:bg-[var(--bg-dark-hover)]"
          : "font-normal text-ink-on-dark-2 hover:bg-[var(--bg-dark-hover)] hover:text-ink-on-dark",
        gated && "cursor-not-allowed opacity-55 hover:bg-transparent hover:text-ink-on-dark-2",
        className,
      )}
      {...props}
    >
      {/* Active rail — 3px, inside the row so it never shifts layout.
          Uses the NON-FLIPPING accent: the sidebar is dark in both themes, so a
          theme-flipping teal would drop to 3.72:1 against the active row in
          light while looking fine in dark. */}
      <span
        aria-hidden
        className={cn(
          "absolute left-0 top-1/2 h-[18px] w-[3px] -translate-x-2 -translate-y-1/2 rounded-r",
          active ? "bg-[color:var(--accent-on-dark)]" : "bg-transparent",
        )}
      />
      <Icon size={ICON_SIZE.dense} className={cn("shrink-0", active && "text-[color:var(--accent-on-dark)]")} aria-hidden />
      <span className="min-w-0 flex-1 truncate text-left">{item.label}</span>
      {item.badge != null && (
        <span
          className={cn(
            "shrink-0 rounded-full px-1.5 py-px font-mono text-nano font-bold tabular-nums",
            active
              ? "bg-[color:var(--accent-on-dark)] text-[color:var(--fg-on-accent-on-dark)]"
              : "bg-[var(--bg-dark-hover)] text-ink-on-dark-2",
          )}
        >
          {item.badge}
        </span>
      )}
    </button>
  );
}

export function NavGroupLabel({ children }: { children: ReactNode }) {
  return (
    <div className="px-5 pb-1.5 pt-4 text-nano font-bold uppercase tracking-[0.08em] text-ink-on-dark-3">
      {children}
    </div>
  );
}

export interface SidebarProps extends ComponentPropsWithoutRef<"aside"> {
  groups: NavGroup[];
  activeId?: string;
  onNavigate?: (id: string) => void;
  /** Whether a client/domain is selected. Drives scope-gating. */
  scoped?: boolean;
  brand?: ReactNode;
  role?: Role;
  user?: { name: string; initials: string; sublabel?: string };
  footer?: ReactNode;
}

export function Sidebar({
  groups, activeId, onNavigate, scoped = true, brand, role, user, footer,
  className, ...props
}: SidebarProps) {
  return (
    <aside
      className={cn(
        "flex w-[240px] min-w-[240px] flex-col bg-[var(--bg-dark)] text-ink-on-dark",
        "border-r border-[var(--border-dark)]",
        className,
      )}
      {...props}
    >
      {brand && <div className="px-5 py-4">{brand}</div>}

      <nav className="flex-1 overflow-y-auto pb-3" aria-label="Main">
        {groups
          .filter((g) => !g.hidden)
          .map((group) => (
            <div key={group.id}>
              {group.label && <NavGroupLabel>{group.label}</NavGroupLabel>}
              {group.items
                // Role-gated items are OMITTED, never CSS-hidden. See the note above.
                .filter((item) => !item.hidden)
                .map((item) => (
                  <NavRow
                    key={item.id}
                    item={item}
                    active={item.id === activeId}
                    scoped={scoped}
                    onClick={() => {
                      if (item.requiresScope && !scoped) return;
                      onNavigate?.(item.id);
                    }}
                  />
                ))}
            </div>
          ))}
      </nav>

      {(user || role || footer) && (
        <div className="border-t border-[var(--border-dark)] px-4 py-3">
          {footer}
          {user && (
            <div className="flex items-center gap-2.5">
              <span
                // Fixed chrome: the sidebar is dark in both themes, so the avatar uses the
              // non-flipping accent pairing rather than the theme-dependent teal.
              className="grid size-7 shrink-0 place-items-center rounded-full font-mono text-nano font-bold"
              style={{ background: "var(--accent-on-dark)", color: "var(--fg-on-accent-on-dark)" }}
                aria-hidden
              >
                {user.initials}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-meta font-semibold text-ink-on-dark">
                  {user.name}
                </span>
                {user.sublabel && (
                  <span className="block truncate text-nano text-ink-on-dark-3">{user.sublabel}</span>
                )}
              </span>
              {role && <RolePill role={role} short size="sm" />}
            </div>
          )}
        </div>
      )}
    </aside>
  );
}
