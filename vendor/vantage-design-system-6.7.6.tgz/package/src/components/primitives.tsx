import { cva, type VariantProps } from "class-variance-authority";
import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { cn } from "../lib/cn";
import { trendIcon, ICON_SIZE } from "../lib/icons";

/* ================================================================== *
 * Card — flat and bordered, NO resting shadow. Elevation is reserved
 * for popovers, modals and toasts; a card that lifts on the page is a
 * bug, not a style choice.
 * ================================================================== */
const card = cva("rounded-xl border bg-card text-card-foreground", {
  variants: {
    padding: { none: "p-0", tight: "p-4", default: "p-6" },
    interactive: {
      true: "cursor-pointer transition-colors duration-fast ease-standard hover:bg-surface-hover hover:border-line-strong focus-visible:outline-none focus-visible:shadow-focus",
      false: "",
    },
    tone: {
      default: "border-line",
      teal: "border-l-[3px] border-l-teal border-line",
      amber: "border-l-[3px] border-l-amber border-line",
      danger: "border-l-[3px] border-l-danger border-line",
    },
  },
  defaultVariants: { padding: "default", interactive: false, tone: "default" },
});

export interface CardProps
  extends ComponentPropsWithoutRef<"div">, VariantProps<typeof card> {}

export function Card({ className, padding, interactive, tone, ...props }: CardProps) {
  return <div className={cn(card({ padding, interactive, tone }), className)} {...props} />;
}

export function CardHeader({ className, ...props }: ComponentPropsWithoutRef<"div">) {
  return (
    <div
      className={cn("flex items-center gap-3 border-b border-line px-5 py-3.5", className)}
      {...props}
    />
  );
}

export function CardTitle({ className, ...props }: ComponentPropsWithoutRef<"h3">) {
  return <h3 className={cn("text-[16px] font-bold tracking-[-0.01em]", className)} {...props} />;
}

export function CardFooter({ className, ...props }: ComponentPropsWithoutRef<"div">) {
  return <div className={cn("border-t border-line px-5 py-3", className)} {...props} />;
}

/* ================================================================== *
 * Eyebrow — uppercase label. 11px with 0.06em tracking is the AS spec;
 * below 11px the letter-spacing stops doing its job.
 * ================================================================== */
export function Eyebrow({ className, ...props }: ComponentPropsWithoutRef<"div">) {
  return (
    <div
      className={cn(
        "text-micro font-bold uppercase tracking-[0.06em] text-ink-3",
        className,
      )}
      {...props}
    />
  );
}

/* ================================================================== *
 * Button
 * `accent` is brand red and is RESERVED — critical alerts and
 * destructive confirmations only. It is not "a more important primary".
 * ================================================================== */
const button = cva(
  "inline-flex items-center justify-center gap-1.5 whitespace-nowrap rounded-md font-bold " +
    "transition-colors duration-fast ease-standard " +
    "focus-visible:outline-none focus-visible:shadow-focus " +
    "disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        primary: "bg-teal text-ink-on-teal hover:bg-teal-fill-hover active:bg-teal-fill-press",
        secondary: "border border-line-strong bg-card text-ink hover:bg-surface-hover",
        // `-ink`, not the base teal: ghost sits on the CARD ground, where the
        // base measures 3.74:1 in light at 13px and fails. The audit did not
        // catch this because the only ghost buttons in the demos live inside a
        // closed popover — a hidden element is never measured.
        ghost: "text-teal-ink hover:bg-teal-soft",
        destructive:
          "bg-danger text-white hover:bg-danger-dark focus-visible:shadow-focus-danger",
      },
      size: {
        sm: "h-7 px-2.5 text-meta",
        md: "h-8 px-3.5 text-small",
        lg: "h-9 px-4 text-body",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  },
);

export interface ButtonProps
  extends ComponentPropsWithoutRef<"button">, VariantProps<typeof button> {
  icon?: ReactNode;
}

export function Button({ className, variant, size, icon, children, ...props }: ButtonProps) {
  return (
    <button className={cn(button({ variant, size }), className)} {...props}>
      {icon}
      {children}
    </button>
  );
}

/* ================================================================== *
 * DeltaPill
 *
 * Direction alone misreads. "ER wait time down 8%" is good news with a
 * down arrow; "rank moved to 4" is bad news with a *lower* number. So
 * `label` is REQUIRED, and `goodDirection` decouples "which way the
 * number went" from "whether that is good".
 * ================================================================== */
export interface DeltaPillProps extends Omit<ComponentPropsWithoutRef<"span">, "children"> {
  value: number;
  /** Required context. Without it the arrow is ambiguous. */
  label: string;
  suffix?: string;
  /** Which direction counts as good. Rank charts pass "down". */
  goodDirection?: "up" | "down";
  precision?: number;
}

export function DeltaPill({
  value, label, suffix = "%", goodDirection = "up", precision = 1, className, ...props
}: DeltaPillProps) {
  const flat = value === 0;
  const direction = flat ? "flat" : value > 0 ? "up" : "down";
  const Icon = trendIcon[direction];
  const good = flat ? null : direction === goodDirection;

  const tone = good === null ? "text-ink-3" : good ? "text-teal-ink" : "text-danger-ink";
  // U+2212 MINUS SIGN, not a hyphen — the AS system is explicit about this,
  // and a hyphen at 12px next to tabular figures reads as a dash, not a sign.
  const sign = flat ? "" : value > 0 ? "+" : "\u2212";

  return (
    <span
      className={cn("inline-flex items-baseline gap-1.5 text-meta", className)}
      {...props}
    >
      <span className={cn("inline-flex items-center gap-1 font-bold tabular-nums", tone)}>
        <Icon size={ICON_SIZE.dense} aria-hidden className="translate-y-px" />
        {sign}
        {Math.abs(value).toFixed(precision)}
        {suffix}
      </span>
      <span className="text-ink-3">{label}</span>
    </span>
  );
}

/* ================================================================== *
 * Score thresholds — ONE definition, used by every score surface.
 *
 * >=60 strong, 30-59 needs work, <30 critical. Exported because
 * ScoreBadge and ScoreGauge both render these boundaries, and a
 * duplicated copy is how the same score ends up reading "Strong" in
 * the gauge and amber in the badge on the same screen.
 * ================================================================== */
export type ScoreLevel = "strong" | "needs-work" | "critical";

export const SCORE_THRESHOLDS = { strong: 60, needsWork: 30 } as const;

export function scoreLevel(value: number): ScoreLevel {
  if (value >= SCORE_THRESHOLDS.strong) return "strong";
  if (value >= SCORE_THRESHOLDS.needsWork) return "needs-work";
  return "critical";
}

/** Human label per level. Plain statements — the AS voice forbids exclamation. */
export const SCORE_LABEL: Record<ScoreLevel, string> = {
  strong: "Strong",
  "needs-work": "Needs work",
  critical: "Critical",
};

/** Tailwind pairs per level: text on the matching soft fill. */
export const SCORE_TONE: Record<ScoreLevel, string> = {
  strong: "bg-teal-soft text-teal-ink",
  "needs-work": "bg-amber-soft text-amber-ink",
  critical: "bg-danger-soft text-danger-ink",
};

/* ================================================================== *
 * ScoreBadge — the number is always shown, so colour is redundant
 * encoding rather than the encoding.
 * ================================================================== */
export interface ScoreBadgeProps extends ComponentPropsWithoutRef<"span"> {
  value: number;
  outOf?: number;
}

export function ScoreBadge({ value, outOf, className, ...props }: ScoreBadgeProps) {
  const tone = SCORE_TONE[scoreLevel(value)];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-meta font-bold tabular-nums",
        tone, className,
      )}
      {...props}
    >
      <span className="size-1.5 rounded-full bg-current" aria-hidden />
      {value}
      {outOf != null && <span className="font-medium opacity-70">/{outOf}</span>}
    </span>
  );
}

/* ================================================================== *
 * Sparkline — decorative by contract. It carries no axis and no
 * labels, so it is marked aria-hidden and must sit beside the real
 * number it summarises, never replace it.
 * ================================================================== */
export interface SparklineProps {
  data: number[];
  width?: number;
  height?: number;
  fill?: boolean;
  className?: string;
  /** Any CSS colour. Defaults to the teal token. */
  stroke?: string;
}

/** Endpoint dot radius. The plot is inset by it on both axes so the dot is
 *  drawn INSIDE the viewBox — see the overflow note below. */
const SPARK_DOT = 2;

export function Sparkline({
  data, width = 120, height = 36, fill = true, className, stroke = "var(--cta-teal)",
}: SparklineProps) {
  if (data.length < 2) return null;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;

  // Inset the plot by the dot radius. Previously the last point sat at x=width
  // with a r=2 dot on top of it and `overflow-visible` on the svg, so the dot
  // painted 2px outside the element's own box and counted toward the page's
  // scroll width. Insetting means nothing is ever drawn outside the viewBox,
  // and the svg no longer needs to leak.
  const x0 = SPARK_DOT;
  const span = Math.max(1, width - SPARK_DOT * 2);
  const pts = data.map((v, i): [number, number] => [
    x0 + (i / (data.length - 1)) * span,
    height - ((v - min) / range) * (height - 4) - 2,
  ]);
  const path = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p[0]},${p[1]}`).join(" ");
  const last = pts[pts.length - 1];

  return (
    <svg
      width={width} height={height} viewBox={`0 0 ${width} ${height}`}
      // max-w-full so the sparkline shrinks with its container. With a bare
      // width attribute it could not, and a 200px spark inside a narrower card
      // pushed the whole page into horizontal scroll — silently, because an
      // overflowing svg reports its full width and nothing errors.
      //
      // preserveAspectRatio="none" compresses horizontally instead of
      // letterboxing, so the row height stays fixed; the stroke is held at a
      // true 1.5px by vector-effect rather than being scaled with the geometry.
      preserveAspectRatio="none"
      className={cn("block max-w-full", className)} aria-hidden focusable="false"
    >
      {fill && (
        <path
          d={`${path} L${last?.[0] ?? width},${height} L${x0},${height} Z`}
          fill={stroke}
          opacity={0.12}
        />
      )}
      <path
        d={path} fill="none" stroke={stroke} strokeWidth={1.5}
        strokeLinejoin="round" vectorEffect="non-scaling-stroke"
      />
      {/* Emphasised endpoint — the value the reader actually wants. */}
      {last && <circle cx={last[0]} cy={last[1]} r={SPARK_DOT} fill={stroke} />}
    </svg>
  );
}
