import { cva, type VariantProps } from "class-variance-authority";
import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { cn } from "../lib/cn";
import { SurfaceBadge } from "./surface-badge";
import { SURFACE_META, type SurfaceId } from "../lib/surfaces";

/**
 * CostPreview — shown before ANY action that spends money: add domain, add
 * tracked page, launch audit, bulk import, run scan.
 *
 * The product is metered, so the operator must be able to see the bill before
 * they commit, and see the arithmetic that produced it. `math` is not optional
 * decoration — it is the reason this component exists. A cost with no visible
 * derivation is the thing this is designed to prevent.
 */
const preview = cva("rounded-lg border-l-[3px] p-4", {
  variants: {
    variant: {
      default: "border-l-ink-3 bg-surface-hover",
      saving: "border-l-teal bg-teal/5",
      warning: "border-l-amber bg-amber/5",
      over: "border-l-danger bg-danger/5",
      "per-surface": "border-l-ink-3 bg-surface-hover",
    },
  },
  defaultVariants: { variant: "default" },
});

const AMOUNT_TONE = {
  default: "text-ink",
  saving: "text-teal-ink",
  warning: "text-amber-ink",
  over: "text-danger-ink",
  "per-surface": "text-ink",
} as const;

export interface CostPreviewProps
  extends ComponentPropsWithoutRef<"div">, VariantProps<typeof preview> {
  title?: string;
  /** Formatted for display by the caller, e.g. "$0.035". */
  amount: string;
  amountSuffix?: string;
  /** How the number was reached — "7 keywords × 3 surfaces × $0.015". */
  math?: ReactNode;
  monthlyImpact?: ReactNode;
  savings?: ReactNode;
  /** Surfaces to itemise. Only read when variant is "per-surface". */
  perSurfaceBreakdown?: readonly { surface: SurfaceId; count: number }[];
}

export function CostPreview({
  title = "Estimated cost", amount, amountSuffix, math, monthlyImpact, savings,
  variant = "default", perSurfaceBreakdown, className, ...props
}: CostPreviewProps) {
  const tone = AMOUNT_TONE[variant ?? "default"];

  return (
    <div className={cn(preview({ variant }), className)} {...props}>
      <div className="flex items-baseline justify-between gap-4">
        <span className="text-micro font-bold uppercase tracking-[0.06em] text-ink-3">
          {title}
        </span>
        <span className={cn("font-mono text-[20px] font-bold tabular-nums leading-none", tone)}>
          {amount}
          {amountSuffix && (
            <span className="ml-1 text-meta font-medium text-ink-3">{amountSuffix}</span>
          )}
        </span>
      </div>

      {math && (
        <p className="mt-2 font-mono text-meta tabular-nums text-ink-3">{math}</p>
      )}

      {variant === "per-surface" && perSurfaceBreakdown && perSurfaceBreakdown.length > 0 && (
        <ul className="mt-3 flex flex-col gap-1.5 border-t border-line pt-3">
          {perSurfaceBreakdown.map(({ surface, count }) => {
            const meta = SURFACE_META[surface];
            if (!meta) return null;
            return (
              <li key={surface} className="flex items-center justify-between gap-3 text-meta">
                <SurfaceBadge surface={surface} size="sm" />
                <span className="font-mono tabular-nums text-ink-3">
                  {count} × ${meta.cost.toFixed(3)}
                  <span className="ml-2 font-bold text-ink-2">
                    ${(count * meta.cost).toFixed(3)}
                  </span>
                </span>
              </li>
            );
          })}
        </ul>
      )}

      {(monthlyImpact || savings) && (
        <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 border-t border-line pt-2.5 text-meta text-ink-3">
          {monthlyImpact && <span>{monthlyImpact}</span>}
          {savings && <span className="font-semibold text-teal-ink">{savings}</span>}
        </div>
      )}
    </div>
  );
}
