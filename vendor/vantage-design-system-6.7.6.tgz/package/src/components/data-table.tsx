"use client";

import { useCallback, useId, useMemo, useState, type ReactNode } from "react";
import { cn } from "../lib/cn";
import { actionIcon, navIcon, ICON_SIZE, type SourceId } from "../lib/icons";
import {
  compareValues, useDebouncedValue, usePersistentState,
  type SortDirection, type SortState,
} from "../lib/use-table";
import { Button } from "./primitives";
import { Popover, CheckRow } from "./popover";
import { SourceBadge } from "./pills";

/**
 * DataTable — the most-reused component in the product.
 *
 * The anatomy is the Baptist SaaS one, because it is already proven against
 * this exact kind of data: debounced search, a filter popover with multi-select
 * chips and Apply / Clear all, column-visibility toggle, a three-step density
 * control persisted per viewer, a bulk-action bar on selection, and card
 * collapse below `md`.
 *
 * Three behaviours here are correctness, not styling:
 *
 * 1. NULL IS NOT ZERO. `null` means NOT MEASURED and always sorts last, in both
 *    directions. Sorting a rank column ascending must never float unmeasured
 *    rows to the top as if they were rank 1.
 *
 * 2. EMPTY HAS TWO MEANINGS. "No rows match your filters" offers a way to clear
 *    them; "there is genuinely nothing here" offers the primary action. Showing
 *    the wrong one sends people hunting for data that was never there, or
 *    hunting for a filter they never set.
 *
 * 3. CHROME STAYS AT ZERO ROWS. The toolbar and header remain visible when the
 *    table is empty, so the controls that produced the empty result are still
 *    reachable.
 */

export type Density = "compact" | "default" | "comfortable";

const DENSITY: Record<Density, { label: string; cell: string; head: string }> = {
  compact:     { label: "Compact",     cell: "py-1 text-meta",   head: "py-1.5" },
  default:     { label: "Default",     cell: "py-2 text-small",  head: "py-2" },
  comfortable: { label: "Comfortable", cell: "py-3 text-small",  head: "py-2.5" },
};

export interface Column<T> {
  id: string;
  header: string;
  /** Cell content. */
  cell: (row: T) => ReactNode;
  /**
   * Sortable / searchable value for this cell. Omit and the column is neither.
   * Return `null` for "not measured" — it sorts last in both directions.
   */
  value?: (row: T) => string | number | null;
  /** Right-aligns and applies tabular figures. Every number in this product is tabular. */
  numeric?: boolean;
  /** Cannot be hidden — the column that identifies the row. */
  locked?: boolean;
  defaultHidden?: boolean;
  width?: string;
  /** Header tooltip, for a column whose name has to be short. */
  title?: string;
}

export interface TableFilter<T> {
  id: string;
  label: string;
  options: { value: string; label: string }[];
  /** Return true when `row` passes with the given selection (never empty). */
  matches: (row: T, selected: string[]) => boolean;
}

export interface DataTableProps<T> {
  rows: T[];
  columns: Column<T>[];
  rowId: (row: T) => string;

  /** Screen-reader caption. Required — a bare grid of numbers is not self-describing. */
  caption: string;

  // ---- states (docs/06: every data component supports all four) ----
  loading?: boolean;
  /** Provider not connected. Takes precedence over empty — the data is not missing, the connection is. */
  notConnected?: { provider: string; onConnect?: () => void };
  /** Data is past its refresh window. Shown, never silently served as fresh. */
  stale?: { since: string; onRefresh?: () => void };

  // ---- toolbar ----
  searchPlaceholder?: string;
  filters?: TableFilter<T>[];
  /** Right-aligned toolbar slot — export, run, etc. */
  actions?: ReactNode;
  /** localStorage key for the density preference. Omit to not persist. */
  densityKey?: string;
  defaultDensity?: Density;

  // ---- selection ----
  selectable?: boolean;
  /** Rendered in the bulk bar when rows are selected. */
  bulkActions?: (selected: T[], clear: () => void) => ReactNode;

  // ---- empty ----
  emptyTitle?: string;
  emptyBody?: string;
  emptyAction?: ReactNode;

  // ---- rows ----
  onRowClick?: (row: T) => void;
  /** Provenance per row. Renders a SourceBadge column — the data-honesty rule. */
  rowSource?: (row: T) => SourceId | undefined;
  /** Mobile card title. Defaults to the first visible column's cell. */
  mobileTitle?: (row: T) => ReactNode;

  className?: string;
}

export function DataTable<T>({
  rows, columns, rowId, caption,
  loading = false, notConnected, stale,
  searchPlaceholder = "Search", filters = [], actions,
  densityKey, defaultDensity = "default",
  selectable = false, bulkActions,
  emptyTitle = "Nothing here yet",
  emptyBody = "Once data arrives it will show up in this table.",
  emptyAction,
  onRowClick, rowSource, mobileTitle,
  className,
}: DataTableProps<T>) {
  const searchId = useId();

  const [rawSearch, setRawSearch] = useState("");
  const search = useDebouncedValue(rawSearch, 300);
  const [sort, setSort] = useState<SortState | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [hidden, setHidden] = useState<Set<string>>(
    () => new Set(columns.filter((c) => c.defaultHidden).map((c) => c.id)),
  );
  const [active, setActive] = useState<Record<string, string[]>>({});

  const [density, setDensity] = usePersistentState<Density>(
    densityKey ? `vantage.table.${densityKey}.density` : null,
    defaultDensity,
    (raw) => (raw in DENSITY ? (raw as Density) : undefined),
  );

  const visible = useMemo(
    () => columns.filter((c) => !hidden.has(c.id)),
    [columns, hidden],
  );

  const activeFilterCount = useMemo(
    () => Object.values(active).filter((v) => v.length > 0).length,
    [active],
  );
  const isFiltered = activeFilterCount > 0 || search.trim() !== "";

  // ---- filter -> search -> sort ----
  const processed = useMemo(() => {
    let out = rows;

    for (const f of filters) {
      const sel = active[f.id];
      if (sel && sel.length > 0) out = out.filter((r) => f.matches(r, sel));
    }

    const q = search.trim().toLowerCase();
    if (q) {
      // Search spans only columns that expose a `value`, and only visible ones —
      // matching a hidden column would produce a row with no visible reason to
      // be there.
      const searchable = visible.filter((c) => c.value);
      out = out.filter((r) =>
        searchable.some((c) => {
          const v = c.value?.(r);
          return v != null && String(v).toLowerCase().includes(q);
        }),
      );
    }

    if (sort) {
      const col = columns.find((c) => c.id === sort.columnId);
      if (col?.value) {
        // slice() first — never sort the caller's array in place
        out = out.slice().sort((a, b) =>
          compareValues(col.value!(a), col.value!(b), sort.direction),
        );
      }
    }
    return out;
  }, [rows, filters, active, search, visible, sort, columns]);

  const toggleSort = useCallback((columnId: string) => {
    setSort((cur) => {
      if (cur?.columnId !== columnId) return { columnId, direction: "asc" };
      if (cur.direction === "asc") return { columnId, direction: "desc" };
      return null; // third click clears — back to source order
    });
  }, []);

  const clearFilters = useCallback(() => {
    setActive({});
    setRawSearch("");
  }, []);

  const toggleRow = useCallback((id: string) => {
    setSelected((cur) => {
      const next = new Set(cur);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const pageIds = processed.map(rowId);
  const allSelected = pageIds.length > 0 && pageIds.every((id) => selected.has(id));
  const someSelected = pageIds.some((id) => selected.has(id)) && !allSelected;
  const selectedRows = processed.filter((r) => selected.has(rowId(r)));
  const clearSelection = useCallback(() => setSelected(new Set()), []);

  const d = DENSITY[density];

  const align = (c: Column<T>) =>
    c.numeric ? "text-right tabular-nums font-mono" : "text-left";

  return (
    <div
      className={cn("flex flex-col rounded-xl border border-line bg-card", className)}
    >
      {/* ---------------- toolbar ---------------- */}
      <div className="flex flex-wrap items-center gap-2 border-b border-line px-3 py-2.5">
        <div className="relative min-w-[160px] flex-1">
          <actionIcon.view
            size={ICON_SIZE.dense}
            aria-hidden
            className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-3"
          />
          <input
            id={searchId}
            type="search"
            value={rawSearch}
            onChange={(e) => setRawSearch(e.target.value)}
            placeholder={searchPlaceholder}
            aria-label={searchPlaceholder}
            className={cn(
              "h-8 w-full rounded-md border border-line-field bg-surface-inset pl-8 pr-2.5",
              "text-small text-ink placeholder:text-ink-3",
              "focus-visible:outline-none focus-visible:shadow-focus",
            )}
          />
        </div>

        {filters.length > 0 && (
          <Popover
            label="Filter"
            ariaLabel="Filter rows"
            badge={activeFilterCount}
            icon={<actionIcon.view size={ICON_SIZE.dense} aria-hidden />}
          >
            {(close) => (
              <FilterPanel
                filters={filters}
                active={active}
                onApply={(next) => { setActive(next); close(); }}
                onClearAll={() => { setActive({}); close(); }}
              />
            )}
          </Popover>
        )}

        <Popover label="Columns" ariaLabel="Show or hide columns" align="end">
          {() => (
            <div className="flex flex-col">
              {columns.map((c) => (
                <CheckRow
                  key={c.id}
                  checked={!hidden.has(c.id)}
                  disabled={c.locked}
                  disabledReason="This column identifies the row and cannot be hidden"
                  label={c.header}
                  onChange={() =>
                    setHidden((cur) => {
                      const next = new Set(cur);
                      if (next.has(c.id)) next.delete(c.id);
                      else next.add(c.id);
                      return next;
                    })
                  }
                />
              ))}
            </div>
          )}
        </Popover>

        <div
          role="radiogroup"
          aria-label="Row density"
          // Interactive control -> border-line-field (3.37:1), not -strong (1.50:1).
          className="hidden items-center rounded-md border border-line-field p-0.5 sm:flex"
        >
          {(Object.keys(DENSITY) as Density[]).map((key) => (
            <button
              key={key}
              type="button"
              role="radio"
              aria-checked={density === key}
              onClick={() => setDensity(key)}
              className={cn(
                "rounded px-2 py-1 text-meta font-medium transition-colors duration-fast",
                "focus-visible:outline-none focus-visible:shadow-focus",
                density === key
                  ? "bg-teal text-ink-on-teal"
                  : "text-ink-3 hover:text-ink",
              )}
            >
              {DENSITY[key].label}
            </button>
          ))}
        </div>

        {stale && (
          <span className="inline-flex items-center gap-1.5 rounded bg-amber-soft px-2 py-1 text-micro font-bold uppercase tracking-[0.04em] text-amber-ink">
            Stale · {stale.since}
            {stale.onRefresh && (
              <button
                type="button"
                onClick={stale.onRefresh}
                aria-label="Refresh now"
                className="rounded focus-visible:outline-none focus-visible:shadow-focus"
              >
                <actionIcon.refresh size={ICON_SIZE.dense} aria-hidden />
              </button>
            )}
          </span>
        )}

        {actions && <div className="ml-auto flex items-center gap-2">{actions}</div>}
      </div>

      {/* ---------------- bulk bar ---------------- */}
      {selectable && selected.size > 0 && (
        <div className="flex flex-wrap items-center gap-3 border-b border-line bg-teal/10 px-3 py-2">
          <span className="text-small font-semibold text-ink">
            <span className="font-mono tabular-nums">{selected.size}</span>{" "}
            {selected.size === 1 ? "row" : "rows"} selected
          </span>
          <button
            type="button"
            onClick={clearSelection}
            className="rounded text-meta font-bold text-teal-ink hover:text-teal-hover focus-visible:outline-none focus-visible:shadow-focus"
          >
            Clear
          </button>
          <div className="ml-auto flex flex-wrap items-center gap-2">
            {bulkActions?.(selectedRows, clearSelection)}
          </div>
        </div>
      )}

      {/* ---------------- body ---------------- */}
      {loading ? (
        <TableSkeleton columns={visible.length} density={density} />
      ) : notConnected ? (
        <StateBlock
          title={`${notConnected.provider} is not connected`}
          body="This table has no data because the source is not connected — not because there is nothing to show. Connect it to populate this view."
          action={
            notConnected.onConnect && (
              <Button size="sm" onClick={notConnected.onConnect}>
                Connect {notConnected.provider}
              </Button>
            )
          }
        />
      ) : processed.length === 0 ? (
        isFiltered ? (
          <StateBlock
            title="No rows match"
            body={`${rows.length} ${rows.length === 1 ? "row is" : "rows are"} hidden by the current search and filters.`}
            action={
              <Button size="sm" variant="secondary" onClick={clearFilters}>
                Clear filters
              </Button>
            }
          />
        ) : (
          <StateBlock title={emptyTitle} body={emptyBody} action={emptyAction} />
        )
      ) : (
        <>
          {/* ---- table (md and up) ---- */}
          <div className="hidden max-h-[70vh] overflow-auto md:block">
            <table className="w-full border-collapse">
              <caption className="sr-only">{caption}</caption>
              <thead className="sticky top-0 z-10 bg-card">
                <tr className="border-b border-line-strong">
                  {selectable && (
                    <th scope="col" className={cn("w-9 pl-3", d.head)}>
                      <SelectBox
                        checked={allSelected}
                        indeterminate={someSelected}
                        onChange={() =>
                          setSelected(allSelected ? new Set() : new Set(pageIds))
                        }
                        label={allSelected ? "Deselect all rows" : "Select all rows"}
                      />
                    </th>
                  )}
                  {visible.map((c) => {
                    const sorted = sort?.columnId === c.id ? sort.direction : null;
                    return (
                      <th
                        key={c.id}
                        scope="col"
                        title={c.title}
                        style={c.width ? { width: c.width } : undefined}
                        aria-sort={
                          sorted ? (sorted === "asc" ? "ascending" : "descending") : "none"
                        }
                        className={cn(
                          "px-3 text-micro font-bold uppercase tracking-[0.06em] text-ink-3",
                          d.head, align(c),
                        )}
                      >
                        {c.value ? (
                          <button
                            type="button"
                            onClick={() => toggleSort(c.id)}
                            className={cn(
                              "inline-flex items-center gap-1 rounded transition-colors duration-fast",
                              "hover:text-ink focus-visible:outline-none focus-visible:shadow-focus",
                              c.numeric && "flex-row-reverse",
                              sorted && "text-ink",
                            )}
                          >
                            {c.header}
                            <SortGlyph direction={sorted} />
                          </button>
                        ) : (
                          c.header
                        )}
                      </th>
                    );
                  })}
                  {rowSource && (
                    <th scope="col" className={cn("px-3 text-micro font-bold uppercase tracking-[0.06em] text-ink-3", d.head)}>
                      Source
                    </th>
                  )}
                </tr>
              </thead>
              <tbody>
                {processed.map((row, i) => {
                  const id = rowId(row);
                  const isSelected = selected.has(id);
                  const src = rowSource?.(row);
                  return (
                    <tr
                      key={id}
                      onClick={onRowClick ? () => onRowClick(row) : undefined}
                      className={cn(
                        "border-b border-line-subtle transition-colors duration-fast",
                        i % 2 === 1 && "bg-surface-hover",
                        isSelected && "bg-teal/10",
                        onRowClick && "cursor-pointer",
                        // Hover must DEEPEN selection, never replace it.
                        // `hover:bg-surface-subtle` is a neutral grey and, as a
                        // `:hover` rule, outranks the plain `bg-teal/10` on
                        // specificity — so pointing at a selected row wiped its
                        // teal and the row read as deselected under the cursor,
                        // exactly where the user is about to act on it. Keep the
                        // two branches mutually exclusive: a selected row goes
                        // 10% -> 20% teal, an unselected one takes the grey.
                        onRowClick && (isSelected ? "hover:bg-teal/20" : "hover:bg-surface-subtle"),
                      )}
                    >
                      {selectable && (
                        <td className={cn("pl-3", d.cell)} onClick={(e) => e.stopPropagation()}>
                          <SelectBox
                            checked={isSelected}
                            onChange={() => toggleRow(id)}
                            label={`Select row ${id}`}
                          />
                        </td>
                      )}
                      {visible.map((c) => (
                        <td key={c.id} className={cn("px-3 text-ink", d.cell, align(c))}>
                          {c.cell(row)}
                        </td>
                      ))}
                      {rowSource && (
                        <td className={cn("px-3", d.cell)}>
                          {src ? <SourceBadge source={src} size="sm" /> : (
                            <span className="text-ink-3" title="No provenance recorded">—</span>
                          )}
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* ---- cards (below md) ---- */}
          <ul className="flex flex-col md:hidden">
            {processed.map((row) => {
              const id = rowId(row);
              const [first, ...rest] = visible;
              return (
                <li
                  key={id}
                  onClick={onRowClick ? () => onRowClick(row) : undefined}
                  className={cn(
                    "flex flex-col gap-2 border-b border-line-subtle px-4 py-3",
                    onRowClick && "cursor-pointer",
                  )}
                >
                  <div className="flex items-start justify-between gap-3">
                    <span className="min-w-0 text-small font-semibold text-ink">
                      {mobileTitle ? mobileTitle(row) : first ? first.cell(row) : id}
                    </span>
                    {rowSource?.(row) && <SourceBadge source={rowSource(row)!} size="sm" />}
                  </div>
                  <dl className="grid grid-cols-2 gap-x-3 gap-y-1.5">
                    {rest.map((c) => (
                      <div key={c.id} className="flex flex-col gap-0.5">
                        <dt className="text-nano font-bold uppercase tracking-[0.06em] text-ink-3">
                          {c.header}
                        </dt>
                        <dd className={cn("text-meta text-ink", c.numeric && "font-mono tabular-nums")}>
                          {c.cell(row)}
                        </dd>
                      </div>
                    ))}
                  </dl>
                </li>
              );
            })}
          </ul>
        </>
      )}

      {/* ---------------- footer ---------------- */}
      {!loading && !notConnected && (
        <div className="flex flex-wrap items-center gap-3 border-t border-line px-3 py-2 text-meta text-ink-3">
          <span className="font-mono tabular-nums">
            {processed.length === rows.length
              ? `${rows.length} ${rows.length === 1 ? "row" : "rows"}`
              : `${processed.length} of ${rows.length} rows`}
          </span>
          {isFiltered && (
            <button
              type="button"
              onClick={clearFilters}
              className="rounded font-bold text-teal-ink hover:text-teal-hover focus-visible:outline-none focus-visible:shadow-focus"
            >
              Clear filters
            </button>
          )}
          {sort && (
            <span className="ml-auto">
              Sorted by{" "}
              <span className="font-semibold text-ink-2">
                {columns.find((c) => c.id === sort.columnId)?.header}
              </span>{" "}
              {sort.direction === "asc" ? "ascending" : "descending"}
            </span>
          )}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Internals
 * ------------------------------------------------------------------ */

function SortGlyph({ direction }: { direction: SortDirection | null }) {
  if (!direction) {
    return (
      <span aria-hidden className="text-ink-3 opacity-0 transition-opacity group-hover:opacity-100">
        <navIcon.expand size={12} />
      </span>
    );
  }
  return (
    <navIcon.expand
      size={12}
      aria-hidden
      className={cn("transition-transform", direction === "asc" && "rotate-180")}
    />
  );
}

function SelectBox({
  checked, indeterminate = false, onChange, label,
}: { checked: boolean; indeterminate?: boolean; onChange: () => void; label: string }) {
  return (
    <label className="flex cursor-pointer items-center">
      <input
        type="checkbox"
        checked={checked}
        aria-label={label}
        ref={(el) => { if (el) el.indeterminate = indeterminate && !checked; }}
        onChange={onChange}
        className="peer sr-only"
      />
      <span
        aria-hidden
        className={cn(
          "grid size-3.5 place-items-center rounded-sm border transition-colors duration-fast",
          "peer-focus-visible:shadow-focus",
          checked || indeterminate
            ? "border-teal bg-teal text-ink-on-teal"
            : "border-line-field",
        )}
      >
        {checked && (
          <svg viewBox="0 0 10 10" className="size-2.5" fill="none" stroke="currentColor" strokeWidth={2.2}>
            <path d="M1.5 5.2 L4 7.5 L8.5 2.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        )}
        {!checked && indeterminate && <span className="h-0.5 w-2 rounded-full bg-current" />}
      </span>
    </label>
  );
}

/**
 * Filter panel. Selections are staged locally and only committed on Apply, so
 * a multi-select does not re-filter the table on every checkbox — which on a
 * long list reads as the page fighting you.
 */
function FilterPanel<T>({
  filters, active, onApply, onClearAll,
}: {
  filters: TableFilter<T>[];
  active: Record<string, string[]>;
  onApply: (next: Record<string, string[]>) => void;
  onClearAll: () => void;
}) {
  const [draft, setDraft] = useState<Record<string, string[]>>(active);

  const toggle = (filterId: string, value: string) =>
    setDraft((cur) => {
      const sel = cur[filterId] ?? [];
      return {
        ...cur,
        [filterId]: sel.includes(value) ? sel.filter((v) => v !== value) : [...sel, value],
      };
    });

  return (
    <div className="flex max-h-[384px] w-[256px] flex-col">
      <div className="flex-1 overflow-y-auto">
        {filters.map((f, i) => (
          <div key={f.id} className={cn(i > 0 && "mt-1 border-t border-line pt-1")}>
            <div className="px-2 py-1.5 text-nano font-bold uppercase tracking-[0.07em] text-ink-3">
              {f.label}
            </div>
            {f.options.map((o) => (
              <CheckRow
                key={o.value}
                checked={(draft[f.id] ?? []).includes(o.value)}
                onChange={() => toggle(f.id, o.value)}
                label={o.label}
              />
            ))}
          </div>
        ))}
      </div>
      <div className="mt-1 flex items-center gap-2 border-t border-line px-2 py-2">
        <Button size="sm" variant="ghost" onClick={onClearAll}>Clear all</Button>
        <Button size="sm" className="ml-auto" onClick={() => onApply(draft)}>Apply</Button>
      </div>
    </div>
  );
}

function StateBlock({
  title, body, action,
}: { title: string; body: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-2 px-6 py-14 text-center">
      <p className="text-small font-bold text-ink">{title}</p>
      <p className="max-w-[42ch] text-meta leading-relaxed text-ink-2">{body}</p>
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}

function TableSkeleton({ columns, density }: { columns: number; density: Density }) {
  const rowH = density === "compact" ? "h-6" : density === "comfortable" ? "h-10" : "h-8";
  return (
    <div className="flex flex-col gap-px p-3" aria-busy="true" aria-live="polite">
      <span className="sr-only">Loading rows</span>
      {Array.from({ length: 6 }).map((_, r) => (
        <div key={r} className="flex gap-3">
          {Array.from({ length: columns }).map((_, c) => (
            <div
              key={c}
              className={cn(
                "flex-1 animate-pulse rounded bg-surface-inset motion-reduce:animate-none",
                rowH,
              )}
              style={{ animationDelay: `${(r * columns + c) * 20}ms` }}
            />
          ))}
        </div>
      ))}
    </div>
  );
}
