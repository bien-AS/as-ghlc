"use client";

import { useCallback, useEffect, useId, useRef, useState } from "react";
import { cn } from "../../lib/cn";
import { navIcon, ICON_SIZE, type Severity } from "../../lib/icons";
import { useDismissable } from "../../lib/use-table";
import { SeverityDot } from "../pills";

/**
 * NotificationBell — the alert feed in the app-shell chrome.
 *
 * WHY THE TRIGGER IS HAND-ROLLED INSTEAD OF USING `Popover`
 * The panel below is Popover's panel, class for class, and dismissal is
 * Popover's own `useDismissable` — none of that is reinvented. The TRIGGER is,
 * for two reasons that Popover has no way to express: its `badge` prop is a
 * `number`, so it cannot render the capped "9+", and it always appends a
 * chevron, which on a bell reads as a second affordance. Changing Popover to
 * suit one caller would push both concerns into every filter button in the app.
 *
 * WHY THE COUNT IS CAPPED AT 9+ FOR DISPLAY BUT NOT FOR ARIA
 * The cap is a layout rule — a three-digit badge blows out the bell's corner
 * and the exact number stops being actionable past a handful anyway. It is not
 * an information rule, so `aria-label` carries the true count: a screen-reader
 * user gets "Notifications, 47 unread", not "9 plus".
 *
 * WHY THE BADGE TONE IS NOT ALWAYS RED
 * Brand red is RESERVED in this system for critical alerts and destructive
 * confirmations; spending it on "you have 3 unread" leaves nothing louder for
 * the alert that matters. The badge is teal until at least one unread item is
 * `critical`. The count is printed either way, so tone is never the only
 * encoding — same rule the rank pins and status pills follow.
 *
 * WHY ROWS ARE SPANS INSIDE A BUTTON
 * A `<div>` inside a `<button>` is invalid HTML and browsers reparent it,
 * which breaks the row layout in ways that only show up in one engine. The row
 * is built from spans with flex/block display instead.
 *
 * WHY THE UNREAD ROW HAS A RAIL AND NOT A TINT
 * Not a Tailwind limitation — an accessibility one. `bg-teal/5` does compile
 * now (`hexToken` in tailwind.config.ts wraps hex tokens in `color-mix()`, so
 * they carry a real alpha channel), but a 5% wash is roughly a 1.03:1 shift
 * against the card ground: invisible to a colourblind reader, and the first
 * thing lost to a low-quality display or a bright room. Unread is carried by a
 * solid `bg-teal` rail — the same device the Sidebar uses for the active row —
 * plus a bold title and an sr-only word, so the state never rests on hue alone.
 * That is the house rule, not a workaround: colour is never the only encoding.
 *
 * TIMESTAMPS ARE PRE-FORMATTED BY THE CALLER. The kit owns no relative-time
 * formatter and inventing one here would put a second, drifting definition of
 * "12m ago" in the codebase. `timestamp` is the display string; pass `datetime`
 * as ISO and it becomes the machine-readable `<time>` value.
 */

/** Display cap. Anything above renders as "9+"; aria still says the real number. */
export const NOTIFICATION_BADGE_CAP = 9;

/**
 * Named `AppNotification` rather than `Notification` on purpose: `Notification`
 * is a DOM global, and a same-named local type makes every `new Notification()`
 * and every `lib.dom` reference in review ambiguous.
 */
export interface AppNotification {
  id: string;
  title: string;
  body?: string;
  severity: Severity;
  /** Display string, already formatted — "12m ago", "Sep 2, 09:14". */
  timestamp: string;
  /** ISO instant for the `<time dateTime>` attribute. */
  datetime?: string;
  read?: boolean;
}

export interface NotificationBellProps {
  notifications: AppNotification[];
  onMarkAllRead?: () => void;
  /** Rows become buttons when provided. Selecting one closes the panel. */
  onSelect?: (id: string) => void;
  /** Footer action when the feed is longer than `maxVisible`. */
  onViewAll?: () => void;
  /** Rows rendered before the "N more" line. */
  maxVisible?: number;
  align?: "start" | "end";
  emptyTitle?: string;
  emptyBody?: string;
  className?: string;
}

const SEVERITY_WORD: Record<Severity, string> = {
  info: "Info",
  moderate: "Moderate",
  critical: "Critical",
};

export function NotificationBell({
  notifications,
  onMarkAllRead,
  onSelect,
  onViewAll,
  maxVisible = 6,
  align = "end",
  emptyTitle = "You are all caught up",
  emptyBody = "Anomalies, stalled campaigns and delivery alerts land here as they are detected.",
  className,
}: NotificationBellProps) {
  const panelId = useId();
  const [open, setOpen] = useState(false);

  const triggerRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  const close = useCallback(() => setOpen(false), []);
  // Wrapper ref, not panel ref: a pointerdown on the trigger must count as
  // INSIDE, or the dismiss fires first and the click then reopens the panel.
  const wrapRef = useDismissable<HTMLDivElement>(open, close);

  const unread = notifications.reduce((n, item) => (item.read === true ? n : n + 1), 0);
  const hasCritical = notifications.some((item) => item.read !== true && item.severity === "critical");
  const badgeText = unread > NOTIFICATION_BADGE_CAP ? `${NOTIFICATION_BADGE_CAP}+` : String(unread);

  const visible = notifications.slice(0, maxVisible);
  const overflow = notifications.length - visible.length;

  /* ---- move focus in on open, hand it back to the bell on close ---- */
  useEffect(() => {
    if (!open) return;
    const first = panelRef.current?.querySelector<HTMLElement>(
      "button:not([disabled]), [href], [tabindex]:not([tabindex='-1'])",
    );
    first?.focus();
    return () => {
      const trigger = triggerRef.current;
      // Guard `isConnected`: this cleanup also runs on unmount, where the
      // trigger is already gone and focusing it would be a silent no-op that
      // leaves focus on <body>.
      if (trigger != null && trigger.isConnected) trigger.focus();
    };
  }, [open]);

  return (
    <div ref={wrapRef} className={cn("relative", className)}>
      <button
        ref={triggerRef}
        type="button"
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-controls={open ? panelId : undefined}
        aria-label={unread === 0 ? "Notifications, none unread" : `Notifications, ${unread} unread`}
        onClick={() => setOpen((current) => !current)}
        className={cn(
          "relative inline-flex size-8 items-center justify-center rounded-md border border-line-field",
          "transition-colors duration-fast ease-standard",
          "focus-visible:outline-none focus-visible:shadow-focus",
          // An OPEN trigger already sits on surface-hover, so it had no hover
          // state at all — the control whose state matters most was the one
          // with no affordance. The move is on the BORDER, not the fill: in
          // LIGHT the surface ramp is pinned between #FFFFFF and the fixed grey
          // --border-input, so a darker fill drops the control's own boundary
          // to 2.99 and fails WCAG 1.4.11. Darkening the border raises it
          // instead — 3.23 -> 4.41 light, 3.61 -> 4.51 dark.
          open
            ? "bg-surface-hover text-ink hover:border-line-field-hover"
            : "bg-card text-ink-2 hover:bg-surface-hover hover:text-ink",
        )}
      >
        <navIcon.bell size={ICON_SIZE.dense} aria-hidden />
        {unread > 0 && (
          // aria-hidden: the count is already in the button's accessible name,
          // uncapped. Exposing this too would announce it twice, once wrong.
          <span
            aria-hidden
            className={cn(
              "absolute -right-1 -top-1 grid min-w-[1.0625rem] place-items-center rounded-full px-1",
              "font-mono text-nano font-bold leading-[1.0625rem] tabular-nums",
              hasCritical ? "bg-danger text-white" : "bg-teal text-ink-on-teal",
            )}
          >
            {badgeText}
          </span>
        )}
      </button>

      {open && (
        <div
          ref={panelRef}
          id={panelId}
          role="dialog"
          aria-label="Notifications"
          className={cn(
            // Elevation is legal on a popover. Cards stay flat.
            /* px, not rem: this system sets `html { font-size: 14px }`, so every rem in
               the kit is 14px and a "21rem" panel silently renders at 294px, not
               336px. A notification list is sized by the text it has to hold, so
               it is pinned in px and does not rescale with the root size. */
            "absolute z-50 mt-1.5 w-[336px] max-w-[calc(100vw-32px)] overflow-hidden",
            "rounded-lg border border-line bg-card shadow-md",
            align === "end" ? "right-0" : "left-0",
          )}
        >
          <div className="flex items-center gap-2 border-b border-line px-3 py-2">
            <span className="text-small font-bold text-ink">Notifications</span>
            {unread > 0 && (
              <span className="font-mono text-nano tabular-nums text-ink-3">{unread} unread</span>
            )}
            <button
              type="button"
              // Present but disabled at zero, rather than absent: a control that
              // appears and disappears is harder to aim at than one that greys.
              disabled={unread === 0 || onMarkAllRead == null}
              onClick={() => onMarkAllRead?.()}
              className={cn(
                "ml-auto rounded text-meta font-bold transition-colors duration-fast",
                "focus-visible:outline-none focus-visible:shadow-focus",
                "text-teal-ink hover:text-teal-hover",
                "disabled:pointer-events-none disabled:text-ink-4",
              )}
            >
              Mark all read
            </button>
          </div>

          {notifications.length === 0 ? (
            <div className="flex flex-col items-center gap-1.5 px-6 py-10 text-center">
              <p className="text-small font-bold text-ink">{emptyTitle}</p>
              <p className="max-w-[34ch] text-meta leading-relaxed text-ink-2">{emptyBody}</p>
            </div>
          ) : (
            <ul className="max-h-[336px] overflow-y-auto">
              {visible.map((item) => (
                <li key={item.id} className="border-b border-line-subtle last:border-b-0">
                  <Row
                    item={item}
                    onSelect={
                      onSelect
                        ? () => { onSelect(item.id); setOpen(false); }
                        : undefined
                    }
                  />
                </li>
              ))}
            </ul>
          )}

          {(overflow > 0 || onViewAll) && (
            <div className="flex items-center gap-2 border-t border-line px-3 py-2 text-meta text-ink-3">
              {overflow > 0 && (
                <span>
                  <span className="font-mono tabular-nums">{overflow}</span> more
                </span>
              )}
              {onViewAll && (
                <button
                  type="button"
                  onClick={() => { onViewAll(); setOpen(false); }}
                  className={cn(
                    "ml-auto rounded font-bold text-teal-ink transition-colors duration-fast",
                    "hover:text-teal-hover focus-visible:outline-none focus-visible:shadow-focus",
                  )}
                >
                  View all
                </button>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Row({ item, onSelect }: { item: AppNotification; onSelect?: () => void }) {
  const unread = item.read !== true;

  const content = (
    <>
      {/* Label suppressed on the dot to keep the row one line high; the word is
          restored below for screen readers, because glyph shape and hue are not
          an accessible encoding on their own. */}
      <SeverityDot
        severity={item.severity}
        withLabel={false}
        className="mt-0.5 shrink-0"
        title={SEVERITY_WORD[item.severity]}
      />
      <span className="min-w-0 flex-1">
        <span className="flex items-baseline gap-2">
          <span
            className={cn(
              // line-clamp-2, not truncate: a notification title is a sentence
              // ("Superior Grouting dropped out of the pack"), and one line at
              // this width cuts it at the client name — losing both what
              // happened and which client it happened to. Two lines is still a
              // bounded row.
              "min-w-0 flex-1 line-clamp-2 text-small",
              unread ? "font-bold text-ink" : "font-medium text-ink-2",
            )}
          >
            {item.title}
          </span>
          <time
            dateTime={item.datetime}
            className="shrink-0 font-mono text-nano tabular-nums text-ink-3"
          >
            {item.timestamp}
          </time>
        </span>
        {item.body != null && (
          <span className="mt-0.5 block text-meta leading-relaxed text-ink-2">{item.body}</span>
        )}
        <span className="sr-only">
          {SEVERITY_WORD[item.severity]} severity. {unread ? "Unread." : "Read."}
        </span>
      </span>
      {unread && (
        <span aria-hidden className="absolute inset-y-1.5 left-0 w-[3px] rounded-r bg-teal" />
      )}
    </>
  );

  const shape = "relative flex w-full items-start gap-2.5 py-2.5 pl-3.5 pr-3 text-left";

  if (!onSelect) {
    return <span className={cn(shape)}>{content}</span>;
  }
  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        shape,
        "transition-colors duration-fast ease-standard hover:bg-surface-hover",
        "focus-visible:outline-none focus-visible:shadow-focus",
      )}
    >
      {content}
    </button>
  );
}
