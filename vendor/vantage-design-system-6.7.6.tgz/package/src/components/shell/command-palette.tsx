"use client";

import {
  useCallback, useEffect, useId, useMemo, useRef, useState,
  type KeyboardEvent as ReactKeyboardEvent, type ReactNode,
} from "react";
import { cn } from "../../lib/cn";
import { useDismissable } from "../../lib/use-table";

/**
 * CommandPalette — the client switcher and global nav (Cmd-K / Ctrl-K).
 *
 * Anatomy is the Baptist app-shell one: one input, grouped results, arrow keys
 * to move, Enter to run. Six behaviours here are correctness rather than
 * styling, and each one is here because the obvious version breaks:
 *
 * 1. SCOPE-GATED ROWS ARE FILTERED OUT, NOT DIMMED. The Sidebar dims a
 *    scope-gated module and explains why, because a sidebar is a map of the
 *    app. A palette is not a map — every row it lists is one Enter away from
 *    running. A dimmed row inside a keyboard list is a trap: it still takes an
 *    index, arrow keys still land on it, and Enter does nothing with no
 *    explanation. So `requiresScope` rows are removed from the list entirely
 *    and the footer reports how many were withheld and what unlocks them.
 *
 * 2. `type="text"`, NOT `type="search"`. WebKit and Chromium give a search
 *    input a built-in Escape handler that clears the field and consumes the
 *    event. On a search input, the first Escape empties the query instead of
 *    closing the palette, so the operator has to press it twice and the
 *    dismiss contract silently differs per browser.
 *
 * 3. THE HOTKEY LISTENER LIVES OUTSIDE THE `open` GUARD. The component renders
 *    `null` when closed but still has to hear Cmd-K, so the listener is bound
 *    unconditionally and only the render short-circuits.
 *
 * 4. HOVER USES pointermove, NOT pointerenter. Arrow-key navigation scrolls the
 *    list under a stationary cursor. `pointerenter`/`mouseover` fire on that
 *    scroll — the row that slid under the mouse steals `activeIndex` back and
 *    the keyboard appears to jump. `pointermove` only fires on real movement.
 *
 * 5. OPTIONS ARE NOT FOCUSABLE. This is the aria-activedescendant combobox
 *    pattern: focus stays in the input, and the active option is named by id.
 *    Options therefore cancel their own pointerdown, because the default would
 *    blur the input and the next arrow key would go nowhere.
 *
 * 6. FOCUS IS RESTORED TO WHATEVER OPENED IT. Cmd-K can be pressed from
 *    anywhere; dropping focus onto <body> on close would send the next Tab back
 *    to the top of the document.
 *
 * STATED TRADEOFF, same as Popover: this does not render through a portal —
 * the kit has no react-dom import anywhere and this does not introduce one.
 * `position: fixed` resolves against the viewport unless an ancestor carries
 * `transform`, `filter`, `perspective` or `container-type`, which would make
 * the overlay position against that ancestor instead. Mount this at the app
 * shell root, not inside a transformed panel.
 */

export interface CommandItem {
  id: string;
  label: string;
  /** Right-aligned supporting text — a shortcut, a client's domain, a count. */
  hint?: string;
  icon?: ReactNode;
  /** Extra strings the query is matched against but which are never shown. */
  keywords?: string[];
  /** A per-module row: listed only while a client is scoped. */
  requiresScope?: boolean;
}

export interface CommandGroup {
  id: string;
  label: string;
  items: CommandItem[];
  /** Whole group is per-module: listed only while a client is scoped. */
  requiresScope?: boolean;
}

export interface CommandPaletteProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  groups: CommandGroup[];
  onSelect: (itemId: string) => void;
  /** A client is selected. False hides every `requiresScope` group and item. */
  scoped: boolean;
  placeholder?: string;
  /** Accessible name for the dialog and the listbox. */
  title?: string;
  className?: string;
}

/** Case-insensitive substring over label, hint and hidden keywords. */
function matchesQuery(item: CommandItem, q: string): boolean {
  if (item.label.toLowerCase().includes(q)) return true;
  if (item.hint != null && item.hint.toLowerCase().includes(q)) return true;
  for (const k of item.keywords ?? []) {
    if (k.toLowerCase().includes(q)) return true;
  }
  return false;
}

export function CommandPalette({
  open, onOpenChange, groups, onSelect, scoped,
  placeholder = "Search clients, modules and actions",
  title = "Command palette",
  className,
}: CommandPaletteProps) {
  const baseId = useId();
  const listId = `${baseId}-list`;

  const [query, setQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);

  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  const close = useCallback(() => onOpenChange(false), [onOpenChange]);
  const panelRef = useDismissable<HTMLDivElement>(open, close);

  /* ---- filter, then number the survivors so a group header never costs an
         index and Enter always lands on the row the operator can see ---- */
  const rendered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let index = 0;
    const out: { id: string; label: string; rows: { item: CommandItem; index: number }[] }[] = [];

    for (const group of groups) {
      if (group.requiresScope === true && !scoped) continue;
      const rows: { item: CommandItem; index: number }[] = [];
      for (const item of group.items) {
        if (item.requiresScope === true && !scoped) continue;
        if (q !== "" && !matchesQuery(item, q)) continue;
        rows.push({ item, index: index++ });
      }
      if (rows.length > 0) out.push({ id: group.id, label: group.label, rows });
    }
    return out;
  }, [groups, scoped, query]);

  const flat = useMemo(
    () => rendered.flatMap((g) => g.rows.map((r) => r.item)),
    [rendered],
  );

  /** How many rows the unscoped view is holding back, for the footer. */
  const withheld = useMemo(() => {
    if (scoped) return 0;
    let n = 0;
    for (const group of groups) {
      if (group.requiresScope === true) { n += group.items.length; continue; }
      for (const item of group.items) if (item.requiresScope === true) n += 1;
    }
    return n;
  }, [groups, scoped]);

  // Clamp rather than trust: the list can shrink under a stale index between
  // a keystroke and the next render.
  const active = flat.length === 0 ? -1 : Math.min(activeIndex, flat.length - 1);
  const activeRow = active >= 0 ? flat[active] : undefined;

  /* ---- Cmd-K. Bound whether or not the palette is open. ---- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!(e.metaKey || e.ctrlKey) || e.altKey) return;
      if (e.key.toLowerCase() !== "k") return;
      e.preventDefault();
      onOpenChange(!open);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onOpenChange]);

  /* ---- open: reset, take focus, and remember where to give it back ---- */
  useEffect(() => {
    if (!open) return;
    setQuery("");
    setActiveIndex(0);
    const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    inputRef.current?.focus();
    return () => {
      if (previous != null && previous.isConnected) previous.focus();
    };
  }, [open]);

  /* ---- a new query starts from the top ---- */
  useEffect(() => { setActiveIndex(0); }, [query, scoped]);

  /* ---- keep the active option on screen. `block: "nearest"` scrolls the
         minimum amount, so paging down does not recentre the whole list. ---- */
  useEffect(() => {
    if (!open) return;
    const el = listRef.current?.querySelector<HTMLElement>('[data-active="true"]');
    el?.scrollIntoView({ block: "nearest" });
  }, [open, active, query]);

  const move = useCallback((delta: number) => {
    setActiveIndex((current) => {
      const count = flat.length;
      if (count === 0) return 0;
      const from = Math.min(current, count - 1);
      return (from + delta + count) % count;
    });
  }, [flat.length]);

  const choose = useCallback((itemId: string) => {
    onSelect(itemId);
    onOpenChange(false);
  }, [onSelect, onOpenChange]);

  const onInputKeyDown = (e: ReactKeyboardEvent<HTMLInputElement>) => {
    switch (e.key) {
      case "ArrowDown": e.preventDefault(); move(1); break;
      case "ArrowUp":   e.preventDefault(); move(-1); break;
      case "Home":      e.preventDefault(); setActiveIndex(0); break;
      case "End":       e.preventDefault(); setActiveIndex(Math.max(0, flat.length - 1)); break;
      case "Enter": {
        e.preventDefault();
        const row = flat[active];
        if (row) choose(row.id);
        break;
      }
      // Focus trap. The input is the only focusable node in the panel — options
      // are addressed by aria-activedescendant — so Tab has nowhere legitimate
      // to go and would otherwise escape to the page behind the scrim.
      case "Tab": e.preventDefault(); break;
      default: break;
    }
  };

  if (!open) return null;

  return (
    <div
      className={cn(
        "fixed inset-0 z-[var(--z-modal-scrim)] flex items-start justify-center",
        "bg-[var(--scrim-modal)] px-4 pb-4 pt-[12vh]",
        className,
      )}
    >
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={cn(
          "flex max-h-[68vh] w-full max-w-[576px] flex-col overflow-hidden",
          // Elevation is legal here: the AS system reserves shadow for
          // popovers, modals and overlays. Cards stay flat.
          "rounded-2xl border border-line bg-card shadow-lg",
        )}
      >
        {/* ---------------- query ---------------- */}
        <div className="flex items-center gap-3 border-b border-line px-4">
          <input
            ref={inputRef}
            // Deliberately not type="search" — see note 2 in the header.
            type="text"
            role="combobox"
            aria-expanded={true}
            aria-controls={listId}
            aria-autocomplete="list"
            aria-activedescendant={activeRow ? `${baseId}-opt-${active}` : undefined}
            aria-label={placeholder}
            autoComplete="off"
            spellCheck={false}
            value={query}
            placeholder={placeholder}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={onInputKeyDown}
            className={cn(
              "h-12 min-w-0 flex-1 bg-transparent text-body text-ink",
              "outline-none placeholder:text-ink-3",
            )}
          />
          <Keys>esc</Keys>
        </div>

        {/* ---------------- results ---------------- */}
        <div
          ref={listRef}
          id={listId}
          role="listbox"
          aria-label={title}
          className="min-h-0 flex-1 overflow-y-auto p-1.5"
        >
          {rendered.length === 0 ? (
            <div role="presentation" className="flex flex-col items-center gap-1.5 px-6 py-12 text-center">
              <p className="text-small font-bold text-ink">No matches</p>
              <p className="max-w-[38ch] text-meta leading-relaxed text-ink-2">
                {query.trim() === ""
                  ? "There is nothing to run from here yet."
                  : `Nothing matches “${query.trim()}”. Try a client name, a module, or part of an action.`}
              </p>
            </div>
          ) : (
            rendered.map((group) => {
              const headerId = `${baseId}-grp-${group.id}`;
              return (
                <div key={group.id} role="group" aria-labelledby={headerId} className="pb-1 last:pb-0">
                  <div
                    id={headerId}
                    className="px-2.5 pb-1 pt-2 text-nano font-bold uppercase tracking-[0.07em] text-ink-3"
                  >
                    {group.label}
                  </div>
                  {group.rows.map(({ item, index }) => {
                    const isActive = index === active;
                    return (
                      <div
                        key={item.id}
                        id={`${baseId}-opt-${index}`}
                        role="option"
                        aria-selected={isActive}
                        data-active={isActive ? "true" : undefined}
                        // See note 4: movement, not entry.
                        onPointerMove={() => setActiveIndex(index)}
                        // See note 5: keep focus in the input.
                        onPointerDown={(e) => e.preventDefault()}
                        onClick={() => choose(item.id)}
                        className={cn(
                          "flex cursor-pointer items-center gap-2.5 rounded-md px-2.5 py-2 text-small",
                          "transition-colors duration-fast ease-standard",
                          isActive ? "bg-surface-hover text-ink" : "text-ink-2",
                        )}
                      >
                        {item.icon && (
                          <span className={cn("flex shrink-0 items-center", isActive ? "text-teal-ink" : "text-ink-3")}>
                            {item.icon}
                          </span>
                        )}
                        <span className="min-w-0 flex-1 truncate">{item.label}</span>
                        {item.hint != null && (
                          <span className="shrink-0 font-mono text-nano tabular-nums text-ink-3">
                            {item.hint}
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })
          )}
        </div>

        {/* ---------------- footer ---------------- */}
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 border-t border-line px-3 py-2 text-meta text-ink-3">
          <span className="font-mono tabular-nums">
            {flat.length} {flat.length === 1 ? "result" : "results"}
          </span>
          {withheld > 0 && (
            <span>
              <span className="font-mono tabular-nums">{withheld}</span> module
              {withheld === 1 ? " command needs" : " commands need"} a selected client
            </span>
          )}
          <span className="ml-auto hidden items-center gap-3 sm:flex">
            <Hint keys="↑↓" label="Navigate" />
            <Hint keys="↵" label="Select" />
            <Hint keys="esc" label="Close" />
          </span>
        </div>

        {/* Result count is not visible to a screen reader as it changes, so it
            is announced. Polite, so it never interrupts the typed characters. */}
        <span role="status" aria-live="polite" className="sr-only">
          {flat.length} {flat.length === 1 ? "result" : "results"} available
        </span>
      </div>
    </div>
  );
}

function Keys({ children }: { children: ReactNode }) {
  return (
    <kbd
      aria-hidden
      className={cn(
        "hidden shrink-0 rounded border border-line-field bg-surface-inset px-1.5 py-0.5",
        "font-mono text-nano font-medium text-ink-3 sm:inline-block",
      )}
    >
      {children}
    </kbd>
  );
}

function Hint({ keys, label }: { keys: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <Keys>{keys}</Keys>
      {label}
    </span>
  );
}
