"use client";

import {
  useId, useMemo, useRef, useState,
  type KeyboardEvent as ReactKeyboardEvent, type ReactNode,
} from "react";
import { cn } from "../../lib/cn";
import { Button } from "../primitives";
import { Popover } from "../popover";

/**
 * DateRangePicker — the range control that sits in every TopBar action slot.
 *
 * WHY THE DATE MATH IS HAND-ROLLED AND LOOKS FUSSY
 * `new Date("2026-09-02")` is parsed as UTC midnight, but every read-back
 * (`getFullYear`, `getMonth`, `getDate`) is local. West of Greenwich that is
 * still the previous day, so a "Last 7 days" range computed the obvious way is
 * off by one for roughly half the planet and correct on the developer's
 * machine. Every date here is therefore built from local components at NOON:
 * local so the round-trip is symmetric, noon so that adding or subtracting
 * days across a DST boundary — where local midnight may not exist — cannot
 * slide the result into the adjacent day.
 *
 * WHY THE RESOLVED RANGE IS ALWAYS PRINTED
 * "Last 28 days" is not a date. Two people reading the same dashboard on
 * different days, or one person comparing a chart against an exported CSV,
 * need the actual endpoints. The preset name is a shortcut, never the record —
 * so the trigger prints the resolved dates and the panel prints them again
 * with the inclusive day count.
 *
 * MONTH ARITHMETIC CLAMPS. Six months before 31 August is 28 or 29 February,
 * not 3 March. The naive `setMonth(m - 6)` overflows into the following month
 * and silently widens the range by a couple of days.
 *
 * `resolveDateRange` is exported deliberately: the server-side data layer has
 * to resolve the same preset to the same endpoints, and a second
 * implementation of this math is a second set of off-by-one bugs.
 */

export const DATE_RANGE_PRESETS = ["7d", "28d", "90d", "6m", "ytd", "custom"] as const;
export type DateRangePreset = (typeof DATE_RANGE_PRESETS)[number];

/** Presets that resolve to a range on their own. `custom` is operator-entered. */
export type FixedDateRangePreset = Exclude<DateRangePreset, "custom">;

export interface DateRange {
  /** Inclusive start, `YYYY-MM-DD`. */
  from: string;
  /** Inclusive end, `YYYY-MM-DD`. */
  to: string;
  preset: DateRangePreset;
}

export const DATE_RANGE_LABEL: Record<DateRangePreset, string> = {
  "7d": "Last 7 days",
  "28d": "Last 28 days",
  "90d": "Last 90 days",
  "6m": "Last 6 months",
  ytd: "Year to date",
  custom: "Custom",
};

/* ------------------------------------------------------------------ *
 * Date helpers — local-noon, ISO in and ISO out.
 * ------------------------------------------------------------------ */

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"] as const;

function toISO(d: Date): string {
  const y = String(d.getFullYear()).padStart(4, "0");
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

/** Local noon on the given ISO day. Invalid input falls back to today. */
function fromISO(iso: string): Date {
  const seg = iso.split("-");
  const y = Number(seg[0]);
  const m = Number(seg[1]);
  const d = Number(seg[2]);
  if (!Number.isFinite(y) || !Number.isFinite(m) || !Number.isFinite(d)) return new Date();
  return new Date(y, m - 1, d, 12, 0, 0, 0);
}

/** Today as an ISO day, in the viewer's own timezone. */
export function todayISO(): string {
  return toISO(new Date());
}

function addDays(d: Date, n: number): Date {
  const out = new Date(d.getTime());
  out.setDate(out.getDate() + n);
  return out;
}

/** Month arithmetic that clamps instead of overflowing. See header. */
function addMonths(d: Date, n: number): Date {
  const targetMonth = d.getMonth() + n;
  const out = new Date(d.getFullYear(), targetMonth, 1, 12, 0, 0, 0);
  const lastDay = new Date(out.getFullYear(), out.getMonth() + 1, 0, 12, 0, 0, 0).getDate();
  out.setDate(Math.min(d.getDate(), lastDay));
  return out;
}

/**
 * Resolve a fixed preset against a reference day.
 *
 * Ranges are INCLUSIVE of both endpoints, so "Last 7 days" spans 7 days ending
 * today — not 8. The panel prints the day count so the convention is visible
 * rather than assumed.
 */
export function resolveDateRange(
  preset: FixedDateRangePreset,
  today: string = todayISO(),
): DateRange {
  const end = fromISO(today);
  let start: Date;
  switch (preset) {
    case "7d":  start = addDays(end, -6); break;
    case "28d": start = addDays(end, -27); break;
    case "90d": start = addDays(end, -89); break;
    case "6m":  start = addDays(addMonths(end, -6), 1); break;
    case "ytd": start = new Date(end.getFullYear(), 0, 1, 12, 0, 0, 0); break;
  }
  return { from: toISO(start), to: toISO(end), preset };
}

/** Inclusive day count across a range. */
export function dayCount(from: string, to: string): number {
  const ms = fromISO(to).getTime() - fromISO(from).getTime();
  return Math.round(ms / 86_400_000) + 1;
}

function dayLabel(iso: string, withYear: boolean): string {
  const seg = iso.split("-");
  const year = seg[0] ?? "";
  const month = MONTHS[Number(seg[1]) - 1] ?? "";
  const day = Number(seg[2]);
  const dayText = Number.isFinite(day) ? String(day) : "";
  return `${month} ${dayText}${withYear ? `, ${year}` : ""}`.trim();
}

/**
 * "Aug 6 – Sep 2, 2026", or "Dec 1, 2025 – Sep 2, 2026" when the range spans a
 * year boundary. U+2013 EN DASH, which is the range dash — not the hyphen and
 * not the U+2212 minus the kit uses for signed deltas.
 */
export function formatDateRange(from: string, to: string): string {
  const sameYear = from.slice(0, 4) === to.slice(0, 4);
  return `${dayLabel(from, !sameYear)} – ${dayLabel(to, true)}`;
}

/* ------------------------------------------------------------------ *
 * Component
 * ------------------------------------------------------------------ */

export interface DateRangePickerProps {
  value: DateRange;
  onChange: (next: DateRange) => void;
  /**
   * Reference day for the relative presets, `YYYY-MM-DD`. Defaults to the
   * viewer's today. Injectable so a snapshot fixture resolves the same range
   * every run instead of drifting a day at midnight.
   */
  today?: string;
  /** Earliest selectable day — campaign start, or the first day of data. */
  minDate?: string;
  align?: "start" | "end";
  className?: string;
}

export function DateRangePicker({
  value, onChange, today = todayISO(), minDate, align = "end", className,
}: DateRangePickerProps) {
  const resolved = formatDateRange(value.from, value.to);

  return (
    <Popover
      align={align}
      className={cn(className)}
      panelClassName="w-[304px]"
      ariaLabel={`Date range: ${DATE_RANGE_LABEL[value.preset]}, ${resolved}`}
      label={
        <span className="inline-flex items-baseline gap-1.5">
          {DATE_RANGE_LABEL[value.preset]}
          <span className="font-mono text-nano tabular-nums text-ink-3">{resolved}</span>
        </span>
      }
    >
      {(close) => (
        <RangePanel
          value={value}
          today={today}
          minDate={minDate}
          onCommit={(next) => { onChange(next); close(); }}
        />
      )}
    </Popover>
  );
}

/**
 * Panel body. Remounted on every open, because Popover only renders its
 * children while open — so a half-typed custom range is never resurrected
 * from a previous session of the popover.
 */
function RangePanel({
  value, today, minDate, onCommit,
}: {
  value: DateRange;
  today: string;
  minDate?: string;
  onCommit: (next: DateRange) => void;
}) {
  const baseId = useId();
  const groupRef = useRef<HTMLDivElement>(null);

  const [preset, setPreset] = useState<DateRangePreset>(value.preset);
  const [from, setFrom] = useState(value.from);
  const [to, setTo] = useState(value.to);

  // ISO days compare correctly as plain strings — fixed width, big-endian,
  // zero-padded. No parsing needed to order them, and no timezone to get wrong.
  const customError = ((): string | null => {
    if (from === "" || to === "") return "Enter both dates.";
    if (from > to) return "The start date is after the end date.";
    if (minDate != null && from < minDate) return `No data before ${dayLabel(minDate, true)}.`;
    return null;
  })();

  const days = useMemo(
    () => (customError == null ? dayCount(from, to) : null),
    [customError, from, to],
  );

  const pick = (next: DateRangePreset) => {
    if (next === "custom") {
      // Reveal the fields, already seeded from the committed range, and wait
      // for Apply. A fixed preset commits and closes on the spot; a custom one
      // must not fire onChange on every half-typed year.
      setPreset("custom");
      return;
    }
    setPreset(next);
    onCommit(resolveDateRange(next, today));
  };

  /**
   * Roving tabindex + arrow keys, which is what `role="radiogroup"` promises.
   * Without it every preset is its own tab stop and Tab has to be pressed six
   * times to get past a control that should cost one.
   */
  const onGroupKeyDown = (e: ReactKeyboardEvent<HTMLDivElement>) => {
    const forward = e.key === "ArrowDown" || e.key === "ArrowRight";
    const back = e.key === "ArrowUp" || e.key === "ArrowLeft";
    if (!forward && !back) return;
    e.preventDefault();

    const current = DATE_RANGE_PRESETS.indexOf(preset);
    const count = DATE_RANGE_PRESETS.length;
    const nextIndex = ((current < 0 ? 0 : current) + (forward ? 1 : -1) + count) % count;
    const next = DATE_RANGE_PRESETS[nextIndex];
    if (!next) return;

    // Move focus first: `pick` on a fixed preset closes the popover, and
    // focusing a node that is about to unmount is a no-op that loses the ring.
    const node = groupRef.current?.querySelectorAll<HTMLButtonElement>('[role="radio"]').item(nextIndex);
    node?.focus();
    if (next === "custom") setPreset("custom");
    else pick(next);
  };

  const fromId = `${baseId}-from`;
  const toId = `${baseId}-to`;

  return (
    <div className="flex flex-col">
      <div
        ref={groupRef}
        role="radiogroup"
        aria-label="Date range preset"
        onKeyDown={onGroupKeyDown}
        className="flex flex-col"
      >
        {DATE_RANGE_PRESETS.map((key) => {
          const selected = preset === key;
          const range = key === "custom" ? null : resolveDateRange(key, today);
          return (
            <button
              key={key}
              type="button"
              role="radio"
              aria-checked={selected}
              tabIndex={selected ? 0 : -1}
              onClick={() => pick(key)}
              className={cn(
                "flex items-baseline gap-2 rounded px-2 py-1.5 text-left text-small",
                "transition-colors duration-fast ease-standard hover:bg-surface-hover",
                "focus-visible:outline-none focus-visible:shadow-focus",
                selected ? "font-bold text-ink" : "font-medium text-ink-2",
              )}
            >
              <span className="min-w-0 flex-1 truncate">{DATE_RANGE_LABEL[key]}</span>
              {range && (
                <span className="shrink-0 font-mono text-nano tabular-nums text-ink-3">
                  {formatDateRange(range.from, range.to)}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {preset === "custom" && (
        <div className="mt-1 flex flex-col gap-2 border-t border-line px-2 pb-1 pt-2">
          <div className="flex items-end gap-2">
            <FieldWrap id={fromId} label="From">
              <input
                id={fromId}
                type="date"
                value={from}
                max={to || undefined}
                min={minDate}
                onChange={(e) => setFrom(e.target.value)}
                className={cn(
                  // border-line-field, never border-line-strong: strong is
                  // 1.50:1 on white and fails WCAG 1.4.11 as a control bound.
                  "h-8 w-full rounded-md border border-line-field bg-surface-inset px-2",
                  "font-mono text-meta tabular-nums text-ink",
                  "focus-visible:outline-none focus-visible:shadow-focus",
                )}
              />
            </FieldWrap>
            <FieldWrap id={toId} label="To">
              <input
                id={toId}
                type="date"
                value={to}
                min={from || minDate}
                onChange={(e) => setTo(e.target.value)}
                className={cn(
                  "h-8 w-full rounded-md border border-line-field bg-surface-inset px-2",
                  "font-mono text-meta tabular-nums text-ink",
                  "focus-visible:outline-none focus-visible:shadow-focus",
                )}
              />
            </FieldWrap>
          </div>

          {/* The range is never committed silently on a bad pair, and the
              reason is stated rather than expressed as a disabled button. */}
          <p
            className={cn("text-meta", customError != null ? "text-danger-ink" : "text-ink-3")}
            role={customError != null ? "alert" : undefined}
          >
            {customError ?? (
              <>
                <span className="font-mono tabular-nums">{days}</span>
                {days === 1 ? " day" : " days"}, inclusive
              </>
            )}
          </p>

          <Button
            size="sm"
            className="self-end"
            disabled={customError != null}
            onClick={() => onCommit({ from, to, preset: "custom" })}
          >
            Apply
          </Button>
        </div>
      )}
    </div>
  );
}

function FieldWrap({ id, label, children }: { id: string; label: string; children: ReactNode }) {
  return (
    <div className="flex min-w-0 flex-1 flex-col gap-1">
      <label htmlFor={id} className="text-nano font-bold uppercase tracking-[0.06em] text-ink-3">
        {label}
      </label>
      {children}
    </div>
  );
}
