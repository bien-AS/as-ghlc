"use client";

import {
  useEffect, useRef, useState,
  type KeyboardEvent as ReactKeyboardEvent,
} from "react";
import { cn } from "../../lib/cn";
import { usePersistentState } from "../../lib/use-table";

/**
 * ThemeToggle — light / dark / system, as three real states.
 *
 * WHY THIS IS NOT A TWO-WAY SWITCH
 * "System" is a preference, not the absence of one. A binary switch has to
 * pick a side the first time it is touched, which overwrites what the operator
 * actually wanted — follow the OS — with a value that no longer tracks it. The
 * damage is invisible: the toggle looks right until the OS flips at sunset and
 * the app does not follow. So the stored value is one of three, and "system"
 * survives being clicked away from and back.
 *
 * WHY "SYSTEM" WRITES A CLASS INSTEAD OF CLEARING BOTH
 * Vantage is dark-first: `:root` IS the dark palette and `.light` derives from
 * it. There is no `@media (prefers-color-scheme)` block anywhere in
 * `colors_and_type.css` or `tokens.css`. So removing both classes does not mean
 * "follow the OS" in this system — it means dark, unconditionally, and a light-
 * mode operator on "System" would silently get dark forever. This resolves the
 * OS preference itself and writes the resolved class, then listens for changes
 * so a mid-session OS flip is picked up. The stored value stays "system"; only
 * the applied class is concrete.
 *
 * WHY THE STORED VALUE IS READ IN A useState INITIALISER
 * Reading it in an effect renders one frame with the default first, so every
 * mount flashes the wrong pressed state — and on a full-page toggle, the wrong
 * theme. The initialiser runs before the first paint.
 *
 * WHAT THIS COMPONENT CANNOT FIX
 * It cannot stop a page-level flash on FIRST load, because React has not
 * mounted yet when the document paints. That needs a blocking inline script in
 * the document head, which the preview shell already ships
 * (`design/index.html`, `design/preview/_ds.js`) against this same key. A host
 * app must ship the equivalent; this component only reconciles afterwards.
 *
 * Every localStorage access is wrapped, here and in `usePersistentState`:
 * it throws outright in private windows and embedded previews, and a theme
 * preference is never worth crashing a page over.
 */

/** The exact key the preview shell already reads and writes. Do not rename. */
export const THEME_STORAGE_KEY = "as-vantage-theme";

export const THEME_CHOICES = ["light", "dark", "system"] as const;
export type ThemeChoice = (typeof THEME_CHOICES)[number];

/** What a choice actually paints as, right now. */
export type ResolvedTheme = "light" | "dark";

const THEME_LABEL: Record<ThemeChoice, string> = {
  light: "Light",
  dark: "Dark",
  system: "System",
};

function isThemeChoice(raw: string): raw is ThemeChoice {
  return (THEME_CHOICES as readonly string[]).includes(raw);
}

/**
 * Resolve a choice to the theme that should be painted.
 *
 * Queries `prefers-color-scheme: light` rather than `: dark`, so a browser that
 * reports neither (no preference) falls through to dark — which is this
 * system's default, not an accident.
 */
export function resolveTheme(choice: ThemeChoice): ResolvedTheme {
  if (choice !== "system") return choice;
  try {
    if (typeof window === "undefined" || typeof window.matchMedia !== "function") return "dark";
    return window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  } catch {
    return "dark";
  }
}

/**
 * Write the resolved theme onto `document.documentElement`, and return it.
 *
 * `colorScheme` is set alongside the class so the browser's own widgets —
 * scrollbars, the native `<input type="date">` calendar, form control chrome —
 * match. Without it a dark page renders a white date picker.
 *
 * Exported so an app shell can call it from its pre-paint bootstrap script and
 * from route transitions without mounting the toggle.
 */
export function applyTheme(choice: ThemeChoice): ResolvedTheme {
  const resolved = resolveTheme(choice);
  if (typeof document === "undefined") return resolved;
  const root = document.documentElement;
  root.classList.remove("light", "dark");
  root.classList.add(resolved);
  root.style.colorScheme = resolved;
  return resolved;
}

export interface ThemeToggleProps {
  /** Accessible name for the group. */
  label?: string;
  /** Called after the class has been written, with both the choice and what it painted as. */
  onChange?: (choice: ThemeChoice, resolved: ResolvedTheme) => void;
  className?: string;
}

export function ThemeToggle({ label = "Theme", onChange, className }: ThemeToggleProps) {
  const [choice, setChoice] = usePersistentState<ThemeChoice>(
    THEME_STORAGE_KEY,
    "system",
    (raw) => (isThemeChoice(raw) ? raw : undefined),
  );
  // "dark", not resolveTheme(choice), for the SAME SSR reason as the stored
  // choice above: `resolveTheme` reads matchMedia, which the server does not
  // have — it returns "dark" there and the OS answer here, so the two renders
  // disagree and React warns on the `System, currently …` label. This is what
  // the server produces; the apply effect below corrects it on mount, before
  // anyone can read the label.
  const [resolved, setResolved] = useState<ResolvedTheme>("dark");
  const groupRef = useRef<HTMLDivElement>(null);

  // The callback lives in a ref so the apply effect can depend on `choice`
  // alone. With `onChange` in the dependency list, a caller passing an inline
  // arrow would re-run the DOM write on every render of the parent.
  const onChangeRef = useRef(onChange);
  useEffect(() => { onChangeRef.current = onChange; });

  useEffect(() => {
    const next = applyTheme(choice);
    setResolved(next);
    onChangeRef.current?.(choice, next);
  }, [choice]);

  // Only "system" tracks the OS. An explicit choice must not be overridden by
  // the machine going dark at sunset.
  useEffect(() => {
    if (choice !== "system") return;
    if (typeof window === "undefined" || typeof window.matchMedia !== "function") return;
    const query = window.matchMedia("(prefers-color-scheme: light)");
    const onPreferenceChange = () => {
      const next = applyTheme("system");
      setResolved(next);
      onChangeRef.current?.("system", next);
    };
    query.addEventListener("change", onPreferenceChange);
    return () => query.removeEventListener("change", onPreferenceChange);
  }, [choice]);

  /** Roving tabindex + arrow keys — what `role="radiogroup"` promises. */
  const onKeyDown = (event: ReactKeyboardEvent<HTMLDivElement>) => {
    const forward = event.key === "ArrowRight" || event.key === "ArrowDown";
    const back = event.key === "ArrowLeft" || event.key === "ArrowUp";
    if (!forward && !back) return;
    event.preventDefault();

    const count = THEME_CHOICES.length;
    const current = THEME_CHOICES.indexOf(choice);
    const nextIndex = ((current < 0 ? 0 : current) + (forward ? 1 : -1) + count) % count;
    const next = THEME_CHOICES[nextIndex];
    if (!next) return;
    setChoice(next);
    groupRef.current?.querySelectorAll<HTMLButtonElement>('[role="radio"]').item(nextIndex)?.focus();
  };

  return (
    <div
      ref={groupRef}
      role="radiogroup"
      aria-label={label}
      onKeyDown={onKeyDown}
      className={cn(
        // border-line-field bounds an interactive control. border-line-strong
        // is 1.50:1 on white and fails WCAG 1.4.11.
        "inline-flex items-center rounded-md border border-line-field bg-card p-0.5",
        className,
      )}
    >
      {THEME_CHOICES.map((key) => {
        const selected = choice === key;
        return (
          <button
            key={key}
            type="button"
            role="radio"
            aria-checked={selected}
            tabIndex={selected ? 0 : -1}
            // "System" alone does not say what it currently resolves to, and
            // that is the one thing a reader wants to confirm about it.
            aria-label={key === "system" ? `System, currently ${resolved}` : undefined}
            onClick={() => setChoice(key)}
            className={cn(
              "rounded px-2.5 py-1 text-meta transition-colors duration-fast ease-standard",
              "focus-visible:outline-none focus-visible:shadow-focus",
              selected
                // A teal FILL carries AS Black ink in both themes, and
                // LIGHTENS on interaction — `bg-teal-fill-hover`, never
                // `bg-teal-hover`, which is the text token.
                ? "bg-teal font-bold text-ink-on-teal hover:bg-teal-fill-hover"
                : "font-medium text-ink-3 hover:text-ink",
            )}
          >
            {THEME_LABEL[key]}
          </button>
        );
      })}
    </div>
  );
}
