"use client";

import { useMemo } from "react";
import {
  Area, AreaChart, CartesianGrid, ReferenceArea, ResponsiveContainer, Tooltip,
  XAxis, YAxis,
} from "recharts";
import { cn } from "../../lib/cn";
import { useChartTokens, RANK_TOKEN } from "../../lib/use-chart-tokens";
import {
  ALGO_LABEL, ALGO_TOKEN, algoUpdatesInRange, shortDate, type AlgoUpdate,
} from "../../lib/algo-updates";
import {
  RANK_BANDS, RANK_BAND_META, legendBands, type RankBand,
} from "../../lib/rank";

/**
 * BucketArea — how many tracked keywords sit in each rank band, over time. S-04.
 *
 * The chart answers one question: is the shape of the portfolio moving up? A
 * line of average position cannot answer it — an average hides ten keywords
 * falling off page one behind two reaching the pack. Stacked bands show the
 * redistribution directly.
 *
 * Rules this encodes, all of which come from the spec rather than taste:
 *
 * - THE BANDS ARE THE LAW, imported from `@/lib/rank`: 1-3 / 4-10 / 11-19 /
 *   20+ / not measured. They are not a styling choice — they encode what a
 *   searcher actually sees. Nothing here invents a band or a hue; the colours
 *   are the `--sc-rank-*` ramp and the labels are `RANK_BAND_META`'s.
 * - "NOT MEASURED" IS A LAYER, NOT AN OMISSION. It is stacked on top and
 *   always drawn. Drop it and a scan that failed on 40 keywords makes the
 *   whole stack shrink by 40 with no explanation, which reads as "we lost
 *   coverage" instead of "we did not look". The stack total is therefore the
 *   tracked-keyword count and stays flat when nothing changes but the ranks.
 * - BEST AT THE BOTTOM. `legendBands(true)` already returns rank order, and
 *   Recharts stacks in declaration order, so pack sits on the baseline. Growth
 *   is then literally the bottom band getting thicker.
 * - BANDS ARE NOT TOGGLEABLE. TimeSeries lets you hide a line; hiding a layer
 *   of a stack silently changes every remaining layer's height and the total.
 *   There is no legend button here, on purpose.
 * - NULL IS A WHOLE DATE, NOT A BAND. A stack physically cannot draw a hole in
 *   one layer — a missing layer is indistinguishable from a zero one, and the
 *   total quietly drops. So the contract is: a date with no scan is null in
 *   EVERY band, and the whole column becomes a gap with a hatched "no scan"
 *   overlay behind it. A null in one band on an otherwise-measured date is a
 *   data-shape error; it is drawn as zero and warned about, because refusing
 *   to draw the caller's data is worse than a warning.
 * - COLOUR NEVER ALONE. The tooltip prints the count AND the share of the
 *   tracked set per band, and the legend prints every band's label. The four
 *   rank hues collapse under deuteranopia.
 * - NO ENTRY ANIMATION. `isAnimationActive={false}` on every Area. Recharts'
 *   entry animation STALLS when the component re-renders mid-flight, leaving
 *   the path a few percent drawn and effectively invisible, permanently, with
 *   no error. A theme toggle is enough to trigger it, because the token hooks
 *   re-render. See the same note in time-series.tsx.
 * - ALGO OVERLAY ON EVERY TIMELINE (docs/06). Same layer, same tokens, same
 *   confirmed/unconfirmed dashing as time-series.tsx — pass `algoUpdates` and
 *   the bands appear behind the stack.
 */

/** Rank order, best first, "not measured" last. Stack order is this order. */
const BAND_ORDER = legendBands(true);

export interface BucketAreaProps {
  /** ISO dates, ascending. The x domain. */
  dates: string[];
  /**
   * Keyword counts per band, aligned to `dates` by index. A missing band reads
   * as zero on every date; `null` at an index means that date was not scanned
   * and must be null across ALL bands — see the doc comment.
   */
  counts: Partial<Record<RankBand, (number | null)[]>>;
  /** Algorithm-update bands. Required on every timeline per docs/06. */
  algoUpdates?: AlgoUpdate[];
  height?: number;
  yLabel?: string;
  /** Required: a bare stack of areas is not self-describing. */
  caption: string;
  loading?: boolean;
  notConnected?: { provider: string };
  className?: string;
}

type Row = Record<string, string | number | null>;

export function BucketArea({
  dates, counts, algoUpdates = [], height = 280, yLabel,
  caption, loading = false, notConnected, className,
}: BucketAreaProps) {
  const t = useChartTokens();
  // One resolver for every chart: a second MutationObserver reading the same
  // tokens is how two charts end up on different palettes after a toggle.
  const bandColor = Object.fromEntries(
    RANK_BANDS.map((b) => [b, t[RANK_TOKEN[b]] ?? "transparent"]),
  ) as Record<RankBand, string>;

  const { rows, partial } = useMemo(() => {
    let partialCount = 0;
    const out: Row[] = dates.map((date, i) => {
      const raw = BAND_ORDER.map((meta) => counts[meta.band]?.[i] ?? null);
      const measured = raw.some((v) => v != null);
      const missing = raw.filter((v) => v == null).length;
      if (measured && missing > 0) partialCount += 1;

      const row: Row = { date };
      let total = 0;
      BAND_ORDER.forEach((meta, bi) => {
        const v = raw[bi] ?? null;
        // On a measured date a null band has to become 0 — a stack cannot draw
        // a hole in one layer. On an unmeasured date every band stays null, so
        // the whole column breaks instead of collapsing to the baseline.
        const drawn = measured ? Math.max(0, v ?? 0) : null;
        row[meta.band] = drawn;
        if (drawn != null) total += drawn;
      });
      row.__total = measured ? total : null;
      return row;
    });
    return { rows: out, partial: partialCount };
  }, [dates, counts]);

  if (partial > 0) {
    console.warn(
      `BucketArea: ${partial} date(s) have a null in some bands but not all. ` +
      `A stack cannot render a hole in one layer, so those nulls are drawn as ` +
      `zero. Send the whole date as null when a scan did not run.`,
    );
  }

  // Contiguous unscanned runs, so the gap is labelled rather than just empty.
  const gaps = useMemo(() => {
    const out: { start: string; end: string }[] = [];
    let open: { start: string; end: string } | null = null;
    for (let i = 0; i < dates.length; i += 1) {
      const date = dates[i];
      if (date == null) continue;
      if (rows[i]?.__total == null) {
        if (open) open.end = date;
        else open = { start: date, end: date };
      } else if (open) {
        out.push(open);
        open = null;
      }
    }
    if (open) out.push(open);
    return out;
  }, [dates, rows]);

  const bands = useMemo(
    () => algoUpdatesInRange(algoUpdates, dates[0] ?? "", dates[dates.length - 1] ?? ""),
    [algoUpdates, dates],
  );

  if (loading || notConnected) {
    return (
      <div className={cn("rounded-xl border border-line bg-card", className)}>
        <div
          className="flex flex-col items-center justify-center gap-2 px-6 text-center"
          style={{ height }}
          aria-busy={loading || undefined}
        >
          {loading ? (
            <>
              <span className="sr-only">Loading chart</span>
              <div className="h-full w-full animate-pulse rounded bg-surface-inset motion-reduce:animate-none" />
            </>
          ) : (
            <>
              <p className="text-small font-bold text-ink">
                {notConnected!.provider} is not connected
              </p>
              <p className="max-w-[40ch] text-meta text-ink-2">
                This chart is empty because the source is not connected — not
                because there is nothing to show.
              </p>
            </>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={cn("flex flex-col rounded-xl border border-line bg-card", className)}>
      <figure className="m-0 p-3">
        <figcaption className="sr-only">{caption}</figcaption>
        <ResponsiveContainer width="100%" height={height}>
          <AreaChart data={rows} margin={{ top: 8, right: 12, bottom: 4, left: 4 }}>
            <CartesianGrid stroke={t.grid} strokeDasharray="0" vertical={false} />

            {/* ---- AlgoOverlay: same layer and tokens as TimeSeries ---- */}
            {bands.map((u) => (
              <ReferenceArea
                key={`algo-${u.name}-${u.start}`}
                x1={u.start}
                x2={u.end}
                fill={t[ALGO_TOKEN[u.type]]}
                fillOpacity={u.confirmed ? 0.13 : 0.07}
                stroke={t[ALGO_TOKEN[u.type]]}
                strokeOpacity={0.35}
                // Unconfirmed rollouts are dashed — never drawn as settled fact.
                strokeDasharray={u.confirmed ? undefined : "3 3"}
                ifOverflow="extendDomain"
              />
            ))}

            {/* ---- Unscanned dates: named, not just an empty stretch ---- */}
            {gaps.map((g) => (
              <ReferenceArea
                key={`gap-${g.start}`}
                x1={g.start}
                x2={g.end}
                fill={t.ink3}
                fillOpacity={0.08}
                stroke={t.ink3}
                strokeOpacity={0.3}
                strokeDasharray="2 3"
                ifOverflow="extendDomain"
              />
            ))}

            <XAxis
              dataKey="date"
              tickFormatter={shortDate}
              stroke={t.axis}
              tick={{ fill: t.ink3, fontSize: 11 }}
              tickLine={false}
              axisLine={{ stroke: t.border }}
              minTickGap={28}
            />
            <YAxis
              stroke={t.axis}
              tick={{ fill: t.ink3, fontSize: 11 }}
              tickLine={false}
              axisLine={false}
              width={48}
              allowDecimals={false}
              domain={[0, "auto"]}
              label={
                yLabel
                  ? { value: yLabel, angle: -90, position: "insideLeft",
                      fill: t.ink3, fontSize: 11, style: { textAnchor: "middle" } }
                  : undefined
              }
            />

            <Tooltip
              cursor={{ stroke: t.axis, strokeDasharray: "3 3" }}
              content={(props) => (
                <BucketTooltip {...props} rows={rows} bands={bands} bandColor={bandColor} />
              )}
            />

            {/* Declaration order IS stack order: pack on the baseline, not
                measured on top. */}
            {BAND_ORDER.map((meta) => (
              <Area
                key={meta.band}
                type="monotone"
                dataKey={meta.band}
                name={meta.label}
                stackId="rank-bands"
                stroke={bandColor[meta.band]}
                strokeWidth={1.25}
                fill={bandColor[meta.band]}
                fillOpacity={meta.band === "none" ? 0.28 : 0.62}
                connectNulls={false}
                dot={false}
                activeDot={{ r: 3, strokeWidth: 0 }}
                isAnimationActive={false}
              />
            ))}
          </AreaChart>
        </ResponsiveContainer>
      </figure>

      <BucketLegend bands={bands} gapCount={gaps.length} tokens={t} />
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Tooltip — count AND share per band, so the reading never depends on
 * hue, and an unscanned date says so instead of showing zeros.
 * ------------------------------------------------------------------ */
interface BucketTooltipProps {
  active?: boolean;
  label?: string | number;
  rows: Row[];
  bands: AlgoUpdate[];
  bandColor: Record<RankBand, string>;
}

function BucketTooltip({ active, label, rows, bands, bandColor }: BucketTooltipProps) {
  if (!active || label == null) return null;
  const date = String(label);
  const row = rows.find((r) => r.date === date);
  if (!row) return null;

  const total = row.__total as number | null;
  const activeBands = bands.filter((b) => b.start <= date && b.end >= date);

  return (
    <div className="min-w-[240px] rounded-lg border border-line bg-card p-2.5 shadow-md">
      <p className="mb-1.5 font-mono text-meta font-bold text-ink">{shortDate(date)}</p>

      {total == null ? (
        <p className="text-meta text-ink-2">
          Not measured — no scan ran on this date. The gap is missing data, not
          zero keywords.
        </p>
      ) : (
        <>
          <ul className="flex flex-col gap-1">
            {BAND_ORDER.map((meta) => {
              const count = (row[meta.band] as number | null) ?? 0;
              const share = total > 0 ? (count / total) * 100 : 0;
              return (
                <li key={meta.band} className="flex items-baseline gap-2 text-meta">
                  <span
                    aria-hidden
                    className="size-2 shrink-0 rounded-sm"
                    style={{ background: bandColor[meta.band] }}
                  />
                  <span className="min-w-0 flex-1 truncate text-ink-2">{meta.label}</span>
                  <span className="font-mono font-bold tabular-nums text-ink">
                    {count.toLocaleString()}
                  </span>
                  {/* The share is the non-colour encoding — it always prints. */}
                  <span className="font-mono tabular-nums text-ink-3">
                    {share.toFixed(1)}%
                  </span>
                </li>
              );
            })}
          </ul>
          <p className="mt-1.5 flex items-baseline justify-between gap-2 border-t border-line pt-1.5 text-meta text-ink-2">
            <span>Tracked keywords</span>
            <span className="font-mono font-bold tabular-nums text-ink">
              {total.toLocaleString()}
            </span>
          </p>
        </>
      )}

      {activeBands.map((b) => (
        <p key={b.name} className="mt-2 border-t border-line pt-1.5 text-meta text-ink-2">
          <span className="font-bold text-ink">{b.name}</span>
          {!b.confirmed && <span className="text-ink-3"> · unconfirmed</span>}
          {b.note && <span className="mt-0.5 block text-ink-3">{b.note}</span>}
        </p>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Legend. Bands are meaningless without their labels, and there are no
 * toggle buttons here on purpose — see the doc comment.
 * ------------------------------------------------------------------ */
function BucketLegend({
  bands, gapCount, tokens,
}: { bands: AlgoUpdate[]; gapCount: number; tokens: Record<string, string> }) {
  const types = [...new Set(bands.map((b) => b.type))];
  const anyUnconfirmed = bands.some((b) => !b.confirmed);
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 border-t border-line px-3 py-2 text-meta text-ink-3">
      {BAND_ORDER.map((meta) => (
        <span key={meta.band} className="inline-flex items-center gap-1.5">
          {/* Swatch through the token class — no literal needed outside SVG. */}
          <span aria-hidden className={cn("h-3 w-4 rounded-sm", meta.fill)} />
          {meta.label}
        </span>
      ))}
      {types.map((type) => (
        <span key={type} className="inline-flex items-center gap-1.5">
          <span aria-hidden className="h-3 w-4 rounded-sm"
                style={{ background: tokens[ALGO_TOKEN[type]], opacity: 0.35 }} />
          {ALGO_LABEL[type]}
        </span>
      ))}
      {anyUnconfirmed && (
        <span className="inline-flex items-center gap-1.5">
          <span aria-hidden className="h-3 w-4 rounded-sm border border-dashed border-ink-3" />
          Unconfirmed
        </span>
      )}
      {gapCount > 0 && (
        <span className="inline-flex items-center gap-1.5">
          <span aria-hidden className="h-3 w-4 rounded-sm border border-dashed border-ink-3" />
          {RANK_BAND_META.none.label} ({gapCount} {gapCount === 1 ? "gap" : "gaps"})
        </span>
      )}
    </div>
  );
}

/* Rank-band colours now come from the kit's central resolver — the private
 * copy that lived here duplicated its MutationObserver and could drift from
 * the shared palette. See RANK_TOKEN in lib/use-chart-tokens.ts. */
