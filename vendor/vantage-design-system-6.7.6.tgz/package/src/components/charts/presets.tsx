import { cn } from "../../lib/cn";
import { TimeSeries, type Series, type SignalMarker } from "./time-series";
import type { AlgoUpdate } from "../../lib/algo-updates";

/**
 * Chart presets — TimeSeries with the dangerous arguments already decided.
 *
 * WHY THESE EXIST
 * Two chart shapes recur in nearly every module, and each has one setting that
 * does not fail loudly when it is wrong — it just renders a plausible chart
 * that says the opposite of the truth. A rank chart drawn on a normal y axis
 * shows a climb to #40 as improvement. Clicks and impressions drawn on one
 * axis flatten clicks into a line along the floor. Deciding those once, here,
 * is cheaper than catching them in review every time someone plots a rank.
 *
 * THEY ARE PRESETS, NOT A SECOND CHARTING API. The prop surface is
 * deliberately narrow. Anything not exposed is reachable by using `TimeSeries`
 * directly — mirroring its whole interface here would double the number of
 * places every chart rule has to be enforced, and the second copy is the one
 * that goes stale.
 *
 * Everything structural stays in TimeSeries and is inherited, not
 * re-implemented: entry animation is already off on every series it draws (the
 * Recharts draw animation stalls on re-render and leaves paths invisible),
 * `null` breaks the line instead of dropping to zero, the tooltip prints the
 * value AND the change so the reading never depends on hue, and the
 * algorithm-update overlay is a built-in layer.
 */

/* ================================================================== *
 * PositionLine — rank over time.
 * ================================================================== */

export interface PositionLineProps {
  /** ISO dates, ascending. */
  dates: string[];
  /**
   * Rank per date, aligned to `dates` by index.
   * `null` = NOT MEASURED. Never pass 0 or 100 for "we didn't check" — a
   * failed scan plotted as rank 100 is indistinguishable from a real crash.
   */
  positions: (number | null)[];
  /** Name of the tracked term. Shown in the tooltip. */
  label?: string;
  algoUpdates?: AlgoUpdate[];
  markers?: SignalMarker[];
  caption: string;
  height?: number;
  /**
   * On by default, and it should almost always stay on: rank has no zero, so a
   * 0-based axis spends most of the plot on positions that cannot exist and
   * squashes a 3→9 slide into a few pixels. Exposed only for the rare side-by-
   * side where two charts must share a floor.
   */
  zoomY?: boolean;
  loading?: boolean;
  notConnected?: { provider: string };
  className?: string;
}

/**
 * A rank of 1 is the best result, so the axis is INVERTED — 1 at the top,
 * worse rows falling downward — and `invertY` is set here rather than exposed.
 * It is not a display preference: with it off, every ranking chart in the app
 * reads as its own mirror image, and the chart still looks entirely normal.
 * A caller who genuinely needs a non-inverted rank axis wants `TimeSeries`.
 */
export function PositionLine({
  dates, positions, label = "Position",
  algoUpdates = [], markers = [], caption, height = 240,
  zoomY = true, loading = false, notConnected, className,
}: PositionLineProps) {
  const series: Series[] = [
    {
      id: "position",
      label,
      values: positions,
      format: formatRank,
      // Explicit, not inherited: bridging a gap in a rank series invents a
      // measurement for a day nobody scanned.
      connectNulls: false,
    },
  ];

  const unmeasured = positions.filter((p) => p == null).length;

  return (
    <TimeSeries
      dates={dates}
      series={series}
      algoUpdates={algoUpdates}
      markers={markers}
      caption={caption}
      height={height}
      zoomY={zoomY}
      invertY
      yLabel="Position"
      loading={loading}
      notConnected={notConnected}
      // A single-series chart renders no legend, so without this the inverted
      // axis is unannounced and the gaps are visible only on hover. Both facts
      // are cheap to print and expensive to guess at.
      toolbar={
        <span className="text-meta text-ink-3">
          Position 1 at top
          {unmeasured > 0 && (
            <>
              {" · "}
              <span className="tabular-nums">
                {unmeasured} of {positions.length}
              </span>{" "}
              not measured
            </>
          )}
        </span>
      }
      // Merged here so a caller's className obeys the same rules as everywhere
      // else in the kit; TimeSeries merges it again against its own base
      // classes, which is idempotent.
      className={cn(className)}
    />
  );
}

/**
 * `#3`, not `3` — a bare number on a rank axis reads as a count.
 * Fractional averages keep one decimal instead of rounding: GSC average
 * position moves in tenths, and rounding 4.4 and 3.6 both to "4" hides the
 * only movement there was. Never called with `null`; TimeSeries prints an
 * em-dash and "not measured" for a missing reading before it gets here.
 */
function formatRank(v: number): string {
  return `#${Number.isInteger(v) ? v : v.toFixed(1)}`;
}

/* ================================================================== *
 * DualAxisTraffic — two related metrics of different magnitude.
 * ================================================================== */

export interface TrafficSeries {
  label: string;
  /** Aligned to `dates` by index. `null` = not measured, never 0. */
  values: (number | null)[];
  /** Tooltip formatter. Defaults to a grouped integer. */
  format?: (v: number) => string;
}

export interface DualAxisTrafficProps {
  dates: string[];
  /** Left axis, drawn as an area — the metric being read for level. */
  primary: TrafficSeries;
  /** Right axis, drawn as a line — the larger-magnitude context metric. */
  secondary: TrafficSeries;
  algoUpdates?: AlgoUpdate[];
  markers?: SignalMarker[];
  caption: string;
  height?: number;
  /**
   * Offer the 7-day rolling-mean toggle. Defaults ON — the canonical pair is
   * daily and noisy — but it only offers the toggle; nothing is smoothed
   * until the reader asks, and the tooltip still shows the raw measurement.
   */
  smoothing?: boolean;
  defaultSmoothed?: boolean;
  loading?: boolean;
  notConnected?: { provider: string };
  className?: string;
}

/**
 * The canonical case is GSC clicks (~250/day) against impressions
 * (~6000/day). On one axis the clicks series is a flat line on the floor and
 * every day looks identical, so the second axis is a correctness fix, not
 * decoration.
 *
 * The cost of a second axis is that the two series are no longer directly
 * comparable in height, and nothing on the chart says so. Three things carry
 * that: the primary is an AREA and the secondary a LINE (a shape difference,
 * readable without colour), the tooltip stamps the right-axis series with
 * "↦", and the header names which series sits on the right.
 *
 * Both axes stay 0-based. A truncated traffic axis exaggerates movement, and
 * unlike rank, zero is a real value here.
 */
export function DualAxisTraffic({
  dates, primary, secondary,
  algoUpdates = [], markers = [], caption, height = 280,
  smoothing = true, defaultSmoothed = false,
  loading = false, notConnected, className,
}: DualAxisTrafficProps) {
  const series: Series[] = [
    {
      id: "primary",
      label: primary.label,
      values: primary.values,
      format: primary.format,
      area: true,
      axis: "left",
    },
    {
      id: "secondary",
      label: secondary.label,
      values: secondary.values,
      format: secondary.format,
      axis: "right",
    },
  ];

  return (
    <TimeSeries
      dates={dates}
      series={series}
      algoUpdates={algoUpdates}
      markers={markers}
      caption={caption}
      height={height}
      smoothing={smoothing}
      defaultSmoothed={defaultSmoothed}
      yLabel={primary.label}
      loading={loading}
      notConnected={notConnected}
      toolbar={
        <span className="text-meta text-ink-3">
          Right axis: {secondary.label}
        </span>
      }
      className={cn(className)}
    />
  );
}
