"use client";

import { useMemo, useState, type ReactNode } from "react";
import { cn } from "../../lib/cn";
import { navIcon, ICON_SIZE, type SourceId } from "../../lib/icons";
import { rankBand, rankLabel, RANK_BAND_META, legendBands, type RankBand } from "../../lib/rank";
import { SourceBadge } from "../pills";

/**
 * HeatGrid — the city × keyword rank matrix.
 *
 * Not a Recharts component, deliberately. A heat grid is a table: it needs
 * sticky headers, per-row and per-column summaries, keyboard traversal and
 * text in every cell. Recharts has no primitive for that, and forcing one
 * would cost the semantics that make this readable to a screen reader. It is
 * built as a real `<table>`.
 *
 * Choices that are correctness, not styling:
 *
 * - EVERY CELL PRINTS ITS RANK. The four band hues collapse under
 *   deuteranopia, and this grid is nothing but colour otherwise. The number is
 *   the encoding; the fill is the fast scan.
 *
 * - NOT MEASURED IS NOT RANK 20+. A cell that was never scanned renders as a
 *   distinct hatched "none" band with an em-dash, never as "absent from
 *   results". Those are different facts and conflating them turns a scanner
 *   outage into a false report of lost rankings.
 *
 * - ROW SUMMARIES IGNORE HOLES. A city's average is computed over the cells
 *   actually measured, and the count of measured cells is shown beside it, so
 *   an average over 2 of 12 keywords cannot pass as an average over 12.
 *
 * - CELL INK IS PER BAND. The bands span too wide a lightness range for one
 *   ink to clear 4.5:1 on all of them — see the `*-on` tokens in tokens.css.
 */

export interface HeatCell {
  /** null = NOT MEASURED. Distinct from "absent from results", which is 20+. */
  rank: number | null;
  /** Optional per-cell provenance, surfaced in the title attribute. */
  source?: SourceId;
}

export interface HeatRow {
  id: string;
  /** City, location, or whatever the rows are scoped to. */
  label: string;
  sublabel?: string;
  /** Keyed by column id. Missing keys are treated as not measured. */
  cells: Record<string, HeatCell | undefined>;
}

export interface HeatColumn {
  id: string;
  label: string;
  sublabel?: string;
}

export type HeatSort = "label" | "best" | "worst" | "coverage";

export interface HeatGridProps {
  rows: HeatRow[];
  columns: HeatColumn[];
  /** Screen-reader caption. Required — a grid of bare numbers is not self-describing. */
  caption: string;
  /** Header above the row labels, e.g. "City" or "Location". */
  rowHeader?: string;
  defaultSort?: HeatSort;
  onCellClick?: (row: HeatRow, column: HeatColumn, cell: HeatCell) => void;
  loading?: boolean;
  notConnected?: { provider: string };
  source?: SourceId;
  toolbar?: ReactNode;
  className?: string;
}

interface RowStats {
  /** Mean of measured ranks only. null when nothing was measured. */
  avg: number | null;
  measured: number;
  total: number;
  inPack: number;
}

function statsFor(row: HeatRow, columns: HeatColumn[]): RowStats {
  const ranks = columns
    .map((c) => row.cells[c.id]?.rank)
    .filter((r): r is number => r != null && Number.isFinite(r));
  return {
    avg: ranks.length ? ranks.reduce((a, b) => a + b, 0) / ranks.length : null,
    measured: ranks.length,
    total: columns.length,
    inPack: ranks.filter((r) => r <= 3).length,
  };
}

export function HeatGrid({
  rows, columns, caption, rowHeader = "Location",
  defaultSort = "best", onCellClick,
  loading = false, notConnected, source, toolbar, className,
}: HeatGridProps) {
  const [sort, setSort] = useState<HeatSort>(defaultSort);

  const withStats = useMemo(
    () => rows.map((r) => ({ row: r, stats: statsFor(r, columns) })),
    [rows, columns],
  );

  const sorted = useMemo(() => {
    const list = withStats.slice();
    switch (sort) {
      case "label":
        return list.sort((a, b) => a.row.label.localeCompare(b.row.label));
      case "coverage":
        return list.sort((a, b) => b.stats.measured - a.stats.measured);
      case "worst":
      case "best": {
        // Rows with nothing measured always sort last, in both directions —
        // "no data" is not a good result or a bad one.
        return list.sort((a, b) => {
          if (a.stats.avg == null && b.stats.avg == null) return 0;
          if (a.stats.avg == null) return 1;
          if (b.stats.avg == null) return -1;
          return sort === "best" ? a.stats.avg - b.stats.avg : b.stats.avg - a.stats.avg;
        });
      }
    }
  }, [withStats, sort]);

  /** Per-column roll-up, for the footer row. */
  const colStats = useMemo(
    () =>
      columns.map((c) => {
        const ranks = rows
          .map((r) => r.cells[c.id]?.rank)
          .filter((r): r is number => r != null && Number.isFinite(r));
        return {
          avg: ranks.length ? ranks.reduce((a, b) => a + b, 0) / ranks.length : null,
          measured: ranks.length,
        };
      }),
    [rows, columns],
  );

  const coverage = useMemo(() => {
    const total = rows.length * columns.length;
    const measured = withStats.reduce((n, w) => n + w.stats.measured, 0);
    return { measured, total, pct: total ? (measured / total) * 100 : 0 };
  }, [withStats, rows.length, columns.length]);

  if (loading || notConnected) {
    return (
      <div className={cn("rounded-xl border border-line bg-card", className)}>
        <div className="flex flex-col items-center justify-center gap-2 px-6 py-16 text-center"
             aria-busy={loading || undefined}>
          {loading ? (
            <>
              <span className="sr-only">Loading grid</span>
              <div className="grid w-full max-w-md grid-cols-6 gap-1">
                {Array.from({ length: 30 }).map((_, i) => (
                  <div key={i}
                       className="h-7 animate-pulse rounded bg-surface-inset motion-reduce:animate-none"
                       style={{ animationDelay: `${i * 18}ms` }} />
                ))}
              </div>
            </>
          ) : (
            <>
              <p className="text-small font-bold text-ink">
                {notConnected!.provider} is not connected
              </p>
              <p className="max-w-[42ch] text-meta text-ink-2">
                This grid is empty because the source is not connected — not
                because these locations have no rankings.
              </p>
            </>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={cn("flex flex-col rounded-xl border border-line bg-card", className)}>
      <div className="flex flex-wrap items-center gap-2 border-b border-line px-3 py-2">
        <div role="radiogroup" aria-label="Sort rows"
             className="flex items-center rounded-md border border-line-field p-0.5">
          {([
            ["best", "Best first"], ["worst", "Worst first"],
            ["label", "A–Z"], ["coverage", "Coverage"],
          ] as [HeatSort, string][]).map(([key, label]) => (
            <button key={key} type="button" role="radio" aria-checked={sort === key}
              onClick={() => setSort(key)}
              className={cn(
                "rounded px-2 py-1 text-meta font-medium transition-colors duration-fast",
                "focus-visible:outline-none focus-visible:shadow-focus",
                // Teal FILL lightens on hover; teal TEXT darkens. Two tokens.
                sort === key
                  ? "bg-teal text-ink-on-teal hover:bg-teal-fill-hover"
                  : "text-ink-3 hover:text-ink",
              )}>
              {label}
            </button>
          ))}
        </div>

        {/* Coverage is stated up front: a grid that looks sparse because the
            scanner failed should never be mistaken for one that looks sparse
            because the rankings are bad. */}
        <span className="text-meta text-ink-3">
          <span className="font-mono tabular-nums text-ink-2">
            {coverage.measured}/{coverage.total}
          </span>{" "}
          cells measured
          {coverage.pct < 100 && (
            <span className="ml-1 font-mono tabular-nums">
              ({coverage.pct.toFixed(0)}%)
            </span>
          )}
        </span>

        <div className="ml-auto flex items-center gap-2">
          {source && <SourceBadge source={source} size="sm" />}
          {toolbar}
        </div>
      </div>

      <div className="overflow-auto">
        <table className="w-full border-collapse text-small">
          <caption className="sr-only">{caption}</caption>
          <thead className="sticky top-0 z-20 bg-card">
            <tr className="border-b border-line-strong">
              <th scope="col"
                  className="sticky left-0 z-30 min-w-[160px] bg-card px-3 py-2 text-left text-micro font-bold uppercase tracking-[0.06em] text-ink-3">
                {rowHeader}
              </th>
              {/* The max-w below stays in rem ON PURPOSE. 1rem is 14px in this
                  system (see kit/README.md), so these caps render 91px rather
                  than the 104px they read as — which is correct here: they are
                  truncation caps on label text, and a truncation point should
                  track the text scale rather than sit at a fixed pixel. The
                  full string is on the th's title either way. */}
              {columns.map((c) => (
                <th key={c.id} scope="col" title={c.sublabel ?? c.label}
                    className="px-1.5 py-2 text-center align-bottom">
                  <span className="mx-auto block max-w-[6.5rem] truncate text-micro font-bold text-ink-3">
                    {c.label}
                  </span>
                  {c.sublabel && (
                    <span className="mx-auto block max-w-[6.5rem] truncate font-mono text-nano text-ink-3">
                      {c.sublabel}
                    </span>
                  )}
                </th>
              ))}
              {/* Pinned right: this column carries the measured/total
                  denominator, so it must not be the first thing to scroll
                  out of view on a wide grid. */}
              <th scope="col"
                  className="sticky right-0 z-30 border-l border-line-strong bg-card px-3 py-2 text-right text-micro font-bold uppercase tracking-[0.06em] text-ink-3">
                Avg
              </th>
            </tr>
          </thead>

          <tbody>
            {sorted.map(({ row, stats }) => (
              <tr key={row.id} className="border-b border-line-subtle">
                <th scope="row"
                    className="sticky left-0 z-10 bg-card px-3 py-1.5 text-left font-medium">
                  <span className="block truncate text-ink">{row.label}</span>
                  {row.sublabel && (
                    <span className="block truncate font-mono text-nano text-ink-3">
                      {row.sublabel}
                    </span>
                  )}
                </th>

                {columns.map((c) => {
                  const cell = row.cells[c.id];
                  const rank = cell?.rank ?? null;
                  const band = rankBand(rank);
                  const meta = RANK_BAND_META[band];
                  const unmeasured = band === "none";
                  const title =
                    `${row.label} · ${c.label} — ` +
                    (unmeasured ? "not measured" : `rank ${rankLabel(rank)} (${meta.label})`) +
                    (cell?.source ? ` · ${cell.source}` : "");

                  const content = (
                    <span
                      className={cn(
                        "flex h-7 w-full items-center justify-center rounded font-mono text-meta font-bold tabular-nums",
                        meta.fill, meta.onFill,
                        // Not-measured is hatched as well as greyed, so it is
                        // distinguishable from a legitimately poor rank even
                        // when the hues are indistinguishable.
                        unmeasured && "opacity-45 [background-image:repeating-linear-gradient(45deg,transparent,transparent_3px,rgba(0,0,0,0.18)_3px,rgba(0,0,0,0.18)_6px)]",
                      )}
                    >
                      {rankLabel(rank)}
                    </span>
                  );

                  return (
                    <td key={c.id} className="p-0.5" title={title}>
                      {onCellClick && cell ? (
                        <button
                          type="button"
                          onClick={() => onCellClick(row, c, cell)}
                          aria-label={title}
                          className="block w-full rounded transition-opacity duration-fast hover:opacity-85 focus-visible:outline-none focus-visible:shadow-focus"
                        >
                          {content}
                        </button>
                      ) : (
                        content
                      )}
                      <span className="sr-only">{title}</span>
                    </td>
                  );
                })}

                <td className="sticky right-0 z-10 border-l border-line-strong bg-card px-3 py-1.5 text-right">
                  {stats.avg == null ? (
                    <span className="text-ink-3" title="Nothing measured for this row">—</span>
                  ) : (
                    <span className="inline-flex items-baseline gap-1.5">
                      <span className="font-mono font-bold tabular-nums text-ink">
                        {stats.avg.toFixed(1)}
                      </span>
                      {/* The denominator is always shown: an average over 2 of
                          12 keywords must not read like an average over 12. */}
                      <span className="font-mono text-nano tabular-nums text-ink-3">
                        {stats.measured}/{stats.total}
                      </span>
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>

          <tfoot>
            <tr className="border-t border-line-strong">
              <th scope="row"
                  className="sticky left-0 z-10 bg-card px-3 py-2 text-left text-micro font-bold uppercase tracking-[0.06em] text-ink-3">
                Keyword avg
              </th>
              {colStats.map((cs, i) => (
                <td key={columns[i]?.id ?? i} className="px-1.5 py-2 text-center">
                  <span className="font-mono text-meta tabular-nums text-ink-2">
                    {cs.avg == null ? "—" : cs.avg.toFixed(1)}
                  </span>
                </td>
              ))}
              <td className="sticky right-0 z-10 border-l border-line-strong bg-card px-3 py-2" />
            </tr>
          </tfoot>
        </table>
      </div>

      <HeatLegend />
    </div>
  );
}

function HeatLegend() {
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 border-t border-line px-3 py-2 text-meta text-ink-3">
      {legendBands(false).map((b) => (
        <span key={b.band} className="inline-flex items-center gap-1.5">
          <span aria-hidden className={cn("inline-block size-3 rounded-sm", b.fill)} />
          {b.label}
          {/* Skip the range when it just repeats the label ("20+ 20+"). */}
          {b.label !== `${b.min}+` && (
            <span className="font-mono text-nano">
              {b.min}
              {b.max != null ? `–${b.max}` : "+"}
            </span>
          )}
        </span>
      ))}
      <span className="inline-flex items-center gap-1.5">
        <span aria-hidden
              className="inline-block size-3 rounded-sm bg-rank-none opacity-45 [background-image:repeating-linear-gradient(45deg,transparent,transparent_2px,rgba(0,0,0,0.18)_2px,rgba(0,0,0,0.18)_4px)]" />
        Not measured
      </span>
      <span className="ml-auto inline-flex items-center gap-1">
        <navIcon.forward size={ICON_SIZE.dense} aria-hidden />
        Click a cell for the live SERP
      </span>
    </div>
  );
}

export type { RankBand };
