"use client";

import { useMemo } from "react";
import { cn } from "../../lib/cn";

/**
 * SovBars — competitor share of voice, as a horizontal bar list. S-14.
 *
 * WHY DIVS AND NOT RECHARTS
 * This is the one chart in the kit that is deliberately hand-rolled. A
 * Recharts `BarChart layout="vertical"` buys nothing here and costs three
 * things that matter:
 *
 * - The numbers stop being text. Share of voice is read as "we are on 12.4%
 *   and they are on 31%", not as bar lengths, so the percentage and the
 *   absolute count have to be selectable, screen-readable, `tabular-nums`
 *   text — not SVG <text> the reader cannot copy.
 * - Category labels get clipped. Competitor rows are domains of wildly
 *   different length; a vertical BarChart needs a guessed left margin and
 *   truncates whatever overflows it. A div row wraps or truncates on purpose.
 * - `null` cannot be drawn. Recharts has no way to render "not measured" as
 *   anything other than an absent bar, which is indistinguishable from 0%.
 *   Here an unmeasured row gets a dashed, empty track and the words "not
 *   measured" where the percentage would be — see below.
 *
 * The div version also needs no token->literal colour resolution, so it is
 * styled purely through Tailwind token classes and is correct in both themes
 * with no `dark:` variants.
 *
 * Rules this encodes:
 *
 * - NULL IS NOT ZERO. An unmeasured competitor renders as a dashed empty
 *   track with an explicit "not measured" label, and when sorting by value it
 *   sorts LAST in both directions — the same rule DataTable uses. It never
 *   becomes a zero-height bar and never gets a floor width, because "we have
 *   no reading" and "they hold none of the market" are opposite findings.
 * - NEVER BAR LENGTH ALONE. Every row prints its percentage AND its absolute
 *   value. The client row is teal, but it also carries a "You" tag and a left
 *   rule, so the distinction survives deuteranopia and greyscale printing.
 * - THE TRACK IS THE WHOLE MARKET, not the leader. Bars are scaled to `total`
 *   (or the sum of measured values), so a 9% share looks like 9% of the row.
 *   Scaling to the top competitor would make every chart look like a close
 *   race, which is the opposite of what this tool is for.
 * - "OTHERS" NEVER SWALLOWS THE CLIENT. When `maxRows` collapses the tail, the
 *   client's own row is pulled into the visible head even if it ranks below
 *   the cut — it is the row the operator opened the screen for. The Others row
 *   states how many competitors it merges, so the tail is never silent.
 * - NO WIDTH TRANSITION. Bars do not animate to their new width on a data
 *   change. Same rule as the Recharts `isAnimationActive={false}` in
 *   time-series.tsx: data updates cross-fade, they never draw or count.
 */

export interface SovRow {
  id: string;
  label: string;
  /** Share metric — visits, keywords, mentions. `null` = NOT MEASURED. */
  value: number | null;
  /** The client we are looking at. Rendered in teal and tagged "You". */
  isClient?: boolean;
}

export interface SovBarsProps {
  rows: SovRow[];
  /**
   * Denominator for the percentages. Defaults to the sum of the measured
   * values, i.e. "share of what we can see". Pass the real market total when
   * you know it — the footer then reports how much of it the listed rows
   * actually cover, instead of implying they cover all of it.
   */
  total?: number;
  /** Descending by value by default; unmeasured rows always sort last. */
  sortBy?: "value" | "label";
  /** Collapse everything past this many rows into a single "Others" row. */
  maxRows?: number;
  /** Formats the absolute value. Defaults to `toLocaleString()`. */
  format?: (v: number) => string;
  /** What the absolute value counts, e.g. "keywords". Printed after the total. */
  unit?: string;
  /** Required: a bare grid of percentages is not self-describing. */
  caption: string;
  loading?: boolean;
  notConnected?: { provider: string };
  className?: string;
}

interface PreparedRow {
  id: string;
  label: string;
  value: number | null;
  isClient: boolean;
  /** Source rows folded into this one. 1 for a real row, N for "Others". */
  merged: number;
}

export function SovBars({
  rows, total, sortBy = "value", maxRows, format, unit,
  caption, loading = false, notConnected, className,
}: SovBarsProps) {
  const fmt = format ?? ((v: number) => v.toLocaleString());

  // The denominator comes from the FULL input, before any collapsing, so
  // turning `maxRows` on cannot silently change anybody's percentage.
  const measuredSum = useMemo(
    () => rows.reduce((a, r) => a + Math.max(0, r.value ?? 0), 0),
    [rows],
  );
  const denom = total ?? measuredSum;
  const unmeasuredCount = rows.filter((r) => r.value == null).length;
  const coverage = denom > 0 ? (measuredSum / denom) * 100 : null;

  const prepared = useMemo(
    () => prepareRows(rows, sortBy, maxRows),
    [rows, sortBy, maxRows],
  );

  if (loading || notConnected) {
    return (
      <div className={cn("rounded-xl border border-line bg-card", className)}>
        {/* min-h in rem on purpose: this only reserves height for a skeleton /
            empty state, so tracking the text scale is right. Content-sizing
            values in this kit are in px — 1rem is 14px here. */}
        <div
          className="flex min-h-[10rem] flex-col items-center justify-center gap-2 px-6 py-6 text-center"
          aria-busy={loading || undefined}
        >
          {loading ? (
            <>
              <span className="sr-only">Loading share of voice</span>
              <div className="h-full w-full animate-pulse rounded bg-surface-inset motion-reduce:animate-none" />
            </>
          ) : (
            <>
              <p className="text-small font-bold text-ink">
                {notConnected!.provider} is not connected
              </p>
              <p className="max-w-[40ch] text-meta text-ink-2">
                This chart is empty because the source is not connected — not
                because there is nothing to show.
              </p>
            </>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={cn("flex flex-col rounded-xl border border-line bg-card", className)}>
      <figure className="m-0 px-3 py-3">
        <figcaption className="sr-only">{caption}</figcaption>

        {prepared.length === 0 ? (
          <p className="px-1 py-6 text-center text-meta text-ink-2">
            No competitors to compare yet.
          </p>
        ) : (
          <ul className="flex flex-col gap-2.5">
            {prepared.map((row) => {
              const pct =
                row.value != null && denom > 0 ? (row.value / denom) * 100 : null;
              const measured = row.value != null;
              return (
                <li
                  key={row.id}
                  className={cn(
                    "flex flex-col gap-1 border-l-[3px] pl-2",
                    // A structural rule, not just a hue — it survives greyscale.
                    row.isClient ? "border-l-teal" : "border-l-transparent",
                  )}
                >
                  <div className="flex items-baseline justify-between gap-3">
                    <span className="flex min-w-0 items-baseline gap-1.5">
                      <span
                        className={cn(
                          "truncate text-meta",
                          row.isClient ? "font-bold text-teal-ink" : "text-ink-2",
                        )}
                        title={row.label}
                      >
                        {row.label}
                      </span>
                      {row.isClient && (
                        <span className="shrink-0 rounded bg-teal-soft px-1.5 py-0.5 text-nano font-bold uppercase tracking-[0.04em] text-teal-ink">
                          You
                        </span>
                      )}
                      {row.merged > 1 && (
                        <span className="shrink-0 text-nano text-ink-3">
                          ({row.merged} merged)
                        </span>
                      )}
                    </span>

                    {/* The numbers are the encoding. Colour only ranks them. */}
                    <span className="flex shrink-0 items-baseline gap-2 text-meta">
                      {measured ? (
                        <>
                          <span className="font-mono font-bold tabular-nums text-ink">
                            {pct == null ? "—" : `${pct.toFixed(1)}%`}
                          </span>
                          <span className="font-mono tabular-nums text-ink-2">
                            {fmt(row.value!)}
                          </span>
                        </>
                      ) : (
                        <span className="text-ink-3">not measured</span>
                      )}
                    </span>
                  </div>

                  {measured ? (
                    <div aria-hidden className="h-2.5 w-full rounded-full bg-surface-inset">
                      <div
                        className={cn(
                          "h-full rounded-full",
                          row.isClient ? "bg-teal" : "bg-ink-3",
                        )}
                        // A 3px stub keeps a real but tiny share visible without
                        // inflating it — the percentage beside it stays exact.
                        style={{
                          width: `${Math.min(100, Math.max(0, pct ?? 0))}%`,
                          minWidth: (row.value ?? 0) > 0 ? "3px" : undefined,
                        }}
                      />
                    </div>
                  ) : (
                    // Dashed and EMPTY. A solid track at 0 width would read as
                    // "they hold none of the market", which is a different claim.
                    <div
                      aria-hidden
                      className="h-2.5 w-full rounded-full border border-dashed border-line-strong"
                    />
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </figure>

      <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1 border-t border-line px-3 py-2 text-meta text-ink-3">
        <span>
          Total{" "}
          <span className="font-mono font-bold tabular-nums text-ink-2">{fmt(denom)}</span>
          {unit ? ` ${unit}` : ""}
        </span>
        <span>
          <span className="font-mono tabular-nums text-ink-2">{rows.length}</span>{" "}
          {rows.length === 1 ? "competitor" : "competitors"}
        </span>
        {unmeasuredCount > 0 && (
          <span>
            <span className="font-mono tabular-nums text-ink-2">{unmeasuredCount}</span>{" "}
            not measured
          </span>
        )}
        {/* Only worth saying when the listed rows do NOT account for the total. */}
        {coverage != null && coverage < 99.5 && (
          <span>
            Listed rows cover{" "}
            <span className="font-mono tabular-nums text-ink-2">{coverage.toFixed(1)}%</span>{" "}
            of the total
          </span>
        )}
      </div>
    </div>
  );
}

/**
 * Sort, then optionally collapse the tail.
 *
 * When sorting by value, unmeasured rows sort last in BOTH directions. They
 * are not the smallest share; they are an absence of a reading, and letting
 * the sort direction move them would make them look like a result. An
 * alphabetical sort leaves them in place, under their own name.
 */
function prepareRows(
  rows: SovRow[],
  sortBy: "value" | "label",
  maxRows?: number,
): PreparedRow[] {
  const base: PreparedRow[] = rows.map((r) => ({
    id: r.id,
    label: r.label,
    value: r.value ?? null,
    isClient: r.isClient === true,
    merged: 1,
  }));

  const sorted = [...base].sort((a, b) => {
    // Alphabetical means alphabetical: an unmeasured competitor stays findable
    // under its own name instead of being exiled to the end of the list.
    if (sortBy === "label") return a.label.localeCompare(b.label);
    // By value, "not measured" sorts last in BOTH directions — the same rule
    // DataTable uses. It is the absence of a reading, not the smallest share.
    if (a.value == null && b.value == null) return a.label.localeCompare(b.label);
    if (a.value == null) return 1;
    if (b.value == null) return -1;
    return b.value - a.value;
  });

  if (maxRows == null || maxRows < 1 || sorted.length <= maxRows) return sorted;

  // At least one real competitor is always shown — a list that is nothing but
  // an "Others" row answers no question at all.
  const head = sorted.slice(0, Math.max(1, maxRows - 1));
  const tail = sorted.slice(Math.max(1, maxRows - 1));

  // The client's own row is why the operator opened this screen. It is pulled
  // into the visible head even when it ranks below the cut, swapping places
  // with the weakest visible competitor rather than vanishing into "Others".
  const clientIdx = tail.findIndex((r) => r.isClient);
  const displaced = head[head.length - 1];
  const client = clientIdx >= 0 ? tail[clientIdx] : undefined;
  if (client && displaced && !head.some((r) => r.isClient)) {
    head[head.length - 1] = client;
    tail[clientIdx] = displaced;
  }

  const measured = tail.filter((r): r is PreparedRow & { value: number } => r.value != null);
  const others: PreparedRow = {
    id: "__others__",
    label: "Others",
    // An all-unmeasured tail stays unmeasured. Summing nothing to 0 would
    // invent a finding.
    value: measured.length > 0 ? measured.reduce((a, r) => a + r.value, 0) : null,
    isClient: false,
    merged: tail.length,
  };

  return [...head, others];
}
