"use client";

import { useMemo, useState, type ReactNode } from "react";
import {
  Area, CartesianGrid, ComposedChart, Legend, Line, ReferenceArea, ReferenceLine,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { cn } from "../../lib/cn";
import { actionIcon, ICON_SIZE } from "../../lib/icons";
import {
  useChartTokens, SERIES_ORDER, MAX_READABLE_SERIES,
} from "../../lib/use-chart-tokens";
import {
  ALGO_LABEL, ALGO_TOKEN, algoUpdatesInRange, pctChange, rollingMean, shortDate,
  type AlgoUpdate,
} from "../../lib/algo-updates";

/**
 * TimeSeries — the base timeline, with the AlgoOverlay and SignalMarkers layers.
 *
 * docs/06 requires the algorithm-update overlay on EVERY timeline, so it is
 * built in here rather than left to callers: pass `algoUpdates` and the bands
 * appear. Omitting them should be a deliberate act, not an oversight.
 *
 * Rules this encodes, all of which come from the spec rather than taste:
 *
 * - MAX 3 SERIES. Beyond three lines a legend stops being readable; the answer
 *   is a small multiple, not a fourth colour. Passing more logs a warning and
 *   still renders, because refusing to draw the user's data is worse.
 * - NEVER COLOUR ALONE. The tooltip prints the value AND the change versus the
 *   previous point, with a sign, so the reading survives without hue.
 * - NULL IS A HOLE. An unmeasured day breaks the line rather than dropping to
 *   zero. `connectNulls` is off by default and opt-in per series.
 * - NO PIE, NO 3D, NO AREA STACKS BY DEFAULT. Area fill is a single-series
 *   affordance for reading level, not a way to stack categories.
 * - NO ENTRY ANIMATION on data series. Two reasons, and the second is the
 *   one that bites: the AS motion spec is explicit that data updates
 *   cross-fade and never draw or count; and Recharts' line-draw animation
 *   STALLS when the component re-renders mid-flight, leaving the path stuck
 *   at `stroke-dasharray: 38px 3330px` — about 1% drawn — permanently. A
 *   theme toggle is enough to trigger it, because the token hook re-renders.
 *   The line then simply is not there, with no error. Animation stays off.
 */

export interface Series {
  id: string;
  label: string;
  /** Values aligned to `data` by index. `null` = not measured. */
  values: (number | null)[];
  /** Token key from useChartTokens. Defaults to position in SERIES_ORDER. */
  token?: string;
  /** Fill under the line. Single-series charts only. */
  area?: boolean;
  /** Bridge gaps instead of breaking the line. Off by default — see above. */
  connectNulls?: boolean;
  /** Formatter for tooltip + axis. */
  format?: (v: number) => string;
  /** Right-hand axis instead of left. */
  axis?: "left" | "right";
}

export interface SignalMarker {
  /** ISO date; must exist in `dates` or it is dropped. */
  date: string;
  label: string;
  /** Short glyph shown on the axis, e.g. "D" for deploy. */
  glyph?: string;
  note?: string;
}

export interface TimeSeriesProps {
  /** ISO dates, ascending. The x domain. */
  dates: string[];
  series: Series[];
  /** Algorithm-update bands. Required on every timeline per docs/06. */
  algoUpdates?: AlgoUpdate[];
  /** Deploys, publishes, campaign starts — anything that could explain a move. */
  markers?: SignalMarker[];
  height?: number;
  /** Offer a 7-day rolling-mean toggle. For noisy daily series. */
  smoothing?: boolean;
  defaultSmoothed?: boolean;
  /** Y axis starts at the data floor rather than zero. Off by default: a
   *  truncated axis exaggerates movement, and this is an honesty-first tool. */
  zoomY?: boolean;
  yLabel?: string;
  /** Inverted y, for rank charts where 1 is best. */
  invertY?: boolean;
  caption: string;
  loading?: boolean;
  notConnected?: { provider: string };
  className?: string;
  toolbar?: ReactNode;
}

export function TimeSeries({
  dates, series, algoUpdates = [], markers = [], height = 280,
  smoothing = false, defaultSmoothed = false, zoomY = false,
  yLabel, invertY = false, caption,
  loading = false, notConnected, className, toolbar,
}: TimeSeriesProps) {
  const t = useChartTokens();
  const [smoothed, setSmoothed] = useState(defaultSmoothed);
  const [hidden, setHidden] = useState<Set<string>>(new Set());

  if (series.length > MAX_READABLE_SERIES) {
    // Render anyway — refusing to draw the caller's data is worse than a
    // crowded legend — but say so, because this is a spec rule.
    console.warn(
      `TimeSeries: ${series.length} series exceeds the ${MAX_READABLE_SERIES}-series ` +
      `readability cap. Consider a small multiple instead of a fourth line.`,
    );
  }

  const shown = series.filter((s) => !hidden.has(s.id));

  const rows = useMemo(() => {
    return dates.map((date, i) => {
      const row: Record<string, string | number | null> = { date };
      for (const s of series) {
        const vals = smoothed ? rollingMean(s.values, 7) : s.values;
        row[s.id] = vals[i] ?? null;
        // Keep the raw value for the tooltip so smoothing never hides the
        // actual measurement behind an average.
        row[`${s.id}__raw`] = s.values[i] ?? null;
      }
      return row;
    });
  }, [dates, series, smoothed]);

  const bands = useMemo(
    () => algoUpdatesInRange(algoUpdates, dates[0] ?? "", dates[dates.length - 1] ?? ""),
    [algoUpdates, dates],
  );

  const validMarkers = useMemo(
    () => markers.filter((m) => dates.includes(m.date)),
    [markers, dates],
  );

  const colorOf = (s: Series, i: number) =>
    t[s.token ?? SERIES_ORDER[i % SERIES_ORDER.length]!] ?? t["chart-1"]!;

  // A second axis is not decoration: GSC clicks (~250/day) and impressions
  // (~6000/day) on one scale flattens clicks into a line along the floor.
  // Recharts requires an explicit yAxisId on EVERY layer once two axes exist,
  // including the reference areas and lines.
  const hasRightAxis = series.some((s) => s.axis === "right");
  const axisOf = (s: Series) => (s.axis === "right" ? "right" : "left");

  if (loading || notConnected) {
    return (
      <div className={cn("rounded-xl border border-line bg-card", className)}>
        <div
          className="flex flex-col items-center justify-center gap-2 px-6 text-center"
          style={{ height }}
          aria-busy={loading || undefined}
        >
          {loading ? (
            <>
              <span className="sr-only">Loading chart</span>
              <div className="h-full w-full animate-pulse rounded bg-surface-inset motion-reduce:animate-none" />
            </>
          ) : (
            <>
              <p className="text-small font-bold text-ink">
                {notConnected!.provider} is not connected
              </p>
              <p className="max-w-[40ch] text-meta text-ink-2">
                This chart is empty because the source is not connected — not
                because there is nothing to show.
              </p>
            </>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={cn("flex flex-col rounded-xl border border-line bg-card", className)}>
      {(smoothing || toolbar || series.length > 1) && (
        <div className="flex flex-wrap items-center gap-2 border-b border-line px-3 py-2">
          {series.length > 1 && (
            <div className="flex flex-wrap items-center gap-1">
              {series.map((s, i) => {
                const off = hidden.has(s.id);
                return (
                  <button
                    key={s.id}
                    type="button"
                    aria-pressed={!off}
                    onClick={() =>
                      setHidden((cur) => {
                        const next = new Set(cur);
                        if (next.has(s.id)) next.delete(s.id);
                        else next.add(s.id);
                        return next;
                      })
                    }
                    className={cn(
                      "inline-flex items-center gap-1.5 rounded px-2 py-1 text-meta font-medium",
                      "transition-colors duration-fast hover:bg-surface-hover",
                      "focus-visible:outline-none focus-visible:shadow-focus",
                      off ? "text-ink-3 line-through" : "text-ink-2",
                    )}
                  >
                    <span
                      aria-hidden
                      className="size-2.5 rounded-sm"
                      style={{ background: off ? "transparent" : colorOf(s, i),
                               boxShadow: off ? `inset 0 0 0 1.5px ${colorOf(s, i)}` : undefined }}
                    />
                    {s.label}
                  </button>
                );
              })}
            </div>
          )}

          {smoothing && (
            <button
              type="button"
              aria-pressed={smoothed}
              onClick={() => setSmoothed((v) => !v)}
              title="Rolling 7-day mean. The tooltip still shows the raw measurement."
              className={cn(
                "ml-auto inline-flex h-7 items-center gap-1.5 rounded-md border px-2.5 text-meta font-medium",
                "transition-colors duration-fast focus-visible:outline-none focus-visible:shadow-focus",
                smoothed
                  ? "border-teal bg-teal text-ink-on-teal"
                  : "border-line-strong bg-card text-ink-2 hover:bg-surface-hover",
              )}
            >
              <actionIcon.refresh size={ICON_SIZE.dense} aria-hidden />
              7-day mean
            </button>
          )}
          {toolbar && <div className={cn(!smoothing && "ml-auto", "flex items-center gap-2")}>{toolbar}</div>}
        </div>
      )}

      <figure className="m-0 p-3">
        <figcaption className="sr-only">{caption}</figcaption>
        <ResponsiveContainer width="100%" height={height}>
          <ComposedChart data={rows} margin={{ top: 8, right: 12, bottom: 4, left: 4 }}>
            <CartesianGrid stroke={t.grid} strokeDasharray="0" vertical={false} />

            {/* ---- AlgoOverlay: bands behind the series ---- */}
            {bands.map((u) => (
              <ReferenceArea
                key={`${u.name}-${u.start}`}
                x1={u.start}
                x2={u.end}
                fill={t[ALGO_TOKEN[u.type]]}
                fillOpacity={u.confirmed ? 0.13 : 0.07}
                stroke={t[ALGO_TOKEN[u.type]]}
                strokeOpacity={0.35}
                // Unconfirmed rollouts are dashed — never drawn as settled fact.
                strokeDasharray={u.confirmed ? undefined : "3 3"}
                ifOverflow="extendDomain"
                yAxisId="left"
              />
            ))}

            {/* ---- SignalMarkers: things we did, that could explain a move ---- */}
            {validMarkers.map((m) => (
              <ReferenceLine
                key={`${m.date}-${m.label}`}
                x={m.date}
                stroke={t["chart-5"]}
                strokeDasharray="2 3"
                strokeOpacity={0.7}
                label={{
                  value: m.glyph ?? "•",
                  position: "top",
                  fill: t.ink3,
                  fontSize: 10,
                  fontFamily: "var(--font-mono)",
                }}
                yAxisId="left"
              />
            ))}

            <XAxis
              dataKey="date"
              tickFormatter={shortDate}
              stroke={t.axis}
              tick={{ fill: t.ink3, fontSize: 11 }}
              tickLine={false}
              axisLine={{ stroke: t.border }}
              minTickGap={28}
            />
            <YAxis
              yAxisId="left"
              stroke={t.axis}
              tick={{ fill: t.ink3, fontSize: 11 }}
              tickLine={false}
              axisLine={false}
              width={48}
              reversed={invertY}
              domain={zoomY ? ["auto", "auto"] : [0, "auto"]}
              tickFormatter={compactNumber}
              label={
                yLabel
                  ? { value: yLabel, angle: -90, position: "insideLeft",
                      fill: t.ink3, fontSize: 11, style: { textAnchor: "middle" } }
                  : undefined
              }
            />
            {hasRightAxis && (
              <YAxis
                yAxisId="right"
                orientation="right"
                stroke={t.axis}
                tick={{ fill: t.ink3, fontSize: 11 }}
                tickLine={false}
                axisLine={false}
                width={48}
                reversed={invertY}
                domain={zoomY ? ["auto", "auto"] : [0, "auto"]}
                tickFormatter={compactNumber}
              />
            )}

            <Tooltip
              cursor={{ stroke: t.axis, strokeDasharray: "3 3" }}
              content={(props) => (
                <ChartTooltip {...props} series={shown} rows={rows} bands={bands}
                  markers={validMarkers} smoothed={smoothed} colorOf={colorOf} />
              )}
            />

            {shown.map((s) => {
              const i = series.findIndex((x) => x.id === s.id);
              const color = colorOf(s, i);
              return s.area ? (
                <Area
                  key={s.id} type="monotone" dataKey={s.id} name={s.label}
                  stroke={color} fill={color} fillOpacity={0.14} strokeWidth={1.75}
                  connectNulls={s.connectNulls ?? false}
                  dot={false} activeDot={{ r: 3.5, strokeWidth: 0 }}
                  isAnimationActive={false}
                  yAxisId={axisOf(s)}
                />
              ) : (
                <Line
                  key={s.id} type="monotone" dataKey={s.id} name={s.label}
                  stroke={color} strokeWidth={1.75}
                  connectNulls={s.connectNulls ?? false}
                  dot={false} activeDot={{ r: 3.5, strokeWidth: 0 }}
                  isAnimationActive={false}
                  yAxisId={axisOf(s)}
                />
              );
            })}

            <Legend content={() => null} />
          </ComposedChart>
        </ResponsiveContainer>
      </figure>

      {(bands.length > 0 || validMarkers.length > 0) && (
        <AlgoLegend bands={bands} markers={validMarkers} tokens={t} />
      )}
    </div>
  );
}

/** Axis ticks abbreviate so a 5-digit number does not eat the plot area. */
function compactNumber(v: number): string {
  const abs = Math.abs(v);
  if (abs >= 1_000_000) return `${(v / 1_000_000).toFixed(abs >= 10_000_000 ? 0 : 1)}M`;
  if (abs >= 1_000) return `${(v / 1_000).toFixed(abs >= 10_000 ? 0 : 1)}k`;
  return String(v);
}

/* ------------------------------------------------------------------ *
 * Tooltip — value AND change, so the reading never depends on hue.
 * ------------------------------------------------------------------ */
interface TooltipProps {
  active?: boolean;
  label?: string | number;
  series: Series[];
  rows: Record<string, string | number | null>[];
  bands: AlgoUpdate[];
  markers: SignalMarker[];
  smoothed: boolean;
  colorOf: (s: Series, i: number) => string;
}

function ChartTooltip({
  active, label, series, rows, bands, markers, smoothed, colorOf,
}: TooltipProps) {
  if (!active || label == null) return null;
  const date = String(label);
  const i = rows.findIndex((r) => r.date === date);
  if (i < 0) return null;

  const activeBands = bands.filter((b) => b.start <= date && b.end >= date);
  const activeMarkers = markers.filter((m) => m.date === date);

  return (
    <div className="min-w-[208px] rounded-lg border border-line bg-card p-2.5 shadow-md">
      <p className="mb-1.5 font-mono text-meta font-bold text-ink">{shortDate(date)}</p>

      <ul className="flex flex-col gap-1">
        {series.map((s, si) => {
          const raw = rows[i]?.[`${s.id}__raw`] as number | null;
          const shownVal = rows[i]?.[s.id] as number | null;
          const prev = i > 0 ? (rows[i - 1]?.[`${s.id}__raw`] as number | null) : null;
          const change = pctChange(prev, raw);
          const fmt = s.format ?? ((v: number) => v.toLocaleString());
          return (
            <li key={s.id} className="flex items-baseline gap-2 text-meta">
              <span aria-hidden className="size-2 shrink-0 rounded-sm"
                    style={{ background: colorOf(s, si) }} />
              <span className="min-w-0 flex-1 truncate text-ink-2">
                {s.label}
                {s.axis === "right" && (
                  <span className="ml-1 text-nano text-ink-3" title="Plotted on the right-hand axis">↦</span>
                )}
              </span>
              <span className="font-mono font-bold tabular-nums text-ink">
                {raw == null ? "—" : fmt(raw)}
              </span>
              {/* The change is the non-colour encoding — it must always print. */}
              {change != null && (
                <span
                  className={cn(
                    "font-mono tabular-nums",
                    change > 0 ? "text-teal-ink" : change < 0 ? "text-danger-ink" : "text-ink-3",
                  )}
                >
                  {change > 0 ? "+" : change < 0 ? "−" : ""}
                  {Math.abs(change).toFixed(1)}%
                </span>
              )}
              {raw == null && <span className="text-ink-3">not measured</span>}
              {smoothed && shownVal != null && raw != null && (
                <span className="sr-only">
                  Smoothed value {fmt(shownVal)}; raw measurement {fmt(raw)}.
                </span>
              )}
            </li>
          );
        })}
      </ul>

      {activeBands.map((b) => (
        <p key={b.name} className="mt-2 border-t border-line pt-1.5 text-meta text-ink-2">
          <span className="font-bold text-ink">{b.name}</span>
          {!b.confirmed && <span className="text-ink-3"> · unconfirmed</span>}
          {b.note && <span className="mt-0.5 block text-ink-3">{b.note}</span>}
        </p>
      ))}
      {activeMarkers.map((m) => (
        <p key={m.label} className="mt-2 border-t border-line pt-1.5 text-meta">
          <span className="font-bold text-ink">{m.label}</span>
          {m.note && <span className="mt-0.5 block text-ink-3">{m.note}</span>}
        </p>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Legend for the overlay layers. Bands are meaningless without it.
 * ------------------------------------------------------------------ */
function AlgoLegend({
  bands, markers, tokens,
}: { bands: AlgoUpdate[]; markers: SignalMarker[]; tokens: Record<string, string> }) {
  const types = [...new Set(bands.map((b) => b.type))];
  const anyUnconfirmed = bands.some((b) => !b.confirmed);
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 border-t border-line px-3 py-2 text-meta text-ink-3">
      {types.map((type) => (
        <span key={type} className="inline-flex items-center gap-1.5">
          <span aria-hidden className="h-3 w-4 rounded-sm"
                style={{ background: tokens[ALGO_TOKEN[type]], opacity: 0.35 }} />
          {ALGO_LABEL[type]}
        </span>
      ))}
      {anyUnconfirmed && (
        <span className="inline-flex items-center gap-1.5">
          <span aria-hidden className="h-3 w-4 rounded-sm border border-dashed border-ink-3" />
          Unconfirmed
        </span>
      )}
      {markers.length > 0 && (
        <span className="inline-flex items-center gap-1.5">
          <span aria-hidden className="h-3 w-px border-l border-dashed border-ink-3" />
          Our activity ({markers.length})
        </span>
      )}
    </div>
  );
}
