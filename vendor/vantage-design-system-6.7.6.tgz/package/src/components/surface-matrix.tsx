import type { ComponentPropsWithoutRef } from "react";
import { cn } from "../lib/cn";
import { SurfaceIcon } from "./surface-badge";
import {
  SURFACE_IDS, SURFACE_META, getSurfacesByCategory, type SurfaceId,
} from "../lib/surfaces";

/**
 * SurfaceMatrix — the "LLM knowledge matrix": entities down, the 6 AI
 * surfaces across.
 *
 * The 4+2 column grouping is structural, not cosmetic. Chatbot surfaces and
 * Google Search AI features answer to different ranking signals, so the
 * divider between them stops a reader scanning across and averaging two
 * unrelated things. Keep the gap.
 */
export type CellState = "cited" | "partial" | "absent" | "unmeasured";

const CELL: Record<CellState, { className: string; label: string; mark: string }> = {
  cited:      { className: "bg-teal text-ink-on-teal",              label: "Cited",      mark: "●" },
  partial:    { className: "bg-amber-soft text-amber-ink ring-1 ring-inset ring-amber/40", label: "Partial", mark: "◐" },
  absent:     { className: "bg-surface-inset text-ink-3",           label: "Not cited",  mark: "○" },
  unmeasured: { className: "bg-transparent text-ink-3 ring-1 ring-inset ring-line border-dashed", label: "Not measured", mark: "–" },
};

export interface SurfaceMatrixCellProps extends ComponentPropsWithoutRef<"td"> {
  state: CellState;
  size?: number;
}

export function SurfaceMatrixCell({ state, size = 32, className, ...props }: SurfaceMatrixCellProps) {
  const meta = CELL[state];
  return (
    <td className={cn("p-1 text-center", className)} {...props}>
      <span
        className={cn(
          "inline-flex items-center justify-center rounded font-bold leading-none",
          meta.className,
        )}
        style={{ width: size, height: size }}
        title={meta.label}
      >
        {/* The mark is the accessible encoding — the fill alone is not. */}
        <span aria-hidden className="text-meta">{meta.mark}</span>
        <span className="sr-only">{meta.label}</span>
      </span>
    </td>
  );
}

export interface MatrixRow {
  id: string;
  label: string;
  sublabel?: string;
  cells: Partial<Record<SurfaceId, CellState>>;
}

export interface SurfaceMatrixProps extends ComponentPropsWithoutRef<"div"> {
  rows: MatrixRow[];
  surfaces?: readonly SurfaceId[];
  cellSize?: number;
  rowHeader?: string;
}

export function SurfaceMatrix({
  rows, surfaces = SURFACE_IDS, cellSize = 32, rowHeader = "Entity",
  className, ...props
}: SurfaceMatrixProps) {
  const chatbots = getSurfacesByCategory("chatbot").filter((s) => surfaces.includes(s.id));
  const features = getSurfacesByCategory("search-feature").filter((s) => surfaces.includes(s.id));
  const ordered = [...chatbots, ...features];
  const dividerAfter = chatbots.length - 1;

  return (
    <div className={cn("overflow-x-auto", className)} {...props}>
      <table className="w-full border-collapse text-small">
        <thead>
          <tr>
            <th className="sticky left-0 z-10 bg-card px-3 py-2 text-left text-micro font-bold uppercase tracking-[0.06em] text-ink-3">
              {rowHeader}
            </th>
            {ordered.map((s, i) => (
              <th
                key={s.id}
                className={cn(
                  "px-1 py-2 text-center align-bottom",
                  i === dividerAfter && "pr-3 border-r border-line-strong",
                )}
                style={{ minWidth: cellSize + 8 }}
              >
                <span className="flex flex-col items-center gap-1">
                  <SurfaceIcon surface={s.id} size={14} className="opacity-80" style={{ color: s.color }} />
                  <span className="font-mono text-nano font-bold text-ink-3">{s.glyph}</span>
                </span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.id} className="border-t border-line-subtle">
              <th
                scope="row"
                className="sticky left-0 z-10 bg-card px-3 py-1.5 text-left font-medium"
              >
                <span className="block truncate text-ink">{row.label}</span>
                {row.sublabel && (
                  <span className="block truncate font-mono text-nano text-ink-3">{row.sublabel}</span>
                )}
              </th>
              {ordered.map((s, i) => (
                <SurfaceMatrixCell
                  key={s.id}
                  state={row.cells[s.id] ?? "unmeasured"}
                  size={cellSize}
                  className={cn(i === dividerAfter && "pr-3 border-r border-line-strong")}
                />
              ))}
            </tr>
          ))}
        </tbody>
      </table>

      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-meta text-ink-3">
        {(Object.keys(CELL) as CellState[]).map((k) => (
          <span key={k} className="inline-flex items-center gap-1.5">
            <span
              className={cn("inline-flex size-4 items-center justify-center rounded text-nano font-bold", CELL[k].className)}
              aria-hidden
            >
              {CELL[k].mark}
            </span>
            {CELL[k].label}
          </span>
        ))}
        <span className="ml-auto font-mono text-nano">
          {chatbots.length} chatbot · {features.length} search AI
        </span>
      </div>
    </div>
  );
}

export { SURFACE_META };
