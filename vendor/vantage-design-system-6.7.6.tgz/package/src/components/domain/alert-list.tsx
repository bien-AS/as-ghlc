"use client";

import { useId, useMemo, type ComponentPropsWithoutRef, type ReactNode } from "react";
import { cn } from "../../lib/cn";
import { navIcon, ICON_SIZE, type Severity, type SourceId } from "../../lib/icons";
import { Button, Card, CardHeader, CardTitle } from "../primitives";
import { SeverityDot, SourceBadge } from "../pills";
import { EmptyState, NotMeasured, PanelSkeleton } from "./empty-state";

/**
 * AlertList — the anomaly / alert feed (S-15).
 *
 * FOUR BEHAVIOURS HERE ARE CORRECTNESS, NOT STYLING.
 *
 * 1. CRITICAL FIRST, ALWAYS. The feed groups by severity and puts critical at
 *    the top, because a strictly chronological feed buries a critical alert
 *    under a morning of info noise. Within a group it is newest-first, which
 *    is the only ordering that answers "is this still happening".
 *
 * 2. ACKNOWLEDGED IS NOT HANDLED. An acknowledged alert recedes — neutral
 *    accent, secondary title colour, an explicit "Acknowledged" tag — but it
 *    is never hidden. Someone ticking a box does not make the ranking drop
 *    stop being true, and a feed that empties itself on acknowledgement lets a
 *    live problem vanish from the only screen that shows it.
 *
 *    The recession is done with colour TOKENS (`text-ink-2`), never with
 *    `opacity`. Fading text is the easy way to do this and it drags real
 *    content under 4.5:1.
 *
 * 3. RECENT IS RELATIVE, OLD IS ABSOLUTE (the AS date rule). "2h ago" answers
 *    "is this live?"; four months later "2,847h ago" answers nothing, so it
 *    becomes "Mar 14". The cutover is 7 days. Every timestamp also carries the
 *    absolute date in its `title`, so the relative form never destroys detail.
 *
 * 4. AN UNPARSEABLE `at` IS NOT "JUST NOW". It renders as not-measured and
 *    sorts last, the same law `null` follows everywhere else in this system.
 *
 * `notConnected` takes precedence over empty: "no alerts" and "we never looked"
 * are opposite facts and must never render the same.
 */

export interface AlertItem {
  id: string;
  severity: Severity;
  title: string;
  detail?: ReactNode;
  /** ISO 8601 timestamp. Unparseable renders as not-measured and sorts last. */
  at: string;
  /** Provenance. Rendered as a SourceBadge — the data-honesty rule. */
  source?: SourceId;
  /**
   * Free-text scope label ("Smith Grove · /roofing-houston"). Deliberately not
   * the closed `Scope` union from `pills.tsx`: an alert can be scoped to a
   * keyword, a location or a competitor, none of which that set covers.
   */
  scope?: string;
  acknowledged?: boolean;
  onAck?: () => void;
  onOpen?: () => void;
}

export interface AlertListProps extends Omit<ComponentPropsWithoutRef<"div">, "title"> {
  items: AlertItem[];
  title?: string;
  loading?: boolean;
  /** Provider not connected. Takes precedence over empty. */
  notConnected?: { provider: string; onConnect?: () => void };
  /**
   * The parent is filtering. Flips the zero-state from "nothing happened" to
   * "your filters hid it" — see the note in `empty-state.tsx`.
   */
  filtered?: boolean;
  onClearFilters?: () => void;
  emptyTitle?: string;
  emptyBody?: string;
  emptyAction?: ReactNode;
  /**
   * Pin "now" for deterministic SSR and tests. Left to `Date.now()` the
   * relative times differ between the server render and the client hydrate.
   */
  now?: number;
  ackLabel?: string;
  openLabel?: string;
}

/** Critical first. This order is the component's whole reason for grouping. */
const SEVERITY_ORDER: readonly Severity[] = ["critical", "moderate", "info"];

/**
 * 3px left accent. The severity is ALSO named by the group heading, so this is
 * redundant encoding rather than the signal itself — the three tones are not
 * separable for every reader.
 */
const ACCENT: Record<Severity, string> = {
  critical: "border-l-danger",
  moderate: "border-l-amber",
  info: "border-l-line-strong",
};

const MONTHS = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
] as const;

const MINUTE = 60_000;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;

/** `Mar 14`, or `Mar 14, 2025` once the year stops being obvious. */
function absoluteDate(d: Date, now: Date): string {
  const month = MONTHS[d.getMonth()] ?? "";
  const base = `${month} ${d.getDate()}`;
  return d.getFullYear() === now.getFullYear() ? base : `${base}, ${d.getFullYear()}`;
}

/**
 * The AS date rule. Returns `null` when `iso` is unparseable, so the caller
 * renders not-measured instead of inventing a time.
 */
export function alertTime(iso: string, nowMs: number): { text: string; absolute: string } | null {
  const t = Date.parse(iso);
  if (!Number.isFinite(t)) return null;

  const d = new Date(t);
  const now = new Date(nowMs);
  const absolute = absoluteDate(d, now);
  const diff = nowMs - t;

  // Clock skew puts "now" fractionally behind the event; that is still "now",
  // not a date in the future.
  if (diff < MINUTE) return { text: "just now", absolute };
  if (diff < HOUR) return { text: `${Math.floor(diff / MINUTE)}m ago`, absolute };
  if (diff < DAY) return { text: `${Math.floor(diff / HOUR)}h ago`, absolute };
  if (diff < 7 * DAY) return { text: `${Math.floor(diff / DAY)}d ago`, absolute };
  return { text: absolute, absolute };
}

export function AlertList({
  items,
  title = "Alerts",
  loading = false,
  notConnected,
  filtered = false,
  onClearFilters,
  emptyTitle = "No alerts this cycle",
  emptyBody = "Nothing crossed an alert threshold. This panel fills in when a metric moves far enough to need a look.",
  emptyAction,
  now = Date.now(),
  ackLabel = "Acknowledge",
  openLabel = "Open",
  className,
  ...props
}: AlertListProps) {
  const headingId = useId();

  const groups = useMemo(
    () =>
      SEVERITY_ORDER.map((severity) => ({
        severity,
        // slice() first — never sort the caller's array in place.
        items: items
          .filter((a) => a.severity === severity)
          .slice()
          .sort((a, b) => {
            // NaN (unparseable) coerces to 0 here, which floats those rows to
            // the bottom in a newest-first sort. Same law as `null` in tables.
            const ta = Date.parse(a.at);
            const tb = Date.parse(b.at);
            return (Number.isFinite(tb) ? tb : 0) - (Number.isFinite(ta) ? ta : 0);
          }),
      })).filter((g) => g.items.length > 0),
    [items],
  );

  const unacknowledged = items.filter((a) => !a.acknowledged).length;

  return (
    <Card padding="none" className={cn("overflow-hidden", className)} {...props}>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {items.length > 0 && (
          <span className="ml-auto font-mono text-meta tabular-nums text-ink-3">
            <span className="font-bold text-ink-2">{unacknowledged}</span> unacknowledged
            {" · "}
            {items.length} total
          </span>
        )}
      </CardHeader>

      {loading ? (
        <PanelSkeleton rows={4} label="Loading alerts" />
      ) : notConnected ? (
        <EmptyState
          variant="notConnected"
          provider={notConnected.provider}
          title={`${notConnected.provider} is not connected`}
          body="This feed is empty because the source is not connected — not because nothing happened. Connect it before reading a quiet feed as good news."
          action={
            notConnected.onConnect && (
              <Button size="sm" onClick={notConnected.onConnect}>
                Connect {notConnected.provider}
              </Button>
            )
          }
        />
      ) : groups.length === 0 ? (
        filtered ? (
          <EmptyState
            variant="filtered"
            title="No alerts match"
            body="Alerts exist in this period; the current filters hide all of them."
            action={
              onClearFilters && (
                <Button size="sm" variant="secondary" onClick={onClearFilters}>
                  Clear filters
                </Button>
              )
            }
          />
        ) : (
          <EmptyState variant="empty" title={emptyTitle} body={emptyBody} action={emptyAction} />
        )
      ) : (
        groups.map((group) => {
          const groupId = `${headingId}-${group.severity}`;
          return (
            <section key={group.severity} aria-labelledby={groupId}>
              <div className="flex items-center gap-2 border-b border-line bg-surface-subtle px-4 py-2">
                {/* SeverityDot lives on the GROUP, not the row: repeating it on
                    every row inside a labelled group is noise, and the row
                    still carries the severity via its accent + this heading. */}
                <SeverityDot severity={group.severity} id={groupId} />
                <span className="font-mono text-meta tabular-nums text-ink-3">
                  {group.items.length}
                </span>
              </div>

              <ul className="flex flex-col">
                {group.items.map((alert) => (
                  <AlertRow
                    key={alert.id}
                    alert={alert}
                    now={now}
                    ackLabel={ackLabel}
                    openLabel={openLabel}
                  />
                ))}
              </ul>
            </section>
          );
        })
      )}
    </Card>
  );
}

function AlertRow({
  alert, now, ackLabel, openLabel,
}: { alert: AlertItem; now: number; ackLabel: string; openLabel: string }) {
  const time = alertTime(alert.at, now);
  const acked = alert.acknowledged === true;

  return (
    <li
      className={cn(
        "flex flex-col gap-1.5 border-b border-b-line-subtle border-l-[3px] px-4 py-3 last:border-b-0",
        // Acknowledged recedes to a neutral accent. It does not disappear.
        acked ? "border-l-line" : ACCENT[alert.severity],
      )}
    >
      <div className="flex items-start justify-between gap-3">
        {alert.onOpen ? (
          <button
            type="button"
            onClick={alert.onOpen}
            className={cn(
              "min-w-0 rounded text-left text-small font-semibold leading-snug transition-colors duration-fast",
              "hover:text-teal-hover focus-visible:outline-none focus-visible:shadow-focus",
              acked ? "text-ink-2" : "text-ink",
            )}
          >
            {alert.title}
          </button>
        ) : (
          <p
            className={cn(
              "min-w-0 text-small font-semibold leading-snug",
              acked ? "text-ink-2" : "text-ink",
            )}
          >
            {alert.title}
          </p>
        )}

        {time ? (
          <time
            dateTime={alert.at}
            title={time.absolute}
            className="shrink-0 font-mono text-meta tabular-nums text-ink-3"
          >
            {time.text}
          </time>
        ) : (
          <NotMeasured what="Alert timestamp" className="shrink-0 text-meta" />
        )}
      </div>

      {alert.detail && (
        <p className="text-meta leading-relaxed text-ink-2">{alert.detail}</p>
      )}

      <div className="flex flex-wrap items-center gap-2">
        {alert.source && <SourceBadge source={alert.source} size="sm" />}
        {alert.scope && (
          <span className="truncate font-mono text-meta text-ink-3">{alert.scope}</span>
        )}

        {acked && (
          <span className="inline-flex items-center rounded bg-surface-subtle px-1.5 py-0.5 text-nano font-bold uppercase tracking-[0.04em] text-ink-3">
            Acknowledged
          </span>
        )}

        <div className="ml-auto flex shrink-0 items-center gap-3">
          {!acked && alert.onAck && (
            <button
              type="button"
              onClick={alert.onAck}
              className="rounded text-meta font-bold text-teal-ink transition-colors duration-fast hover:text-teal-hover focus-visible:outline-none focus-visible:shadow-focus"
            >
              {ackLabel}
            </button>
          )}
          {alert.onOpen && (
            <button
              type="button"
              onClick={alert.onOpen}
              className="inline-flex items-center gap-1 rounded text-meta font-bold text-teal-ink transition-colors duration-fast hover:text-teal-hover focus-visible:outline-none focus-visible:shadow-focus"
            >
              {openLabel}
              <navIcon.forward size={ICON_SIZE.dense} aria-hidden />
            </button>
          )}
        </div>
      </div>
    </li>
  );
}
