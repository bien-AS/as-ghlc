"use client";

import { useMemo, type ComponentPropsWithoutRef, type ReactNode } from "react";
import { cn } from "../../lib/cn";
import { navIcon, ICON_SIZE } from "../../lib/icons";
import { Button, Card, CardHeader, CardTitle, DeltaPill, Eyebrow } from "../primitives";
import { RankPill } from "../pills";
import { EmptyState, NotMeasured, PanelSkeleton } from "./empty-state";

/**
 * MoversPanel — the biggest rank movements this cycle (S-03).
 *
 * DIRECTION CONVENTION — READ THIS BEFORE CHANGING ANYTHING HERE.
 *
 * A LOWER RANK NUMBER IS BETTER. Rank 1 is the top of the page; rank 40 is
 * nowhere. So:
 *
 *     14 → 6   delta = to - from = −8   the number went DOWN   this is a GAIN
 *      6 → 14  delta = to - from = +8   the number went UP     this is a LOSS
 *
 * Every arithmetic and visual decision in this file follows from that:
 *
 *   - Gainers are `delta < 0`, sorted most-negative first (biggest gain first).
 *   - Losers are `delta > 0`, sorted most-positive first (biggest loss first).
 *   - `DeltaPill` is passed `goodDirection="down"`, which is what decouples
 *     "which way the number moved" from "whether that is good". Without it the
 *     pill paints a −8 improvement in danger red.
 *   - The section headings do NOT carry trend arrows. An up-arrow over a column
 *     whose rows all show down-arrows is the single most confusing thing this
 *     panel could do, so the headings say it in words instead: "moved toward 1"
 *     / "moved away from 1".
 *
 * Get the sign backwards and the panel silently inverts: every win is shown as
 * a loss and the operator chases campaigns that are actually working.
 *
 * NOT MEASURED IS NOT A MOVE. A row with a null `from` or `to` has no delta —
 * not a delta of zero. Treating an unmeasured endpoint as rank 0 would
 * manufacture the largest gain on the board out of a failed scan, so those rows
 * are pulled into their own group and are counted in neither column.
 *
 * Unchanged rows (`delta === 0`) are not movers either, so they are not listed
 * — but they are COUNTED in the footer, because a row that silently disappears
 * from every group is a row the operator will assume was dropped.
 */

export interface MoverItem {
  id: string;
  label: string;
  sublabel?: string;
  /** Rank at the start of the cycle. `null` = NOT MEASURED, never zero. */
  from: number | null;
  /** Rank now. `null` = NOT MEASURED, never zero. */
  to: number | null;
}

export interface MoversPanelProps extends Omit<ComponentPropsWithoutRef<"div">, "title"> {
  items: MoverItem[];
  title?: string;
  /** Rows shown per column. The rest are summarised, never silently dropped. */
  limit?: number;
  loading?: boolean;
  /** Provider not connected. Takes precedence over empty. */
  notConnected?: { provider: string; onConnect?: () => void };
  filtered?: boolean;
  onClearFilters?: () => void;
  emptyTitle?: string;
  emptyBody?: string;
  emptyAction?: ReactNode;
}

interface Move {
  item: MoverItem;
  /** `to - from`. Negative = moved toward rank 1 = a gain. */
  delta: number;
}

export function MoversPanel({
  items,
  title = "Biggest movers",
  limit = 5,
  loading = false,
  notConnected,
  filtered = false,
  onClearFilters,
  emptyTitle = "No movement this cycle",
  emptyBody = "No tracked term changed position since the last measurement. This panel fills in as soon as one does.",
  emptyAction,
  className,
  ...props
}: MoversPanelProps) {
  const { gainers, losers, unmeasured, unchanged } = useMemo(() => {
    const g: Move[] = [];
    const l: Move[] = [];
    const u: MoverItem[] = [];
    let flat = 0;

    for (const item of items) {
      if (
        item.from == null || item.to == null ||
        !Number.isFinite(item.from) || !Number.isFinite(item.to)
      ) {
        u.push(item);
        continue;
      }
      const delta = item.to - item.from;
      if (delta < 0) g.push({ item, delta });
      else if (delta > 0) l.push({ item, delta });
      else flat += 1;
    }

    g.sort((a, b) => a.delta - b.delta); // most negative first = biggest gain
    l.sort((a, b) => b.delta - a.delta); // most positive first = biggest loss
    return { gainers: g, losers: l, unmeasured: u, unchanged: flat };
  }, [items]);

  const nothingToShow =
    gainers.length === 0 && losers.length === 0 && unmeasured.length === 0 && unchanged === 0;

  return (
    <Card padding="none" className={cn("overflow-hidden", className)} {...props}>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {items.length > 0 && (
          <span className="ml-auto font-mono text-meta tabular-nums text-ink-3">
            <span className="font-bold text-ink-2">{gainers.length}</span> up
            {" · "}
            <span className="font-bold text-ink-2">{losers.length}</span> down
          </span>
        )}
      </CardHeader>

      {loading ? (
        <PanelSkeleton rows={4} label="Loading rank movements" />
      ) : notConnected ? (
        <EmptyState
          variant="notConnected"
          provider={notConnected.provider}
          title={`${notConnected.provider} is not connected`}
          body="Rank movement cannot be computed without a measurement to compare against. Connect the source — a blank movers panel is not a flat cycle."
          action={
            notConnected.onConnect && (
              <Button size="sm" onClick={notConnected.onConnect}>
                Connect {notConnected.provider}
              </Button>
            )
          }
        />
      ) : nothingToShow ? (
        filtered ? (
          <EmptyState
            variant="filtered"
            title="No movers match"
            body="Movement exists this cycle; the current filters hide all of it."
            action={
              onClearFilters && (
                <Button size="sm" variant="secondary" onClick={onClearFilters}>
                  Clear filters
                </Button>
              )
            }
          />
        ) : (
          <EmptyState variant="empty" title={emptyTitle} body={emptyBody} action={emptyAction} />
        )
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2">
            <MoverColumn
              heading="Gainers"
              caption="moved toward 1"
              moves={gainers}
              limit={limit}
              emptyLine="No term improved this cycle."
              className="md:border-r md:border-r-line"
            />
            <MoverColumn
              heading="Losers"
              caption="moved away from 1"
              moves={losers}
              limit={limit}
              emptyLine="No term lost ground this cycle."
            />
          </div>

          {unmeasured.length > 0 && (
            <section className="border-t border-line">
              <div className="flex items-baseline gap-2 bg-surface-subtle px-4 py-2">
                <Eyebrow>Not measured</Eyebrow>
                <span className="font-mono text-meta tabular-nums text-ink-3">
                  {unmeasured.length}
                </span>
                <span className="text-meta text-ink-3">
                  · no movement is claimed for these — one endpoint is missing
                </span>
              </div>
              <ul className="flex flex-col">
                {unmeasured.map((item) => (
                  <li
                    key={item.id}
                    className="flex flex-wrap items-center gap-x-3 gap-y-1.5 border-b border-line-subtle px-4 py-2.5 last:border-b-0"
                  >
                    <MoverLabel item={item} />
                    <RankSpan from={item.from} to={item.to} />
                    <NotMeasured what="Rank movement" withLabel className="shrink-0" />
                  </li>
                ))}
              </ul>
            </section>
          )}

          {unchanged > 0 && (
            <div className="border-t border-line px-4 py-2 text-meta text-ink-3">
              <span className="font-mono font-bold tabular-nums text-ink-2">{unchanged}</span>{" "}
              {unchanged === 1 ? "term held" : "terms held"} position — unchanged, so not counted
              as a move.
            </div>
          )}
        </>
      )}
    </Card>
  );
}

function MoverColumn({
  heading, caption, moves, limit, emptyLine, className,
}: {
  heading: string;
  caption: string;
  moves: Move[];
  limit: number;
  emptyLine: string;
  className?: string;
}) {
  const shown = moves.slice(0, limit);
  const hidden = moves.length - shown.length;

  return (
    <section className={cn("flex flex-col", className)}>
      <div className="flex items-baseline gap-2 border-b border-line bg-surface-subtle px-4 py-2">
        <Eyebrow>{heading}</Eyebrow>
        <span className="font-mono text-meta tabular-nums text-ink-3">{moves.length}</span>
        {/* Words, not an arrow. See the direction note at the top of the file. */}
        <span className="ml-auto text-meta text-ink-3">{caption}</span>
      </div>

      {shown.length === 0 ? (
        // A short line, not a full EmptyState: two of those side by side in a
        // two-column panel is more chrome than content.
        <p className="px-4 py-6 text-center text-meta text-ink-3">{emptyLine}</p>
      ) : (
        <ul className="flex flex-col">
          {shown.map(({ item, delta }) => (
            <li
              key={item.id}
              className="flex flex-wrap items-center gap-x-3 gap-y-1.5 border-b border-line-subtle px-4 py-2.5 last:border-b-0"
            >
              <MoverLabel item={item} />
              <RankSpan from={item.from} to={item.to} />
              <DeltaPill
                className="shrink-0"
                value={delta}
                // Positions, not percent — and singular when it is one.
                label={Math.abs(delta) === 1 ? "position" : "positions"}
                suffix=""
                precision={0}
                // The whole convention in one prop: down is good for rank.
                goodDirection="down"
              />
            </li>
          ))}
        </ul>
      )}

      {hidden > 0 && (
        <p className="px-4 pb-3 pt-1 text-meta text-ink-3">
          <span className="font-mono font-bold tabular-nums text-ink-2">{hidden}</span> more not
          shown.
        </p>
      )}
    </section>
  );
}

function MoverLabel({ item }: { item: MoverItem }) {
  return (
    <div className="min-w-0 flex-1">
      <p className="truncate text-small font-semibold text-ink">{item.label}</p>
      {item.sublabel && <p className="truncate text-meta text-ink-3">{item.sublabel}</p>}
    </div>
  );
}

/** from → to. RankPill prints the number, so the band colour is never alone. */
function RankSpan({ from, to }: { from: number | null; to: number | null }) {
  return (
    <span className="flex shrink-0 items-center gap-1.5">
      <RankPill rank={from} />
      <navIcon.forward size={ICON_SIZE.dense} aria-hidden className="text-ink-3" />
      {/* The arrow is decorative, so the relationship between the two pills is
          supplied in words. The ranks themselves are NOT repeated here — the
          pills already announce them, and duplicating gives "6 14 from 6 to 14". */}
      <span className="sr-only">moved to</span>
      <RankPill rank={to} />
    </span>
  );
}
