import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { cn } from "../../lib/cn";
import { actionIcon, entityIcon, ICON_SIZE } from "../../lib/icons";

/**
 * EmptyState — the generalised form of `data-table.tsx`'s `StateBlock`.
 *
 * WHY THIS IS A COMPONENT AND NOT A `<p>`
 *
 * "Nothing is here" has three completely different causes, and the reader
 * cannot tell them apart from an empty box:
 *
 *   filtered      Rows exist. The current search/filters hide them. The way
 *                 out is CLEAR FILTERS.
 *   empty         No rows have ever existed. The way out is the primary CTA
 *                 that creates the first one.
 *   notConnected  Rows may well exist upstream. The data is not missing, the
 *                 CONNECTION is. The way out is connecting the provider.
 *
 * Show the wrong one and you send someone hunting for data that never existed,
 * or hunting for a filter they never set, or — worst — reading "no alerts" as
 * "no problems" when the truth is that nothing was ever checked. That last
 * failure is why `notConnected` exists as a first-class variant rather than
 * being folded into `empty`, and why `variant` is REQUIRED: there is no safe
 * default, so the caller has to decide.
 *
 * The variant is also stated in words, above the title, for `filtered` and
 * `notConnected`. Tone alone is not an encoding (see the colour rule) and the
 * distinction is the entire point of the component.
 *
 * `PanelSkeleton` and `NotMeasured` live here too. All three answer the same
 * question — "what does this panel render when it has nothing real to show" —
 * and keeping them together stops each panel from re-inventing its own loading
 * shimmer and its own em-dash.
 */

export const EMPTY_STATE_VARIANTS = ["empty", "filtered", "notConnected"] as const;
export type EmptyStateVariant = (typeof EMPTY_STATE_VARIANTS)[number];

export interface EmptyStateProps extends Omit<ComponentPropsWithoutRef<"div">, "title"> {
  /**
   * Required on purpose. See the note above: guessing produces a state block
   * that actively misdirects, which is worse than no state block at all.
   */
  variant: EmptyStateVariant;
  title: string;
  body: string;
  /** The way out. `filtered` should offer Clear filters; `empty`, the primary CTA. */
  action?: ReactNode;
  /** Pass `null` to suppress the default glyph entirely. */
  icon?: ReactNode;
  /**
   * `notConnected` only — names WHICH connection is missing. Without it the
   * reader is told something is unplugged but not what to go and plug in.
   */
  provider?: string;
}

/** 24px is the AS empty-state size; see the size note in `lib/icons.ts`. */
const DEFAULT_ICON: Record<EmptyStateVariant, ReactNode> = {
  // Eye = the filter/search affordance the table toolbar already uses.
  filtered: <actionIcon.view size={ICON_SIZE.empty} aria-hidden />,
  empty: <entityIcon.document size={ICON_SIZE.empty} aria-hidden />,
  // Network = a link that is not made, not a document that is absent.
  notConnected: <entityIcon.hierarchy size={ICON_SIZE.empty} aria-hidden />,
};

export function EmptyState({
  variant, title, body, action, icon, provider, className, ...props
}: EmptyStateProps) {
  // `undefined` means "use the default"; explicit `null` means "no glyph".
  const glyph = icon === undefined ? DEFAULT_ICON[variant] : icon;

  return (
    <div
      className={cn("flex flex-col items-center gap-2 px-6 py-14 text-center", className)}
      {...props}
    >
      {glyph && <span className="mb-1 text-ink-3">{glyph}</span>}

      {variant === "filtered" && (
        <span className="inline-flex items-center rounded bg-surface-subtle px-2 py-1 text-micro font-bold uppercase tracking-[0.04em] text-ink-2">
          Filtered view
        </span>
      )}

      {variant === "notConnected" && (
        // amber-soft ground, amber-INK text. The base `text-amber` on this
        // tint measures ~2.9:1 in light mode and fails.
        <span className="inline-flex items-center rounded bg-amber-soft px-2 py-1 text-micro font-bold uppercase tracking-[0.04em] text-amber-ink">
          Not connected
          {provider && <span className="ml-1.5 font-mono normal-case">{provider}</span>}
        </span>
      )}

      <p className="text-small font-bold text-ink">{title}</p>
      <p className="max-w-[42ch] text-meta leading-relaxed text-ink-2">{body}</p>
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}

/* ================================================================== *
 * PanelSkeleton
 *
 * Same contract as `TableSkeleton`: `aria-busy` + a polite live region
 * so a screen reader is told the panel is loading rather than told it
 * is empty, and `motion-reduce:animate-none` so the shimmer is not
 * forced on anyone.
 * ================================================================== */
export interface PanelSkeletonProps extends ComponentPropsWithoutRef<"div"> {
  rows?: number;
  /** What is loading — announced, not painted. */
  label?: string;
}

export function PanelSkeleton({
  rows = 4, label = "Loading", className, ...props
}: PanelSkeletonProps) {
  return (
    <div
      className={cn("flex flex-col gap-3 p-4", className)}
      aria-busy="true"
      aria-live="polite"
      {...props}
    >
      <span className="sr-only">{label}</span>
      {Array.from({ length: rows }).map((_, r) => (
        <div key={r} className="flex items-center gap-3">
          <div
            className="size-8 shrink-0 animate-pulse rounded-md bg-surface-inset motion-reduce:animate-none"
            style={{ animationDelay: `${r * 60}ms` }}
          />
          <div className="flex min-w-0 flex-1 flex-col gap-1.5">
            <div
              className="h-3 w-2/5 animate-pulse rounded bg-surface-inset motion-reduce:animate-none"
              style={{ animationDelay: `${r * 60}ms` }}
            />
            <div
              className="h-2.5 w-3/5 animate-pulse rounded bg-surface-inset motion-reduce:animate-none"
              style={{ animationDelay: `${r * 60 + 30}ms` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

/* ================================================================== *
 * NotMeasured
 *
 * `null` means NOT MEASURED. It never means zero, and it never means
 * "absent from results" — a scan that failed must not render as a
 * rank-20 result or a zero-day delay.
 *
 * The em-dash alone is ambiguous, so it always ships with an
 * explanation: a `title` for pointer users, an `sr-only` sentence for
 * assistive tech, and an optional visible label where the row has room.
 * ================================================================== */
export interface NotMeasuredProps extends Omit<ComponentPropsWithoutRef<"span">, "title"> {
  /** What was not measured, e.g. "Rank movement". Sharpens the affordance. */
  what?: string;
  /** Print "Not measured" beside the dash. Use where the layout allows it. */
  withLabel?: boolean;
}

export function NotMeasured({ what, withLabel = false, className, ...props }: NotMeasuredProps) {
  const reason = what ? `${what} — not measured` : "Not measured";
  return (
    <span
      className={cn("inline-flex items-baseline gap-1.5 text-ink-3", className)}
      title={reason}
      {...props}
    >
      <span aria-hidden className="font-mono tabular-nums">—</span>
      {withLabel ? (
        <span aria-hidden className="text-micro font-bold uppercase tracking-[0.04em]">
          Not measured
        </span>
      ) : null}
      <span className="sr-only">{reason}</span>
    </span>
  );
}
