"use client";

import { useMemo, type ComponentPropsWithoutRef, type ReactNode } from "react";
import { cn } from "../../lib/cn";
import type { Severity } from "../../lib/icons";
import { Button, Card, CardHeader, CardTitle } from "../primitives";
import { SeverityDot } from "../pills";
import { EmptyState, NotMeasured, PanelSkeleton } from "./empty-state";

/**
 * RoadblockPanel — stalled work that needs a human (S-03 overview).
 *
 * THE NUMBER IS THE HEADLINE, NOT THE TITLE.
 *
 * This panel exists to make stalling undeniable. "Waiting on client copy" reads
 * as a normal state of affairs; "41 days · waiting on client copy" does not.
 * So days-blocked is set as the largest type in the row, in the leading
 * position, before the task name — the opposite of how a task list is normally
 * laid out, and deliberately so. A roadblock panel that leads with titles gets
 * skimmed; the ages are what force the conversation.
 *
 * Sorted longest-blocked first for the same reason. The worst item is the one
 * that most needs saying out loud, and it must not be reachable only by
 * scrolling.
 *
 * `blockedSince` that does not parse renders as NOT MEASURED — never as day
 * zero. A missing start date would otherwise sort a genuinely old blocker to
 * the bottom and print a reassuring "0 days" next to it.
 *
 * The empty state states the fact plainly: "Nothing blocked." No exclamation
 * mark — the AS voice rule forbids them, and an internal ops tool congratulating
 * its operator is exactly the tone this product is not.
 */

export interface RoadblockItem {
  id: string;
  title: string;
  /** ISO 8601 date or timestamp. Unparseable renders as not-measured, sorts last. */
  blockedSince: string;
  owner?: string;
  /** What is actually blocking it. Required — "blocked" alone is not actionable. */
  reason: string;
  severity: Severity;
  onResolve?: () => void;
}

export interface RoadblockPanelProps extends Omit<ComponentPropsWithoutRef<"div">, "title"> {
  items: RoadblockItem[];
  title?: string;
  loading?: boolean;
  /** Provider not connected. Takes precedence over empty — silence is not "nothing blocked". */
  notConnected?: { provider: string; onConnect?: () => void };
  filtered?: boolean;
  onClearFilters?: () => void;
  emptyTitle?: string;
  emptyBody?: string;
  emptyAction?: ReactNode;
  /** Pin "now" for deterministic SSR and tests. */
  now?: number;
  resolveLabel?: string;
}

const DAY = 86_400_000;

/**
 * Tone for the day count. Every one of these is an `*-ink` on its matching
 * `*-soft` — the base `text-danger` / `text-amber` on their own tint measure
 * under 3:1 in light mode.
 *
 * `info` gets the neutral inset chip rather than a third hue: the count and the
 * SeverityDot already carry the grade, and a third colour here would compete
 * with the two that mean something.
 */
const COUNT_CHIP: Record<Severity, string> = {
  critical: "bg-danger-soft text-danger-ink",
  moderate: "bg-amber-soft text-amber-ink",
  info: "bg-surface-inset text-ink",
};

/** Whole days blocked, or `null` when `blockedSince` cannot be read. */
export function daysBlocked(blockedSince: string, nowMs: number): number | null {
  const t = Date.parse(blockedSince);
  if (!Number.isFinite(t)) return null;
  // Clamp at 0: a future start date is a data error, not negative blockage.
  return Math.max(0, Math.floor((nowMs - t) / DAY));
}

export function RoadblockPanel({
  items,
  title = "Roadblocks",
  loading = false,
  notConnected,
  filtered = false,
  onClearFilters,
  emptyTitle = "Nothing blocked",
  emptyBody = "No task on this campaign is waiting on a human right now. This panel fills in the moment one stalls.",
  emptyAction,
  now = Date.now(),
  resolveLabel = "Resolve",
  className,
  ...props
}: RoadblockPanelProps) {
  const ranked = useMemo(() => {
    // slice() first — never sort the caller's array in place.
    return items
      .map((item) => ({ item, days: daysBlocked(item.blockedSince, now) }))
      .slice()
      .sort((a, b) => {
        // Not-measured sorts last, in the same direction, always.
        if (a.days == null && b.days == null) return 0;
        if (a.days == null) return 1;
        if (b.days == null) return -1;
        return b.days - a.days;
      });
  }, [items, now]);

  const longest = ranked.find((r) => r.days != null)?.days ?? null;

  return (
    <Card padding="none" className={cn("overflow-hidden", className)} {...props}>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {items.length > 0 && (
          <span className="ml-auto font-mono text-meta tabular-nums text-ink-3">
            <span className="font-bold text-ink-2">{items.length}</span> blocked
            {longest != null && (
              <>
                {" · longest "}
                <span className="font-bold text-ink-2">{longest}</span>
                {longest === 1 ? " day" : " days"}
              </>
            )}
          </span>
        )}
      </CardHeader>

      {loading ? (
        <PanelSkeleton rows={3} label="Loading roadblocks" />
      ) : notConnected ? (
        <EmptyState
          variant="notConnected"
          provider={notConnected.provider}
          title={`${notConnected.provider} is not connected`}
          body="Delivery status cannot be read, so this panel is blank. That is not the same as nothing being blocked — connect the source before treating it as an all-clear."
          action={
            notConnected.onConnect && (
              <Button size="sm" onClick={notConnected.onConnect}>
                Connect {notConnected.provider}
              </Button>
            )
          }
        />
      ) : ranked.length === 0 ? (
        filtered ? (
          <EmptyState
            variant="filtered"
            title="No roadblocks match"
            body="Blocked work exists; the current filters hide all of it."
            action={
              onClearFilters && (
                <Button size="sm" variant="secondary" onClick={onClearFilters}>
                  Clear filters
                </Button>
              )
            }
          />
        ) : (
          <EmptyState variant="empty" title={emptyTitle} body={emptyBody} action={emptyAction} />
        )
      ) : (
        <ul className="flex flex-col">
          {ranked.map(({ item, days }) => (
            <li
              key={item.id}
              className="flex items-start gap-3 border-b border-line-subtle px-4 py-3 last:border-b-0"
            >
              {/* The headline. Leading position, largest type in the row. */}
              {days == null ? (
                <div
                  className="flex w-16 shrink-0 items-center justify-center rounded-md bg-surface-inset px-2 py-4"
                >
                  <NotMeasured what="Days blocked" />
                </div>
              ) : (
                <div
                  className={cn(
                    "flex w-16 shrink-0 flex-col items-center rounded-md px-2 py-2",
                    COUNT_CHIP[item.severity],
                  )}
                >
                  <span className="font-mono text-[22px] font-bold leading-none tabular-nums">
                    {days}
                  </span>
                  <span className="mt-1 text-nano font-bold uppercase tracking-[0.06em]">
                    {days === 1 ? "day" : "days"}
                  </span>
                  {/* Colour is never the only encoding, and "41 days" alone
                      does not say days of WHAT. */}
                  <span className="sr-only">blocked</span>
                </div>
              )}

              <div className="flex min-w-0 flex-1 flex-col gap-1.5">
                <div className="flex items-start justify-between gap-3">
                  <p className="min-w-0 text-small font-semibold leading-snug text-ink">
                    {item.title}
                  </p>
                  <SeverityDot severity={item.severity} className="shrink-0" />
                </div>

                <p className="text-meta leading-relaxed text-ink-2">{item.reason}</p>

                <div className="flex flex-wrap items-center gap-3">
                  {item.owner ? (
                    <span className="text-meta text-ink-3">
                      Owner <span className="font-semibold text-ink-2">{item.owner}</span>
                    </span>
                  ) : (
                    // An unowned blocker is the worst kind — it is nobody's to
                    // clear — so the gap is stated rather than left blank.
                    <span className="text-meta text-ink-3">Unassigned</span>
                  )}

                  {item.onResolve && (
                    <Button
                      size="sm"
                      variant="secondary"
                      className="ml-auto"
                      onClick={item.onResolve}
                    >
                      {resolveLabel}
                    </Button>
                  )}
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
