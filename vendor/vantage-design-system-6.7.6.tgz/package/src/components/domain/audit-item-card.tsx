"use client";

import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { cn } from "../../lib/cn";
import type { AuditState, SourceId } from "../../lib/icons";
import { Button, Card, Eyebrow } from "../primitives";
import { SourceBadge, StatusPill } from "../pills";
import { NotMeasured, PanelSkeleton } from "./empty-state";

/**
 * AuditItemCard — one row of the Baptist 16-point scorecard.
 *
 * `whyItMatters` IS REQUIRED, AND THAT IS THE POINT OF THE COMPONENT.
 *
 * A scorecard that prints "Fail" against "NAP consistency" and stops has told
 * the reader nothing they can act on. It produces the two failure modes this
 * card exists to prevent: an item gets ignored because nobody knows what it
 * costs, or it gets escalated past items that matter far more. Every failing
 * item has to end in a verb, and the sentence that gets it there is this one —
 * so it is a required prop, not an optional flourish a caller can forget.
 *
 * A CHECK WHOSE SOURCE IS NOT CONNECTED CANNOT HAVE PASSED. When `notConnected`
 * is set the state is forced to `unknown` regardless of what the caller passed,
 * and the missing provider is named on the card. Rendering a stale `pass` for a
 * check nobody ran is the most expensive lie this scorecard could tell: it
 * moves an unverified item into the "done" column.
 *
 * The card's left-border tone repeats what the StatusPill already says in
 * words. Redundant by design — the tone is never the only encoding.
 */

export interface AuditItemCardProps extends Omit<ComponentPropsWithoutRef<"div">, "title"> {
  /** 1-based position in the scorecard. Printed, so the reader can cite it. */
  index: number;
  title: string;
  subtitle?: string;
  /** Required. What breaks if this item stays as it is. */
  whyItMatters: string;
  state: AuditState;
  /** Provenance. Absent renders as not-measured, never as a silent blank. */
  source?: SourceId;
  /** The verb. Usually a Button. */
  action?: ReactNode;
  loading?: boolean;
  /**
   * Provider not connected. Forces `state` to `unknown` — see the note above.
   */
  notConnected?: { provider: string; onConnect?: () => void };
}

/** Matches `Card`'s `tone` variant: a 3px left border, no fill, no shadow. */
const TONE: Record<AuditState, "default" | "teal" | "amber" | "danger"> = {
  pass: "teal",
  verified: "teal",
  attention: "amber",
  fail: "danger",
  unknown: "default",
};

export function AuditItemCard({
  index, title, subtitle, whyItMatters, state, source, action,
  loading = false, notConnected, className, ...props
}: AuditItemCardProps) {
  if (loading) {
    return (
      <Card padding="none" className={cn("overflow-hidden", className)} {...props}>
        <PanelSkeleton rows={2} label={`Loading check ${index}`} />
      </Card>
    );
  }

  // An unconnected source cannot produce a verdict. Anything else here would
  // let a check nobody ran read as a check that passed.
  const effectiveState: AuditState = notConnected ? "unknown" : state;

  return (
    <Card
      padding="none"
      tone={TONE[effectiveState]}
      className={cn("overflow-hidden", className)}
      {...props}
    >
      <div className="flex items-start gap-3 px-4 pt-4">
        <span
          aria-hidden
          className="grid size-7 shrink-0 place-items-center rounded-md bg-surface-inset font-mono text-meta font-bold tabular-nums text-ink-2"
        >
          {index}
        </span>

        <div className="min-w-0 flex-1">
          <h4 className="text-small font-bold leading-snug text-ink">
            {/* The chip is aria-hidden, so the position is restored here — a
                screen-reader user has to be able to say "item 7" too. */}
            <span className="sr-only">Check {index}: </span>
            {title}
          </h4>
          {subtitle && <p className="mt-0.5 text-meta leading-snug text-ink-3">{subtitle}</p>}
        </div>

        <StatusPill state={effectiveState} className="shrink-0" />
      </div>

      <div className="mx-4 mt-3 rounded-md bg-surface-subtle px-3 py-2.5">
        <Eyebrow>Why it matters</Eyebrow>
        <p className="mt-1 text-meta leading-relaxed text-ink-2">{whyItMatters}</p>
      </div>

      <div className="flex flex-wrap items-center gap-2 px-4 pb-4 pt-3">
        {source ? (
          <SourceBadge source={source} size="sm" />
        ) : (
          <NotMeasured what="Provenance" withLabel />
        )}

        {notConnected && (
          // amber-soft ground, amber-INK text — the base amber on its own tint
          // fails contrast in light mode.
          <span className="inline-flex items-center gap-1.5 rounded bg-amber-soft px-1.5 py-0.5 text-nano font-bold uppercase tracking-[0.04em] text-amber-ink">
            Not connected
            <span className="font-mono normal-case">{notConnected.provider}</span>
          </span>
        )}

        <div className="ml-auto flex shrink-0 flex-wrap items-center gap-2">
          {notConnected?.onConnect && (
            <Button size="sm" variant="secondary" onClick={notConnected.onConnect}>
              Connect {notConnected.provider}
            </Button>
          )}
          {action}
        </div>
      </div>
    </Card>
  );
}
