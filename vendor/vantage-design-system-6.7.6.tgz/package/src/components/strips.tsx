"use client";

import { cva, type VariantProps } from "class-variance-authority";
import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { cn } from "../lib/cn";
import { navIcon, ICON_SIZE } from "../lib/icons";
import { ScoreBadge } from "./primitives";

/**
 * Slim context strips. All share one shape: a 3px left border in a tone that
 * says what kind of context this is, a tinted ground, and an optional
 * right-aligned pivot action.
 */
const strip = cva(
  "flex items-center justify-between gap-4 rounded-lg border-l-[3px] px-4",
  {
    variants: {
      tone: {
        teal: "border-l-teal bg-teal/5",
        amber: "border-l-amber bg-amber/5",
        danger: "border-l-danger bg-danger/5",
        neutral: "border-l-ink-3 bg-surface-hover",
      },
      density: { tight: "py-2.5", default: "py-3" },
    },
    defaultVariants: { tone: "teal", density: "default" },
  },
);

/* ================================================================== *
 * ScopeBanner — sits directly below the top bar on every scoped
 * screen, so it is always clear what a run or an edit will apply to.
 * ================================================================== */
export interface ScopeBannerProps
  extends Omit<ComponentPropsWithoutRef<"div">, "onSelect">, VariantProps<typeof strip> {
  scope?: "page" | "domain" | "system";
  label: ReactNode;
  meta?: ReactNode;
  switcherLabel?: string;
  onSwitch?: () => void;
}

export function ScopeBanner({
  scope = "page", label, meta, switcherLabel, onSwitch, className, ...props
}: ScopeBannerProps) {
  return (
    <div
      className={cn(strip({ tone: scope === "system" ? "neutral" : "teal" }), "text-small text-ink-2", className)}
      {...props}
    >
      <div className="flex min-w-0 flex-wrap items-baseline gap-x-3 gap-y-1">
        <span className="font-semibold text-ink">{label}</span>
        {meta && <span className="text-ink-3">{meta}</span>}
      </div>
      {switcherLabel && onSwitch && (
        <button
          type="button"
          onClick={onSwitch}
          className="inline-flex shrink-0 items-center gap-1 rounded text-meta font-bold text-teal-ink transition-colors duration-fast hover:text-teal-hover focus-visible:outline-none focus-visible:shadow-focus"
        >
          {switcherLabel}
          <navIcon.expand size={ICON_SIZE.dense} aria-hidden />
        </button>
      )}
    </div>
  );
}

/* ================================================================== *
 * ParentDomainStrip — the page -> domain pivot. A page score is never
 * meaningful without its domain context, so this rides along with it.
 * ================================================================== */
export interface ParentDomainStripProps extends ComponentPropsWithoutRef<"div"> {
  domain: string;
  domainScore?: number;
  dr?: number;
  trackedPageCount?: number;
  onViewDomain?: () => void;
}

export function ParentDomainStrip({
  domain, domainScore, dr, trackedPageCount, onViewDomain, className, ...props
}: ParentDomainStripProps) {
  return (
    <div
      className={cn(strip({ tone: "neutral", density: "tight" }), "text-meta text-ink-3", className)}
      {...props}
    >
      <div className="flex min-w-0 flex-wrap items-center gap-x-4 gap-y-1">
        <span>
          Part of <span className="font-mono font-bold text-ink-2">{domain}</span>
        </span>
        {domainScore != null && (
          <span className="inline-flex items-center gap-1.5">
            Domain score <ScoreBadge value={domainScore} />
          </span>
        )}
        {dr != null && (
          <span>
            DR <span className="font-mono font-bold tabular-nums text-ink-2">{dr}</span>
          </span>
        )}
        {trackedPageCount != null && (
          <span>
            <span className="font-mono font-bold tabular-nums text-ink-2">{trackedPageCount}</span>{" "}
            tracked {trackedPageCount === 1 ? "page" : "pages"}
          </span>
        )}
      </div>
      {onViewDomain && (
        <button
          type="button"
          onClick={onViewDomain}
          className="inline-flex shrink-0 items-center gap-1 rounded text-meta font-bold text-teal-ink transition-colors duration-fast hover:text-teal-hover focus-visible:outline-none focus-visible:shadow-focus"
        >
          View domain overview
          <navIcon.forward size={ICON_SIZE.dense} aria-hidden />
        </button>
      )}
    </div>
  );
}

/* ================================================================== *
 * GSCSyncStrip — Search Console connection state.
 *
 * GSC is a DATA PLATFORM, not an AI surface. It never participates in
 * the 6-surface taxonomy and never appears in a surface selector or a
 * per-surface cost. It keeps Google's own blue for accurate
 * attribution rather than taking an AS token.
 * ================================================================== */
export type GscState = "connected" | "reconnect" | "not-connected";

export interface GSCSyncStripProps extends ComponentPropsWithoutRef<"div"> {
  state?: GscState;
  connectedCount?: number;
  totalCount?: number;
  lastSyncedAt?: string;
  onConnect?: () => void;
}

export function GSCSyncStrip({
  state = "connected", connectedCount, totalCount, lastSyncedAt, onConnect,
  className, ...props
}: GSCSyncStripProps) {
  const hasCounts = connectedCount != null && totalCount != null;
  const message: Record<GscState, string> = {
    connected: hasCounts
      ? `Search Console: connected on ${connectedCount}/${totalCount} domains`
      : "Search Console: connected",
    reconnect: hasCounts
      ? `Search Console: ${totalCount - connectedCount} of ${totalCount} domains need reconnect`
      : "Search Console: needs reconnect",
    "not-connected": "Search Console: not connected",
  };
  const action: Record<GscState, string | null> = {
    connected: null, reconnect: "Reconnect", "not-connected": "Connect",
  };
  // `--gsc-blue-80`, not `bg-[var(--gsc-blue)]/80`. The modifier form compiled
  // to NOTHING — an arbitrary `var()` has no alpha slot for Tailwind to fill —
  // so the "connected" dot rendered with no background at all, an invisible
  // status indicator on the one state that is supposed to read as healthy.
  // The token file already carries the composited value and calls it "the
  // canonical GSC connected dot". Google's blue is a vendor colour, one of the
  // sanctioned exceptions to the no-literals rule, and does not flip by theme.
  const dotClass: Record<GscState, string> = {
    connected: "bg-[var(--gsc-blue-80)]", reconnect: "bg-amber", "not-connected": "bg-ink-4",
  };

  return (
    <div
      className={cn("flex items-center justify-between gap-4 px-4 py-2 text-meta text-ink-3", className)}
      {...props}
    >
      <span className="flex min-w-0 items-center gap-2">
        <span className={cn("size-2 shrink-0 rounded-full", dotClass[state])} aria-hidden />
        <span className="truncate">{message[state]}</span>
        {lastSyncedAt && state === "connected" && (
          <span className="shrink-0 font-mono text-ink-3">· synced {lastSyncedAt}</span>
        )}
      </span>
      {action[state] && onConnect && (
        <button
          type="button"
          onClick={onConnect}
          className="inline-flex shrink-0 items-center gap-1 rounded font-bold text-teal-ink transition-colors duration-fast hover:text-teal-hover focus-visible:outline-none focus-visible:shadow-focus"
        >
          {action[state]}
          <navIcon.forward size={ICON_SIZE.dense} aria-hidden />
        </button>
      )}
    </div>
  );
}
