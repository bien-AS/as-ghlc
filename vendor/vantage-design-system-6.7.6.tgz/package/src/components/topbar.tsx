"use client";

import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { cn } from "../lib/cn";
import { actionIcon, navIcon, ICON_SIZE } from "../lib/icons";

/**
 * TopBar / PageHeader.
 *
 * The Baptist page anatomy, which every screen follows so the operator always
 * knows where the title, the range and the primary action will be:
 *
 *   breadcrumb  ->  h1 + subtitle  ->  [range picker] [secondary] [PRIMARY]
 *
 * Exactly one primary action per header. If a screen seems to need two, one of
 * them is secondary.
 */

export type SaveState = "idle" | "saving" | "saved" | "error";

export interface AutoSaveIndicatorProps extends ComponentPropsWithoutRef<"span"> {
  state?: SaveState;
  lastSavedAt?: string;
}

export function AutoSaveIndicator({
  state = "saved", lastSavedAt, className, ...props
}: AutoSaveIndicatorProps) {
  const copy: Record<SaveState, string> = {
    idle: "",
    saving: "Saving…",
    saved: lastSavedAt ? `Saved ${lastSavedAt}` : "Saved",
    error: "Not saved — retry",
  };
  if (state === "idle") return null;

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 text-meta",
        state === "error" ? "text-danger-ink" : "text-ink-3",
        className,
      )}
      role="status"
      aria-live="polite"
      {...props}
    >
      {state === "saving" && (
        <actionIcon.refresh
          size={ICON_SIZE.dense}
          className="animate-spin motion-reduce:animate-none"
          aria-hidden
        />
      )}
      {copy[state]}
    </span>
  );
}

export interface LastSyncIndicatorProps extends ComponentPropsWithoutRef<"span"> {
  lastSyncedAt: string;
  /** Marks the data as past its refresh window. */
  stale?: boolean;
  onRefresh?: () => void;
}

export function LastSyncIndicator({
  lastSyncedAt, stale = false, onRefresh, className, ...props
}: LastSyncIndicatorProps) {
  return (
    <span
      className={cn("inline-flex items-center gap-1.5 text-meta", stale ? "text-amber-ink" : "text-ink-3", className)}
      {...props}
    >
      <span className="font-mono tabular-nums">
        {stale ? "Stale · " : "Synced "}
        {lastSyncedAt}
      </span>
      {onRefresh && (
        <button
          type="button"
          onClick={onRefresh}
          aria-label="Refresh now"
          className="rounded p-0.5 text-ink-3 transition-colors duration-fast hover:text-teal-ink focus-visible:outline-none focus-visible:shadow-focus"
        >
          <actionIcon.refresh size={ICON_SIZE.dense} aria-hidden />
        </button>
      )}
    </span>
  );
}

export interface Crumb {
  label: string;
  onClick?: () => void;
}

export interface TopBarProps extends ComponentPropsWithoutRef<"header"> {
  title: string;
  subtitle?: ReactNode;
  breadcrumbs?: Crumb[];
  /** Right-aligned cluster. Exactly one primary action. */
  actions?: ReactNode;
  meta?: ReactNode;
  sticky?: boolean;
}

export function TopBar({
  title, subtitle, breadcrumbs, actions, meta, sticky = true,
  className, ...props
}: TopBarProps) {
  return (
    <header
      className={cn(
        "flex flex-wrap items-start gap-4 border-b border-line bg-card px-8 py-6",
        sticky && "sticky top-0 z-10",
        className,
      )}
      {...props}
    >
      {/* min-w-[256px], not min-w-0: with a zero floor the title column shrinks
          toward nothing and `flex-wrap` on the header can never fire, so a
          narrow viewport squeezes the h1 to one word per line instead of
          dropping the action cluster onto its own row. */}
      <div className="min-w-[256px] flex-1">
        {breadcrumbs && breadcrumbs.length > 0 && (
          <nav aria-label="Breadcrumb" className="mb-1.5">
            <ol className="flex flex-wrap items-center gap-1 text-meta text-ink-3">
              {breadcrumbs.map((crumb, i) => (
                <li key={`${crumb.label}-${i}`} className="flex items-center gap-1">
                  {i > 0 && <navIcon.forward size={12} aria-hidden className="text-ink-3" />}
                  {crumb.onClick ? (
                    <button
                      type="button"
                      onClick={crumb.onClick}
                      className="rounded transition-colors duration-fast hover:text-teal-ink focus-visible:outline-none focus-visible:shadow-focus"
                    >
                      {crumb.label}
                    </button>
                  ) : (
                    <span aria-current={i === breadcrumbs.length - 1 ? "page" : undefined}>
                      {crumb.label}
                    </span>
                  )}
                </li>
              ))}
            </ol>
          </nav>
        )}

        <h1 className="text-[24px] font-bold leading-tight tracking-[-0.01em] text-ink">
          {title}
        </h1>

        {subtitle && <p className="mt-1 text-small text-ink-2">{subtitle}</p>}
        {meta && <div className="mt-2 flex flex-wrap items-center gap-3">{meta}</div>}
      </div>

      {actions && <div className="flex shrink-0 flex-wrap items-center gap-2">{actions}</div>}
    </header>
  );
}
