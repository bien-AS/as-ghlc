"use client";

import type { ComponentPropsWithoutRef } from "react";
import { cn } from "../lib/cn";
import { SurfaceIcon } from "./surface-badge";
import { CostPreview } from "./cost-preview";
import {
  SURFACE_CATEGORIES, SURFACE_IDS, SURFACE_META, costFor,
  getSurfacesByCategory, type SurfaceCategory, type SurfaceId,
} from "../lib/surfaces";

/**
 * SurfaceSelector — pick which AI surfaces a run covers.
 *
 * Every card shows its own per-call cost, and the footer shows the running
 * total, because this is the screen where an operator commits real money. The
 * category headers carry their optimisation note so the choice is informed:
 * adding AI Overviews is a schema play, adding Gemini is a brand-mention play.
 */
export interface SurfaceSelectorCardProps {
  surface: SurfaceId;
  selected: boolean;
  disabled?: boolean;
  onToggle: (id: SurfaceId) => void;
}

export function SurfaceSelectorCard({
  surface, selected, disabled = false, onToggle,
}: SurfaceSelectorCardProps) {
  const meta = SURFACE_META[surface];
  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={selected}
      aria-label={`${meta.name} — $${meta.cost.toFixed(3)} per keyword`}
      disabled={disabled}
      onClick={() => onToggle(surface)}
      className={cn(
        "flex flex-col items-start gap-2 rounded-lg border p-3 text-left transition-colors duration-fast ease-standard",
        "focus-visible:outline-none focus-visible:shadow-focus",
        "disabled:cursor-not-allowed disabled:opacity-50",
        // Both branches need hover. This is a toggle — clicking a SELECTED
        // tile deselects it — so the selected state having no hover left the
        // most consequential click in the group with no affordance at all.
        // Selected deepens its own tint rather than borrowing the neutral
        // hover, which would read as "no longer selected".
        selected
          ? "border-teal bg-teal/10 hover:bg-teal/20"
          : "border-line bg-card hover:border-line-strong hover:bg-surface-hover",
      )}
    >
      <span className="flex w-full items-center gap-2">
        <SurfaceIcon surface={surface} size={18} style={{ color: meta.color }} />
        <span className="text-small font-bold leading-tight text-ink">{meta.name}</span>
        <span
          className={cn(
            "ml-auto grid size-4 shrink-0 place-items-center rounded-sm border",
            selected ? "border-teal bg-teal text-ink-on-teal" : "border-line-field",
          )}
          aria-hidden
        >
          {selected && (
            <svg viewBox="0 0 10 10" className="size-2.5" fill="none" stroke="currentColor" strokeWidth={2}>
              <path d="M1.5 5.2 L4 7.5 L8.5 2.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          )}
        </span>
      </span>
      <span className="font-mono text-meta tabular-nums text-ink-3">
        ${meta.cost.toFixed(3)} <span className="text-ink-3">/ keyword</span>
      </span>
    </button>
  );
}

export function SurfaceCategoryHeader({
  category, count,
}: { category: SurfaceCategory; count: number }) {
  const meta = SURFACE_CATEGORIES[category];
  return (
    <div className="flex flex-col gap-0.5">
      <span className="flex items-baseline gap-2">
        <span className="text-micro font-bold uppercase tracking-[0.06em] text-ink-3">
          {meta.label}
        </span>
        <span className="font-mono text-nano tabular-nums text-ink-3">{count}</span>
      </span>
      <span className="text-meta leading-snug text-ink-3">{meta.note}</span>
    </div>
  );
}

export interface SurfaceSelectorProps extends Omit<ComponentPropsWithoutRef<"div">, "onChange"> {
  surfaces?: readonly SurfaceId[];
  selected: readonly SurfaceId[];
  onChange: (next: SurfaceId[]) => void;
  showCategoryHeaders?: boolean;
  /** Keywords in the run — drives the total. */
  keywordCount?: number;
  disabled?: readonly SurfaceId[];
}

export function SurfaceSelector({
  surfaces = SURFACE_IDS, selected, onChange, showCategoryHeaders = true,
  keywordCount = 1, disabled = [], className, ...props
}: SurfaceSelectorProps) {
  const toggle = (id: SurfaceId) =>
    onChange(selected.includes(id) ? selected.filter((s) => s !== id) : [...selected, id]);

  const perKeyword = costFor(selected);
  const total = perKeyword * keywordCount;

  const groups: SurfaceCategory[] = ["chatbot", "search-feature"];

  return (
    <div className={cn("flex flex-col gap-5", className)} {...props}>
      {groups.map((cat) => {
        const list = getSurfacesByCategory(cat).filter((s) => surfaces.includes(s.id));
        if (list.length === 0) return null;
        return (
          <div key={cat} className="flex flex-col gap-2.5">
            {showCategoryHeaders && <SurfaceCategoryHeader category={cat} count={list.length} />}
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
              {list.map((s) => (
                <SurfaceSelectorCard
                  key={s.id}
                  surface={s.id}
                  selected={selected.includes(s.id)}
                  disabled={disabled.includes(s.id)}
                  onToggle={toggle}
                />
              ))}
            </div>
          </div>
        );
      })}

      <CostPreview
        variant={selected.length === 0 ? "default" : "per-surface"}
        title={selected.length === 0 ? "No surfaces selected" : "Estimated cost"}
        amount={`$${total.toFixed(3)}`}
        math={
          selected.length === 0
            ? "Select at least one surface to run."
            : `${keywordCount} ${keywordCount === 1 ? "keyword" : "keywords"} × ${selected.length} ${selected.length === 1 ? "surface" : "surfaces"} = $${perKeyword.toFixed(3)} per keyword`
        }
        perSurfaceBreakdown={selected.map((s) => ({ surface: s, count: keywordCount }))}
      />
    </div>
  );
}
