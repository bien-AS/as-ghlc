import type { ComponentPropsWithoutRef } from "react";
import { cn } from "../lib/cn";
import { Card, DeltaPill, Eyebrow, Sparkline, scoreLevel, SCORE_LABEL, type ScoreLevel } from "./primitives";
import { SourceBadge } from "./pills";
import type { SourceId } from "../lib/icons";

/**
 * KpiTile and ScoreGauge — the two ways a single number gets shown.
 *
 * Both encode the same two rules, because both are places the rules get
 * broken quietly:
 *
 * 1. `null` MEANS NOT MEASURED, NEVER ZERO. A tile that renders a missing
 *    reading as "0" is not a formatting bug, it is a false statement — and it
 *    is the kind that survives review, because 0 looks like data. Every
 *    not-measured path here prints an em-dash plus the words "not measured",
 *    and the "not connected" path says so in as many words so an empty tile
 *    is never read as a collapse to zero.
 *
 * 2. COLOUR IS NEVER THE ONLY ENCODING. The gauge always prints its number
 *    AND its threshold word, so the ring is redundant; the delta always
 *    carries a written label, because direction alone misreads — "wait time
 *    down 8%" is good news with a down arrow, and a lower rank number is an
 *    improvement. `DeltaPill` already enforces that label; this file just
 *    never routes around it.
 *
 * The gauge ring is hand-rolled SVG. One arc does not justify a chart
 * library, and staying out of Recharts means it needs no literal colours, no
 * token hook and no `isAnimationActive` escape hatch — it is styled with
 * `stroke-*` utilities and follows the theme like everything else.
 */

/* ================================================================== *
 * KpiTile
 * ================================================================== */

export interface KpiDelta {
  value: number;
  /**
   * REQUIRED CONTEXT — e.g. "vs. last 28 days". An arrow without a period to
   * compare against is not a fact.
   */
  label: string;
  /** Which direction counts as good. Rank and cost metrics pass "down". */
  goodDirection?: "up" | "down";
}

export interface KpiTileProps extends Omit<ComponentPropsWithoutRef<"div">, "children"> {
  /** Uppercase eyebrow. What the number is. */
  label: string;
  /**
   * `null` = NOT MEASURED. Pass a string for anything needing formatting this
   * component does not do — currency, a "%"-hugging suffix, a ratio.
   */
  value: string | number | null;
  /**
   * Trailing unit, e.g. "leads" or "/day". It is set off from the number by a
   * space, so a unit that must hug its number ("82%") belongs in `value`.
   */
  unit?: string;
  delta?: KpiDelta;
  /** History behind the number. Decorative and aria-hidden — it summarises
   *  the number beside it, it never replaces it. */
  spark?: number[];
  /** Provenance. Renders a SourceBadge — the data-honesty rule. */
  source?: SourceId;
  loading?: boolean;
  notConnected?: { provider: string };
}

/** U+2014 EM DASH. The same not-measured glyph `rankLabel` uses. */
const EM_DASH = "—";

/** Shared by every state so the number never moves when data arrives. */
const DISPLAY_NUMBER =
  "font-display text-[30px] font-bold leading-none tracking-[-0.02em] tabular-nums";

export function KpiTile({
  label, value, unit, delta, spark, source,
  loading = false, notConnected, className, ...props
}: KpiTileProps) {
  // NaN is what a division by zero looks like by the time it reaches a tile.
  // It is a missing measurement, not a value, and must not print as "NaN".
  const measured =
    value != null && !(typeof value === "number" && !Number.isFinite(value));

  if (loading) {
    return (
      <Card padding="tight" className={cn("flex flex-col gap-3", className)} aria-busy {...props}>
        <span className="sr-only">Loading {label}</span>
        <Eyebrow aria-hidden>{label}</Eyebrow>
        <div aria-hidden className="h-8 w-24 animate-pulse rounded bg-surface-inset motion-reduce:animate-none" />
        <div aria-hidden className="h-3 w-16 animate-pulse rounded bg-surface-inset motion-reduce:animate-none" />
      </Card>
    );
  }

  if (notConnected) {
    return (
      <Card padding="tight" className={cn("flex flex-col gap-3", className)} {...props}>
        <Eyebrow>{label}</Eyebrow>
        <p className={cn(DISPLAY_NUMBER, "text-ink-3")} aria-hidden>{EM_DASH}</p>
        {/* Spelled out, because an empty tile in a KPI row otherwise reads as
            a metric that fell to zero. */}
        <p className="text-meta leading-snug text-ink-2">
          {notConnected.provider} is not connected — this is not a zero.
        </p>
      </Card>
    );
  }

  return (
    <Card padding="tight" className={cn("flex flex-col gap-3", className)} {...props}>
      <div className="flex items-start gap-2">
        {/* line-clamp-2, not truncate. The label is the only thing that says
            what the number MEANS — a tile reading "Portfolio …  68 / 100" has
            lost the measurement, while the source badge beside it kept its full
            width. Two lines of a text-micro eyebrow is a bounded cost; an
            unreadable KPI is not. */}
        <Eyebrow className="min-w-0 flex-1 line-clamp-2">{label}</Eyebrow>
        {source && <SourceBadge source={source} size="sm" className="shrink-0" />}
      </div>

      <p className="flex flex-wrap items-baseline gap-x-1 gap-y-0.5">
        <span className={cn(DISPLAY_NUMBER, measured ? "text-ink" : "text-ink-3")} aria-hidden={!measured || undefined}>
          {measured ? formatValue(value) : EM_DASH}
        </span>
        {measured && unit && (
          <span className="text-small font-semibold text-ink-3">{unit}</span>
        )}
        {!measured && <span className="text-meta text-ink-3">not measured</span>}
      </p>

      {/* `spark.length > 1` mirrors Sparkline's own guard so a one-point
          history does not leave an empty row behind. */}
      {(delta || (spark && spark.length > 1)) && (
        <div className="mt-auto flex items-end gap-3">
          {/* A percentage change against a reading we do not have would be
              invented, so the delta is dropped with the value. The sparkline
              stays: the history is real, and the gap at its end is the point. */}
          {measured && delta && (
            <DeltaPill
              value={delta.value}
              label={delta.label}
              goodDirection={delta.goodDirection}
              className="min-w-0"
            />
          )}
          {/* min-w-0, not shrink-0: a flex item's default `min-width: auto`
              floors an svg at its attribute width, so shrink-0 would re-create
              the overflow the Sparkline's own max-w-full exists to prevent. */}
          {spark && <Sparkline data={spark} width={72} height={24} className="ml-auto min-w-0" />}
        </div>
      )}
    </Card>
  );
}

/**
 * The locale is pinned. `toLocaleString()` with no argument reads the Node
 * ICU default on the server and the browser's locale on the client, so a
 * server-rendered "1,240" hydrates against a client "1 240" and React throws
 * out the markup. This is a US-English internal tool; anything else formats
 * upstream and passes a string.
 */
function formatValue(value: string | number): string {
  return typeof value === "number" ? value.toLocaleString("en-US") : value;
}

/* ================================================================== *
 * ScoreGauge — the 0-100 ring.
 * ================================================================== */

/**
 * Arc colour per level. BASE tokens, not `*-ink`: `*-ink` is text colour for a
 * `*-soft` fill, and a 9px stroke is a graphic, not text. Full class strings —
 * Tailwind's scanner cannot see `stroke-${tone}`.
 */
const LEVEL_ARC: Record<ScoreLevel, string> = {
  strong: "stroke-teal",
  "needs-work": "stroke-amber",
  critical: "stroke-danger",
};

/** Word colour. Here `*-ink` IS right — this is text. */
const THRESHOLD_INK: Record<ScoreLevel, string> = {
  strong: "text-teal-ink",
  "needs-work": "text-amber-ink",
  critical: "text-danger-ink",
};

/** Two sizes only. A gauge sized between them stops matching its neighbours. */
const GAUGE = {
  sm: { px: 72, stroke: 6, number: "text-[18px]", word: "text-nano" },
  md: { px: 120, stroke: 9, number: "text-[28px]", word: "text-meta" },
} as const;

export interface ScoreGaugeProps extends Omit<ComponentPropsWithoutRef<"div">, "children"> {
  /** 0-100. `null` = not measured — renders an empty track, never a 0 ring. */
  value: number | null;
  size?: keyof typeof GAUGE;
}

export function ScoreGauge({ value, size = "md", className, ...props }: ScoreGaugeProps) {
  const g = GAUGE[size];
  const measured = value != null && Number.isFinite(value);
  // Clamped, because a score of 140 would draw a full ring plus a second lap
  // and read as 40.
  const score = measured ? Math.min(100, Math.max(0, value)) : 0;
  const band: ScoreLevel | null = measured ? scoreLevel(score) : null;

  const radius = (g.px - g.stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const arc = (score / 100) * circumference;

  return (
    <div className={cn("inline-flex flex-col items-center gap-1.5", className)} {...props}>
      <div className="relative shrink-0" style={{ width: g.px, height: g.px }}>
        {/* -rotate-90 starts the arc at 12 o'clock. The ring is redundant
            encoding — the number and the word below carry the reading — so it
            is aria-hidden and the text does the talking. */}
        <svg
          width={g.px} height={g.px} viewBox={`0 0 ${g.px} ${g.px}`}
          className="block -rotate-90" aria-hidden focusable="false"
        >
          <circle
            cx={g.px / 2} cy={g.px / 2} r={radius}
            fill="none" strokeWidth={g.stroke} className="stroke-line-strong"
          />
          {band && (
            <circle
              cx={g.px / 2} cy={g.px / 2} r={radius}
              fill="none" strokeWidth={g.stroke} strokeLinecap="round"
              // dasharray, not a wedge path: one dash the length of the arc,
              // one gap the length of the rest.
              strokeDasharray={`${arc} ${circumference - arc}`}
              className={cn(
                "transition-[stroke-dasharray] duration-med ease-standard motion-reduce:transition-none",
                LEVEL_ARC[band],
              )}
            />
          )}
        </svg>

        <div className="absolute inset-0 flex items-center justify-center">
          <span
            className={cn(
              "font-display font-bold leading-none tracking-[-0.02em] tabular-nums",
              g.number, measured ? "text-ink" : "text-ink-3",
            )}
            aria-hidden={!measured || undefined}
          >
            {measured ? Math.round(score) : EM_DASH}
          </span>
          {measured && <span className="sr-only"> out of 100</span>}
        </div>
      </div>

      <span className={cn("font-semibold", g.word, band ? THRESHOLD_INK[band] : "text-ink-3")}>
        {band ? SCORE_LABEL[band] : "Not measured"}
      </span>
    </div>
  );
}
