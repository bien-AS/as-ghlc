"use client";

import { useId, useState, type ReactNode } from "react";
import { cn } from "../lib/cn";
import { useDismissable } from "../lib/use-table";
import { navIcon, ICON_SIZE } from "../lib/icons";

/**
 * A small accessible popover.
 *
 * Hand-rolled rather than pulled from Radix: the scaffold's dependency list has
 * no Radix packages, and this needs exactly one behaviour — a labelled trigger,
 * a dismissable panel, and focus that returns to the trigger. Adding a
 * positioning engine for that would be a large dependency for a small job.
 *
 * The tradeoff, stated plainly: this does NOT do collision detection or
 * flipping. It anchors bottom-start (or bottom-end via `align`) and can overflow
 * a narrow viewport. If the app later needs popovers near the viewport edge,
 * swap the panel for Radix Popover and keep this API.
 *
 * Elevation IS allowed here — the AS system reserves shadow for popovers,
 * modals and toasts. Cards stay flat.
 */
export interface PopoverProps {
  /** Rendered inside the trigger button. */
  label: ReactNode;
  /** Accessible name, when `label` alone is not descriptive. */
  ariaLabel?: string;
  children: (close: () => void) => ReactNode;
  align?: "start" | "end";
  /** Shown as a count badge on the trigger, e.g. active filter count. */
  badge?: number;
  icon?: ReactNode;
  className?: string;
  panelClassName?: string;
  disabled?: boolean;
}

export function Popover({
  label, ariaLabel, children, align = "start", badge, icon,
  className, panelClassName, disabled,
}: PopoverProps) {
  const [open, setOpen] = useState(false);
  const panelId = useId();
  const ref = useDismissable(open, () => setOpen(false));

  return (
    <div ref={ref} className={cn("relative", className)}>
      <button
        type="button"
        aria-expanded={open}
        aria-haspopup="dialog"
        aria-controls={open ? panelId : undefined}
        aria-label={ariaLabel}
        disabled={disabled}
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "inline-flex h-8 items-center gap-1.5 rounded-md border px-2.5 text-small font-medium",
          "transition-colors duration-fast ease-standard",
          "focus-visible:outline-none focus-visible:shadow-focus",
          "disabled:pointer-events-none disabled:opacity-50",
          open
            // border-line-field, not -strong: this is an interactive control, and
            // --border-strong is 1.50:1 on white (fails WCAG 1.4.11).
            // An open trigger sits on surface-hover and otherwise has nowhere
            // to go, so the hover moves the border rather than the fill (a
            // darker fill in light would break the boundary's 3:1 — see
            // notification-bell). Every popover inherits this: date range,
            // table filters, column visibility.
            ? "border-line-field bg-surface-hover text-ink hover:border-line-field-hover"
            : "border-line-field bg-card text-ink-2 hover:bg-surface-hover hover:text-ink",
        )}
      >
        {icon}
        {label}
        {badge != null && badge > 0 && (
          <span className="ml-0.5 rounded-full bg-teal px-1.5 font-mono text-nano font-bold tabular-nums text-ink-on-teal">
            {badge}
          </span>
        )}
        <navIcon.expand
          size={ICON_SIZE.dense}
          aria-hidden
          className={cn("transition-transform duration-fast", open && "rotate-180")}
        />
      </button>

      {open && (
        <div
          id={panelId}
          role="dialog"
          aria-label={ariaLabel ?? (typeof label === "string" ? label : undefined)}
          className={cn(
            "absolute z-50 mt-1.5 min-w-[240px] rounded-lg border border-line bg-card p-1 shadow-md",
            align === "end" ? "right-0" : "left-0",
            panelClassName,
          )}
        >
          {children(() => setOpen(false))}
        </div>
      )}
    </div>
  );
}

/** A checkable row inside a popover. Used by filters and column visibility. */
export interface CheckRowProps {
  checked: boolean;
  onChange: () => void;
  label: ReactNode;
  count?: number;
  disabled?: boolean;
  disabledReason?: string;
}

export function CheckRow({
  checked, onChange, label, count, disabled, disabledReason,
}: CheckRowProps) {
  return (
    <label
      className={cn(
        "flex cursor-pointer items-center gap-2.5 rounded px-2 py-1.5 text-small",
        "transition-colors duration-fast hover:bg-surface-hover",
        disabled && "cursor-not-allowed opacity-50 hover:bg-transparent",
      )}
      title={disabled ? disabledReason : undefined}
    >
      {/* Native input kept for semantics and keyboard; the visible box is the
          span beside it, so the checkmark renders on every platform rather than
          relying on the OS control being styleable. */}
      <input
        type="checkbox"
        checked={checked}
        disabled={disabled}
        onChange={onChange}
        className="peer sr-only"
      />
      <span
        aria-hidden
        className={cn(
          "grid size-3.5 shrink-0 place-items-center rounded-sm border transition-colors duration-fast",
          "peer-focus-visible:shadow-focus",
          checked ? "border-teal bg-teal text-ink-on-teal" : "border-line-field bg-transparent",
        )}
      >
        {checked && (
          <svg viewBox="0 0 10 10" className="size-2.5" fill="none" stroke="currentColor" strokeWidth={2.2}>
            <path d="M1.5 5.2 L4 7.5 L8.5 2.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        )}
      </span>
      <span className="min-w-0 flex-1 truncate text-ink">{label}</span>
      {count != null && (
        <span className="shrink-0 font-mono text-nano tabular-nums text-ink-3">{count}</span>
      )}
    </label>
  );
}
