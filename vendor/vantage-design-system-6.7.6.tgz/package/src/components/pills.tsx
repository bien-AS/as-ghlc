import { cva, type VariantProps } from "class-variance-authority";
import type { ComponentPropsWithoutRef } from "react";
import { cn } from "../lib/cn";
import {
  auditIcon, auditTone, runIcon, RUN_SPINS, severityIcon, severityTone,
  sourceIcon, sourceLabel, ICON_SIZE,
  type AuditState, type RunState, type Severity, type SourceId,
} from "../lib/icons";
import { rankMeta, rankLabel } from "../lib/rank";

const pill = cva(
  "inline-flex items-center gap-1.5 rounded font-bold uppercase tracking-[0.04em] whitespace-nowrap",
  {
    variants: {
      size: { sm: "px-1.5 py-0.5 text-nano", md: "px-2 py-1 text-micro" },
    },
    defaultVariants: { size: "md" },
  },
);

/* ================================================================== *
 * StatusPill — the closed audit-state set.
 * Glyph AND label always ship together: the glyph is not readable at
 * 11px to everyone, and the tone alone is not an accessible signal.
 * ================================================================== */
export interface StatusPillProps
  extends ComponentPropsWithoutRef<"span">, VariantProps<typeof pill> {
  state: AuditState;
  label?: string;
}

const AUDIT_LABEL: Record<AuditState, string> = {
  pass: "Pass", attention: "Attention", fail: "Fail",
  unknown: "Unknown", verified: "Verified",
};

const AUDIT_BG: Record<AuditState, string> = {
  pass: "bg-teal-soft", attention: "bg-amber-soft", fail: "bg-danger-soft",
  unknown: "bg-surface-subtle", verified: "bg-teal-soft",
};

export function StatusPill({ state, label, size, className, ...props }: StatusPillProps) {
  const Icon = auditIcon[state];
  return (
    <span
      className={cn(pill({ size }), AUDIT_BG[state], auditTone[state], className)}
      {...props}
    >
      <Icon size={ICON_SIZE.dense} aria-hidden />
      {label ?? AUDIT_LABEL[state]}
    </span>
  );
}

/* ================================================================== *
 * SourceBadge — provenance.
 *
 * This is the enforcement point for the data-honesty rule, not a
 * decoration: every row that carries a `source` field renders one of
 * these, so a synthetic or interpolated figure can never quietly pass
 * as a measured one. `synthetic` is deliberately styled as a warning.
 * ================================================================== */
export interface SourceBadgeProps
  extends ComponentPropsWithoutRef<"span">, VariantProps<typeof pill> {
  source: SourceId;
  /** Prefix shown before the source name. */
  mode?: "live" | "cached" | "cross-check";
}

export function SourceBadge({ source, mode = "live", size, className, ...props }: SourceBadgeProps) {
  const Icon = sourceIcon[source];
  const synthetic = source === "synthetic";
  return (
    <span
      className={cn(
        pill({ size }),
        synthetic
          ? "bg-amber-soft text-amber-ink"
          : "bg-surface-subtle text-ink-3",
        className,
      )}
      title={synthetic ? "Not a measurement — generated or interpolated" : sourceLabel[source]}
      {...props}
    >
      <Icon size={ICON_SIZE.dense} aria-hidden />
      <span className="font-mono">
        {synthetic ? "SYNTHETIC" : `${mode.toUpperCase()} · ${sourceLabel[source].toUpperCase()}`}
      </span>
    </span>
  );
}

/* ================================================================== *
 * RunStatePill — scan lifecycle.
 * `partial` is a first-class state, never rounded up to complete.
 * ================================================================== */
const RUN_LABEL: Record<RunState, string> = {
  queued: "Queued", dispatching: "Dispatching", collecting: "Collecting",
  aggregating: "Aggregating", complete: "Complete", partial: "Partial", failed: "Failed",
};

const RUN_TONE: Record<RunState, string> = {
  queued: "bg-surface-subtle text-ink-3",
  dispatching: "bg-surface-subtle text-ink-2",
  collecting: "bg-teal-soft text-teal-ink",
  aggregating: "bg-teal-soft text-teal-ink",
  complete: "bg-teal-soft text-teal-ink",
  partial: "bg-amber-soft text-amber-ink",
  failed: "bg-danger-soft text-danger-ink",
};

export interface RunStatePillProps
  extends ComponentPropsWithoutRef<"span">, VariantProps<typeof pill> {
  state: RunState;
}

export function RunStatePill({ state, size, className, ...props }: RunStatePillProps) {
  const Icon = runIcon[state];
  return (
    <span className={cn(pill({ size }), RUN_TONE[state], className)} {...props}>
      <Icon
        size={ICON_SIZE.dense}
        aria-hidden
        className={RUN_SPINS.has(state) ? "animate-spin motion-reduce:animate-none" : undefined}
      />
      {RUN_LABEL[state]}
    </span>
  );
}

/* ================================================================== *
 * RankPill — the rank-band law, with the number always visible so
 * colour is never carrying the meaning alone.
 * ================================================================== */
export interface RankPillProps extends ComponentPropsWithoutRef<"span"> {
  rank: number | null | undefined;
  showBandLabel?: boolean;
}

export function RankPill({ rank, showBandLabel = false, className, ...props }: RankPillProps) {
  const meta = rankMeta(rank);
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded px-2 py-1 text-micro font-bold tabular-nums",
        meta.softFill, meta.text, className,
      )}
      title={meta.label}
      {...props}
    >
      {rankLabel(rank)}
      {/* Skip the band label when it would just repeat the value ("20+ 20+"). */}
      {showBandLabel && meta.label !== rankLabel(rank) && (
        <span className="font-medium normal-case opacity-80">{meta.label}</span>
      )}
    </span>
  );
}

/* ================================================================== *
 * SeverityDot — grades an event (audit log, alert feed). Distinct
 * from StatusPill, which grades a check.
 * ================================================================== */
export interface SeverityDotProps extends ComponentPropsWithoutRef<"span"> {
  severity: Severity;
  withLabel?: boolean;
}

const SEVERITY_LABEL: Record<Severity, string> = {
  info: "Info", moderate: "Moderate", critical: "Critical",
};

export function SeverityDot({ severity, withLabel = true, className, ...props }: SeverityDotProps) {
  const Icon = severityIcon[severity];
  return (
    <span
      className={cn("inline-flex items-center gap-1.5 text-micro font-bold uppercase tracking-[0.04em]", severityTone[severity], className)}
      {...props}
    >
      <Icon size={ICON_SIZE.dense} aria-hidden fill={severity === "info" ? "currentColor" : "none"} />
      {withLabel && SEVERITY_LABEL[severity]}
    </span>
  );
}

/* ================================================================== *
 * RolePill
 * ================================================================== */
export const ROLES = ["owner", "admin", "viewer"] as const;
export type Role = (typeof ROLES)[number];

export const ROLE_META: Record<Role, { label: string; short: string; className: string }> = {
  owner:  { label: "Workspace Owner", short: "Owner",  className: "bg-teal text-ink-on-teal" },
  admin:  { label: "Admin",           short: "Admin",  className: "bg-secondary text-secondary-foreground" },
  viewer: { label: "Viewer",          short: "Viewer", className: "bg-surface-inset text-ink" },
};

export interface RolePillProps
  extends ComponentPropsWithoutRef<"span">, VariantProps<typeof pill> {
  role: Role;
  short?: boolean;
}

export function RolePill({ role, short = false, size, className, ...props }: RolePillProps) {
  const meta = ROLE_META[role];
  return (
    <span className={cn(pill({ size }), meta.className, className)} {...props}>
      {short ? meta.short : meta.label}
    </span>
  );
}

/* ================================================================== *
 * ScopePill — what a run or notification applies to.
 * ================================================================== */
export const SCOPES = ["domain", "page", "system"] as const;
export type Scope = (typeof SCOPES)[number];

const SCOPE_META: Record<Scope, { label: string; className: string }> = {
  domain: { label: "Domain", className: "bg-teal-soft text-teal-ink" },
  page:   { label: "Page",   className: "bg-amber-soft text-amber-ink" },
  system: { label: "System", className: "bg-surface-subtle text-ink-2" },
};

export interface ScopePillProps
  extends ComponentPropsWithoutRef<"span">, VariantProps<typeof pill> {
  scope: Scope;
  label?: string;
  detail?: string;
}

export function ScopePill({ scope, label, detail, size, className, ...props }: ScopePillProps) {
  const meta = SCOPE_META[scope];
  return (
    <span className={cn(pill({ size }), meta.className, className)} {...props}>
      {label ?? meta.label}
      {detail && <span className="font-medium normal-case opacity-75">{detail}</span>}
    </span>
  );
}

/* ================================================================== *
 * RunScopePill — the breadth of a run. Kept separate from ScopePill
 * because "domain + its pages" is a distinct, costed choice.
 * ================================================================== */
export const RUN_SCOPES = ["workspace", "domain-pages", "domain-only", "page", "multi"] as const;
export type RunScope = (typeof RUN_SCOPES)[number];

const RUN_SCOPE_META: Record<RunScope, { label: string; className: string }> = {
  workspace:     { label: "Workspace",       className: "bg-teal-soft text-teal-ink ring-1 ring-inset ring-teal/25" },
  "domain-pages":{ label: "Domain + pages",  className: "bg-teal-soft text-teal-ink ring-1 ring-inset ring-teal/25" },
  "domain-only": { label: "Domain only",     className: "bg-surface-subtle text-ink-2 ring-1 ring-inset ring-line-strong" },
  page:          { label: "Page",            className: "bg-amber-soft text-amber-ink ring-1 ring-inset ring-amber/25" },
  multi:         { label: "Multi-select",    className: "bg-teal-soft text-teal-ink ring-1 ring-inset ring-teal/25" },
};

export interface RunScopePillProps
  extends ComponentPropsWithoutRef<"span">, VariantProps<typeof pill> {
  scope: RunScope;
  detail?: string;
}

export function RunScopePill({ scope, detail, size, className, ...props }: RunScopePillProps) {
  const meta = RUN_SCOPE_META[scope];
  return (
    <span className={cn(pill({ size }), meta.className, className)} {...props}>
      {meta.label}
      {detail && <span className="font-medium normal-case opacity-75">{detail}</span>}
    </span>
  );
}
