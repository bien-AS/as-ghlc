/**
 * Google algorithm-update timeline — the data behind `AlgoOverlay`.
 *
 * docs/06 makes this a must-have: the overlay goes on EVERY timeline, from one
 * shared layer reading `data/algo-updates.json`. The reason is analytical, not
 * decorative — a traffic cliff that lines up with a core update is a different
 * conversation from one that does not, and an operator should never have to
 * remember the dates to notice.
 *
 * The JSON's `_meta.type_colors` are fixed hexes that cannot flip with the
 * theme and are not AS hues. They are advisory; rendering colours come from the
 * `--sc-algo-*` tokens instead.
 *
 * Confirmed vs unconfirmed matters. An unconfirmed update is rendered dashed
 * and labelled, never as settled fact — the file's own instruction is
 * "keep verified vs web search; do not fabricate".
 */

export type AlgoType = "core" | "spam" | "system" | "discover";

export interface AlgoUpdate {
  name: string;
  type: AlgoType;
  /** ISO date, inclusive. */
  start: string;
  /** ISO date, inclusive. Equal to `start` for single-day events. */
  end: string;
  confirmed: boolean;
  note?: string;
}

/** Token key per update type — resolved through `useChartTokens`. */
export const ALGO_TOKEN: Record<AlgoType, string> = {
  core: "algo-core",
  spam: "algo-spam",
  system: "algo-system",
  discover: "algo-discover",
};

export const ALGO_LABEL: Record<AlgoType, string> = {
  core: "Core update",
  spam: "Spam update",
  system: "System change",
  discover: "Discover update",
};

/** Shape of `data/algo-updates.json`. */
export interface AlgoUpdatesFile {
  _meta?: { last_verified?: string; [k: string]: unknown };
  updates: AlgoUpdate[];
  _forward_note?: string;
}

/**
 * Keep only the updates that overlap [from, to]. A band that is entirely
 * outside the visible window is not drawn — but one that merely starts before
 * it IS, clipped, because a rollout that began earlier still explains what the
 * chart shows.
 */
export function algoUpdatesInRange(
  updates: AlgoUpdate[],
  from: string,
  to: string,
): AlgoUpdate[] {
  return updates
    .filter((u) => u.end >= from && u.start <= to)
    .sort((a, b) => a.start.localeCompare(b.start));
}

/**
 * Rolling mean over `window` points, for noisy daily series (docs/06 asks for a
 * 7-day option). Leading points average over what exists rather than being
 * dropped, so the line starts where the data does.
 *
 * Nulls are HOLES, not zeros — a day with no measurement must not drag the mean
 * down. A window containing only nulls stays null.
 */
export function rollingMean(
  values: (number | null)[],
  window = 7,
): (number | null)[] {
  return values.map((_, i) => {
    const slice = values.slice(Math.max(0, i - window + 1), i + 1);
    const present = slice.filter((v): v is number => v != null);
    if (present.length === 0) return null;
    return present.reduce((a, b) => a + b, 0) / present.length;
  });
}

/** Percent change between two points; null when either side is unmeasured. */
export function pctChange(from: number | null, to: number | null): number | null {
  if (from == null || to == null || from === 0) return null;
  return ((to - from) / Math.abs(from)) * 100;
}

/** `2026-05-21` -> `May 21`. Locale-independent, matching the AS date rule. */
export function shortDate(iso: string): string {
  const [, m, d] = iso.split("-");
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  return `${months[Number(m) - 1]} ${Number(d)}`;
}
