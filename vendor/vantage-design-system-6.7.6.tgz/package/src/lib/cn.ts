import { clsx, type ClassValue } from "clsx";
import { extendTailwindMerge } from "tailwind-merge";

/**
 * Tailwind class merger, taught about this design system's custom scales.
 *
 * WHY THE `extend` BLOCK IS NOT OPTIONAL
 * tailwind-merge resolves conflicts by class GROUP. Out of the box it only
 * knows Tailwind's stock scale, so it cannot tell our custom font sizes
 * (`text-meta`, `text-small`) from our custom text colours (`text-ink-2`,
 * `text-ink-on-teal`) — it files both under `text-*`, decides they conflict,
 * and keeps only the last one.
 *
 * The failure is silent and theme-dependent: a button carrying
 * `text-ink-on-teal text-meta` lost its colour entirely and fell back to
 * inheriting the body colour, which is near-white in dark mode — so primary
 * buttons rendered near-white text on a teal fill at 2.99:1 instead of the
 * intended AS Black at 5.92:1. Nothing errored; the classes were simply gone.
 *
 * Registering the scales below tells tailwind-merge which `text-*` names are
 * sizes, so colours stop colliding with them. Any NEW custom font size added
 * to tailwind.config.ts must be added here too, or the bug comes back.
 */
const FONT_SIZES = ["nano", "micro", "meta", "small", "body", "display"] as const;

export const twMerge = extendTailwindMerge({
  extend: {
    classGroups: {
      // Declaring these as font sizes leaves every other `text-*` free to be
      // treated as a colour, which is what we want.
      "font-size": [{ text: [...FONT_SIZES] }],
    },
  },
});

/**
 * Merge Tailwind classes so a caller's `className` always wins over a
 * component's defaults, instead of both landing in the class list and letting
 * source order decide. Every component in this kit takes a `className` prop
 * and runs it through here.
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
