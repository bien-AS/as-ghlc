/**
 * Icon registry — semantic name -> Lucide component.
 *
 * WHY THIS FILE EXISTS
 * Callers never choose an icon. They ask for a *state* ("pass", "collecting",
 * "dataforseo") and get whatever glyph the system has assigned to it. That
 * keeps one glyph per meaning across 45 screens, and makes a global icon
 * change a one-line edit here instead of a grep.
 *
 * The vocabulary is taken from the Baptist SaaS (as-baptist-geo-monitor),
 * which is the reference implementation for these states. Baptist is itself a
 * Lucide app, so this maps onto the real set rather than substituting
 * hand-drawn approximations. (The original screen captures live in the AS
 * design archive, not in this package — the registry below is the portable
 * result, and is authoritative on its own.)
 *
 * RULES
 * - Lucide only. If a state has no good Lucide glyph, add a custom SVG under
 *   `components/marks/` and register it here — do not pick a loose approximation.
 * - Stroke width stays at Lucide's 1.5 default. Never mix weights.
 * - Icons inherit `currentColor`. Set the text color; the icon follows.
 * - Sizes: 16 in dense UI, 20 in page headers, 24 in empty states. Never >32.
 * - An icon never carries meaning alone. Every status glyph ships beside its
 *   label (PASS / FAIL / …), because glyph shape is not readable at 12px to
 *   everyone and the four rank hues collapse under deuteranopia.
 */
import {
  AlertTriangle, BadgeCheck, Ban, BarChart3, Bell, CheckCircle2, ChevronDown,
  ChevronRight, Circle, CircleDot, Clock, Copy, Crosshair, Database, Download,
  ExternalLink, Eye, FileText, GitCompare, Globe, Grid3X3, HelpCircle, KeyRound,
  Layers, LineChart, Link2, Loader2, Lock, LogOut, MapPin, Minus, Network,
  Pencil, Play, Radar, RefreshCw, Rocket, Save, Search, Settings, ShieldAlert,
  ShieldCheck, Sparkles, Target, Trash2, TrendingDown, TrendingUp, Unlock,
  UserRound, Waves, XCircle,
  type LucideIcon,
} from "lucide-react";

/* ------------------------------------------------------------------ *
 * Audit state — a closed set. Baptist stamps one of these on every
 * scored item; there is no fifth option and no bare "ok".
 * ------------------------------------------------------------------ */
export const AUDIT_STATES = ["pass", "attention", "fail", "unknown", "verified"] as const;
export type AuditState = (typeof AUDIT_STATES)[number];

export const auditIcon: Record<AuditState, LucideIcon> = {
  pass: CheckCircle2,
  attention: AlertTriangle,
  fail: XCircle,
  unknown: HelpCircle,
  verified: BadgeCheck,
};

/**
 * Tailwind text-colour class per audit state.
 *
 * These are the `*-ink` tokens, NOT the base semantic colours. A status pill
 * puts its text on the matching `*-soft` fill, and the base colour on its own
 * tint measures 2.9-3.3:1 in light mode — it fails. The ink variants are
 * darkened to clear 4.5:1 on that same fill in both themes.
 */
export const auditTone: Record<AuditState, string> = {
  pass: "text-teal-ink",
  attention: "text-amber-ink",
  fail: "text-danger-ink",
  unknown: "text-ink-3",
  verified: "text-teal-ink",
};

/* ------------------------------------------------------------------ *
 * Run lifecycle — the scan pipeline. Ordered; `index` is meaningful
 * for progress UI.
 * ------------------------------------------------------------------ */
export const RUN_STATES = [
  "queued", "dispatching", "collecting", "aggregating",
  "complete", "partial", "failed",
] as const;
export type RunState = (typeof RUN_STATES)[number];

export const runIcon: Record<RunState, LucideIcon> = {
  queued: Clock,
  dispatching: Rocket,
  collecting: Loader2,      // spin this one
  aggregating: BarChart3,
  complete: CheckCircle2,
  partial: CircleDot,       // measured, but with gaps — never silently "complete"
  failed: XCircle,
};

/** States that should render with a spin animation. */
export const RUN_SPINS: ReadonlySet<RunState> = new Set<RunState>(["collecting"]);

/* ------------------------------------------------------------------ *
 * Citation / indexing loop — the directory submission lifecycle.
 * ------------------------------------------------------------------ */
export const CITATION_STATES = [
  "recommended", "queued", "ordered", "submitted",
  "live", "indexing", "indexed", "not_indexed",
] as const;
export type CitationState = (typeof CITATION_STATES)[number];

export const citationIcon: Record<CitationState, LucideIcon> = {
  recommended: Sparkles,
  queued: Clock,
  ordered: FileText,
  submitted: Rocket,
  live: Globe,
  indexing: Loader2,
  indexed: CheckCircle2,
  not_indexed: Ban,
};

/* ------------------------------------------------------------------ *
 * Data sources — provenance. Baptist stamps LIVE · <SOURCE> on every
 * figure; this is the enforcement point for the data-honesty rule, so
 * every source the app can read from needs a glyph here.
 * ------------------------------------------------------------------ */
export const SOURCES = [
  "dataforseo", "searchatlas", "serper", "ahrefs", "majestic", "semrush",
  "gsc", "ga4", "gbp", "clickup", "callrail", "agencyanalytics",
  "windsor", "firecrawl", "apify", "neuronwriter", "synthetic",
] as const;
export type SourceId = (typeof SOURCES)[number];

export const sourceIcon: Record<SourceId, LucideIcon> = {
  dataforseo: Database,
  searchatlas: Waves,
  serper: Search,
  ahrefs: Link2,
  majestic: Network,
  semrush: BarChart3,
  gsc: LineChart,
  ga4: BarChart3,
  gbp: MapPin,
  clickup: FileText,
  callrail: Radar,
  agencyanalytics: BarChart3,
  windsor: Layers,
  firecrawl: Globe,
  apify: Grid3X3,
  neuronwriter: Pencil,
  synthetic: ShieldAlert,   // never dressed up as a real measurement
};

export const sourceLabel: Record<SourceId, string> = {
  dataforseo: "DataForSEO", searchatlas: "Search Atlas", serper: "Serper.dev",
  ahrefs: "Ahrefs", majestic: "Majestic", semrush: "Semrush",
  gsc: "Search Console", ga4: "GA4", gbp: "Google Business Profile",
  clickup: "ClickUp", callrail: "CallRail", agencyanalytics: "AgencyAnalytics",
  windsor: "Windsor.ai", firecrawl: "Firecrawl", apify: "Apify",
  neuronwriter: "NeuronWriter", synthetic: "Synthetic",
};

/* ------------------------------------------------------------------ *
 * Severity — for audit logs and alert feeds. Distinct from audit
 * state: severity grades an event, audit state grades a check.
 * ------------------------------------------------------------------ */
export const SEVERITIES = ["info", "moderate", "critical"] as const;
export type Severity = (typeof SEVERITIES)[number];

export const severityIcon: Record<Severity, LucideIcon> = {
  info: Circle,
  moderate: AlertTriangle,
  critical: ShieldAlert,
};

export const severityTone: Record<Severity, string> = {
  info: "text-ink-3",
  moderate: "text-amber-ink",
  critical: "text-danger-ink",
};

/* ------------------------------------------------------------------ *
 * Trend direction. Direction alone misreads — "wait time down 8%" is
 * good — so DeltaPill requires a contextual label alongside these.
 * ------------------------------------------------------------------ */
export const trendIcon = { up: TrendingUp, down: TrendingDown, flat: Minus } as const;
export type TrendDirection = keyof typeof trendIcon;

/* ------------------------------------------------------------------ *
 * Geo / scan — the S-06 and S-07 vocabulary.
 * ------------------------------------------------------------------ */
export const geoIcon = {
  location: MapPin,
  grid: Grid3X3,
  layers: Layers,
  crosshair: Crosshair,
  rankType: Target,
  compare: GitCompare,
  runScan: Rocket,
  legend: Eye,
  pending: Circle,        // "future cycle pending" placeholder
} as const;

/* ------------------------------------------------------------------ *
 * Actions and navigation.
 * ------------------------------------------------------------------ */
export const actionIcon = {
  run: Play, refresh: RefreshCw, export: Download, save: Save,
  edit: Pencil, delete: Trash2, copy: Copy, deploy: Rocket,
  aiAction: Sparkles, viewDiff: GitCompare, view: Eye,
} as const;

export const navIcon = {
  forward: ChevronRight, expand: ChevronDown, external: ExternalLink,
  bell: Bell, settings: Settings, logout: LogOut,
} as const;

export const entityIcon = {
  user: UserRound, role: ShieldCheck, key: KeyRound,
  locked: Lock, unlocked: Unlock, document: FileText,
  domain: Globe, page: FileText, hierarchy: Network,
} as const;

/* ------------------------------------------------------------------ *
 * Standard sizes. Anything outside this set is a mistake, not a
 * decision — the AS system caps icons at 32.
 * ------------------------------------------------------------------ */
export const ICON_SIZE = { dense: 16, header: 20, empty: 24, hero: 32 } as const;
export type IconSize = keyof typeof ICON_SIZE;

export type { LucideIcon };
