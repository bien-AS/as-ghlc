/**
 * The rank-band law: 1-3 / 4-10 / 11-19 / 20+.
 *
 * The boundaries are fixed and are not a styling choice. They encode what a
 * searcher actually sees: 1-3 is the map pack, 4-10 is the rest of page one,
 * 11-19 is page two, 20+ is effectively absent. The "orange band ends at 19,
 * red starts at 20" split is inherited from the Baptist SaaS, where the orange
 * hue was deliberately moved off yellow so bands 2 and 3 stay apart.
 *
 * COLOUR IS NEVER THE ONLY ENCODING. These four hues collapse under
 * deuteranopia. Every surface that uses them — map pins, heat cells, bucket
 * areas — must also print the rank number or an explicit band label. That is
 * why `RankBand` carries `label` and why `<RankPin>` always renders its value.
 */

export const RANK_BANDS = ["pack", "page1", "page2", "out", "none"] as const;
export type RankBand = (typeof RANK_BANDS)[number];

export interface RankBandMeta {
  band: RankBand;
  /** Human label — the required non-colour encoding. */
  label: string;
  /** Inclusive lower bound; null for "not measured". */
  min: number | null;
  /** Inclusive upper bound; null for open-ended. */
  max: number | null;
  /** Tailwind classes, resolved per theme through the rank-* tokens. */
  fill: string;
  /** Text colour for use ON `softFill` — a darkened variant, not `fill`. */
  text: string;
  softFill: string;
  /**
   * Text colour for use ON `fill` (the SOLID band, e.g. a heat-grid cell).
   * Different from `text`: the solid fill is a different ground, and the bands
   * span too wide a lightness range for one ink to clear AA on all of them.
   */
  onFill: string;
}

export const RANK_BAND_META: Record<RankBand, RankBandMeta> = {
  pack:  { band: "pack",  label: "In the pack", min: 1,  max: 3,    fill: "bg-rank-pack",  text: "text-rank-pack-ink",  softFill: "bg-rank-pack/15", onFill: "text-rank-pack-on" },
  page1: { band: "page1", label: "Page one",    min: 4,  max: 10,   fill: "bg-rank-page1", text: "text-rank-page1-ink", softFill: "bg-rank-page1/15", onFill: "text-rank-page1-on" },
  page2: { band: "page2", label: "Page two",    min: 11, max: 19,   fill: "bg-rank-page2", text: "text-rank-page2-ink", softFill: "bg-rank-page2/15", onFill: "text-rank-page2-on" },
  out:   { band: "out",   label: "20+",         min: 20, max: null, fill: "bg-rank-out",   text: "text-rank-out-ink",   softFill: "bg-rank-out/15", onFill: "text-rank-out-on" },
  none:  { band: "none",  label: "Not measured",min: null, max: null, fill: "bg-rank-none", text: "text-rank-none-ink",  softFill: "bg-rank-none/15", onFill: "text-rank-none-on" },
};

/**
 * Map a rank to its band.
 * `null` / `undefined` means NOT MEASURED, which is different from "absent
 * from results" — a scan that failed must never render as a rank-20 result.
 */
export function rankBand(rank: number | null | undefined): RankBand {
  if (rank == null || !Number.isFinite(rank)) return "none";
  if (rank <= 0) return "none";
  if (rank <= 3) return "pack";
  if (rank <= 10) return "page1";
  if (rank <= 19) return "page2";
  return "out";
}

export function rankMeta(rank: number | null | undefined): RankBandMeta {
  return RANK_BAND_META[rankBand(rank)];
}

/** Display string for a rank. 20+ collapses; unmeasured is an em-dash. */
export function rankLabel(rank: number | null | undefined): string {
  if (rank == null || !Number.isFinite(rank) || rank <= 0) return "—";
  return rank >= 20 ? "20+" : String(rank);
}

/** Ordered bands for legends — excludes "none" unless asked for. */
export function legendBands(includeUnmeasured = false): RankBandMeta[] {
  const bands: RankBand[] = ["pack", "page1", "page2", "out"];
  if (includeUnmeasured) bands.push("none");
  return bands.map((b) => RANK_BAND_META[b]);
}
