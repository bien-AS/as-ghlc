/**
 * The 6 AI citation surfaces, in two structurally distinct categories.
 *
 * These colours are REAL THIRD-PARTY BRAND COLOURS, not Authority Solutions
 * branding. They are product-functional — they attribute a citation to the
 * vendor that produced it — and they are deliberately excluded from every
 * Vantage rebrand. Do not re-token them.
 *
 * Category matters more than it looks: a gap on AI Overviews is a schema and
 * content problem, a gap on the Gemini chatbot is a brand-mention problem.
 * Different work. Never average the two into one number.
 */

export const SURFACE_IDS = [
  "perplexity", "chatgpt", "gemini", "claude", "ai-overviews", "ai-mode",
] as const;
export type SurfaceId = (typeof SURFACE_IDS)[number];

export type SurfaceCategory = "chatbot" | "search-feature";

export interface SurfaceMeta {
  id: SurfaceId;
  name: string;
  /** 3-letter code used in dense tables and matrix headers. */
  glyph: string;
  category: SurfaceCategory;
  /** Vendor brand colour — CSS var, resolved per theme. */
  color: string;
  colorDark: string;
  soft: string;
  /** USD per keyword per run. Drives every cost preview. */
  cost: number;
  /** Brand-mandated gradient for 48px tile placements; null = solid mark. */
  gradient: readonly string[] | null;
}

export const SURFACE_META: Record<SurfaceId, SurfaceMeta> = {
  perplexity: {
    id: "perplexity", name: "Perplexity", glyph: "PER", category: "chatbot",
    color: "var(--engine-perplexity)", colorDark: "var(--engine-perplexity-dark)",
    soft: "var(--engine-perplexity-soft)", cost: 0.015, gradient: null,
  },
  chatgpt: {
    id: "chatgpt", name: "ChatGPT", glyph: "GPT", category: "chatbot",
    color: "var(--engine-chatgpt)", colorDark: "var(--engine-chatgpt-dark)",
    soft: "var(--engine-chatgpt-soft)", cost: 0.015, gradient: null,
  },
  gemini: {
    id: "gemini", name: "Gemini", glyph: "GEM", category: "chatbot",
    color: "var(--engine-gemini)", colorDark: "var(--engine-gemini-dark)",
    soft: "var(--engine-gemini-soft)", cost: 0.015,
    gradient: ["#4796E3", "#9168C0", "#D96570"],
  },
  claude: {
    id: "claude", name: "Claude", glyph: "CLA", category: "chatbot",
    color: "var(--engine-claude)", colorDark: "var(--engine-claude-dark)",
    soft: "var(--engine-claude-soft)", cost: 0.015, gradient: null,
  },
  "ai-overviews": {
    id: "ai-overviews", name: "AI Overviews", glyph: "AIO", category: "search-feature",
    color: "var(--engine-ai-overviews)", colorDark: "var(--engine-ai-overviews-dark)",
    soft: "var(--engine-ai-overviews-soft)", cost: 0.005,
    gradient: ["#4285F4", "#9B72CB", "#D96570", "#FBBC04"],
  },
  "ai-mode": {
    id: "ai-mode", name: "AI Mode", glyph: "AIM", category: "search-feature",
    // Shares Google Blue with AI Overviews by design — the two are told apart
    // by their mark, not their colour.
    color: "var(--engine-ai-overviews)", colorDark: "var(--engine-ai-overviews-dark)",
    soft: "var(--engine-ai-overviews-soft)", cost: 0.020,
    gradient: ["#4285F4", "#9B72CB", "#D96570", "#FBBC04"],
  },
};

export const SURFACE_CATEGORIES: Record<SurfaceCategory, { label: string; note: string }> = {
  chatbot: {
    label: "Chatbot surfaces",
    note: "Measures brand authority. Optimise with E-E-A-T, authoritative content, brand mentions in citation-worthy sources.",
  },
  "search-feature": {
    label: "Google Search AI features",
    note: "Measures schema and SEO performance. Optimise with structured data, direct-answer paragraphs, primary-answer blocks.",
  },
};

/** Default audit mix — the cheapest set that covers both categories. */
export const DEFAULT_AUDIT_SURFACES: readonly SurfaceId[] = [
  "perplexity", "chatgpt", "ai-overviews",
];

/** v4 ids that changed in v4.5. Kept so old stored records still resolve. */
const LEGACY_ID_MAP: Record<string, SurfaceId> = { googleai: "ai-overviews" };

export function resolveSurfaceId(idOrLegacy: string): SurfaceId {
  return (LEGACY_ID_MAP[idOrLegacy] ?? idOrLegacy) as SurfaceId;
}

export function getSurface(id: string): SurfaceMeta | undefined {
  return SURFACE_META[resolveSurfaceId(id)];
}

export function getSurfacesByCategory(category: SurfaceCategory): SurfaceMeta[] {
  return SURFACE_IDS.map((id) => SURFACE_META[id]).filter((s) => s.category === category);
}

export function getAllSurfaces(): SurfaceMeta[] {
  return SURFACE_IDS.map((id) => SURFACE_META[id]);
}

/** Total USD for one keyword across the given surfaces. */
export function costFor(surfaces: readonly SurfaceId[]): number {
  return surfaces.reduce((sum, id) => sum + (SURFACE_META[id]?.cost ?? 0), 0);
}
