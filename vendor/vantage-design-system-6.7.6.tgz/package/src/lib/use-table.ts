"use client";

import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Debounce a value. The table uses 300ms on search, per the Baptist spec —
 * short enough to feel live, long enough that a fast typist does not trigger a
 * filter pass per keystroke on a few thousand rows.
 */
export function useDebouncedValue<T>(value: T, delay = 300): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const id = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(id);
  }, [value, delay]);
  return debounced;
}

/**
 * State persisted to localStorage, per viewer.
 *
 * Every access is wrapped: localStorage throws outright in some contexts
 * (private windows, embedded previews, browsers set to block site data), and
 * a table that crashes because it could not remember a density preference is
 * a worse outcome than one that forgets.
 *
 * Pass `key: null` to opt out of persistence entirely.
 */
export function usePersistentState<T>(
  key: string | null,
  initial: T,
  parse: (raw: string) => T | undefined,
): [T, (next: T) => void] {
  // WHY A MOUNTED FLAG AND NOT A useState INITIALISER
  // Reading localStorage in the initialiser is right for a client-only render
  // and WRONG under SSR: the server has no localStorage, so it renders
  // `initial` while the client's first render reads the stored value. React
  // hydrates, sees the two disagree, and every consuming Next.js app gets
  // "Prop `aria-checked` did not match" in its console on every load.
  //
  // So the first client render deliberately reproduces the server's value, and
  // the stored one is adopted in an effect. That costs one frame of the default
  // state — for the theme toggle that is the *pressed* state only, never the
  // painted theme, because the app's pre-paint bootstrap script has already set
  // the class before React exists. See SETUP.md §4.
  const [value, setValue] = useState<T>(initial);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setHydrated(true);
    if (!key) return;
    try {
      const raw = window.localStorage.getItem(key);
      if (raw == null) return;
      const parsed = parse(raw);
      if (parsed !== undefined) setValue(parsed);
    } catch {
      /* localStorage throws outright in private windows; the default stands. */
    }
    // `parse` is a fresh closure on most callers, so depending on it would
    // re-read storage every render and clobber the user's current choice.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  void hydrated;

  const set = useCallback(
    (next: T) => {
      setValue(next);
      if (!key) return;
      try {
        window.localStorage.setItem(key, String(next));
      } catch {
        /* preference is best-effort; never let it break the table */
      }
    },
    [key],
  );

  return [value, set];
}

/**
 * Close on outside pointer-down and on Escape.
 *
 * pointerdown rather than click, so the popover closes before a click lands on
 * whatever is underneath — otherwise the first click outside is swallowed by
 * the dismiss and the user has to click twice.
 */
export function useDismissable<T extends HTMLElement = HTMLDivElement>(
  open: boolean,
  onDismiss: () => void,
) {
  const ref = useRef<T>(null);

  useEffect(() => {
    if (!open) return;
    const onPointerDown = (e: PointerEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onDismiss();
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        onDismiss();
      }
    };
    document.addEventListener("pointerdown", onPointerDown, true);
    document.addEventListener("keydown", onKey, true);
    return () => {
      document.removeEventListener("pointerdown", onPointerDown, true);
      document.removeEventListener("keydown", onKey, true);
    };
  }, [open, onDismiss]);

  return ref;
}

export type SortDirection = "asc" | "desc";

export interface SortState {
  columnId: string;
  direction: SortDirection;
}

/**
 * Compare two cell values.
 *
 * `null` always sorts last regardless of direction. In this product null means
 * NOT MEASURED, and a missing measurement is not "rank zero" or "worst" — it
 * is absent. Letting it sort to the top of an ascending rank column would read
 * as the best result on the page.
 */
export function compareValues(
  a: string | number | null | undefined,
  b: string | number | null | undefined,
  direction: SortDirection,
): number {
  const aNull = a == null || a === "";
  const bNull = b == null || b === "";
  if (aNull && bNull) return 0;
  if (aNull) return 1;
  if (bNull) return -1;

  let result: number;
  if (typeof a === "number" && typeof b === "number") {
    result = a - b;
  } else {
    result = String(a).localeCompare(String(b), undefined, {
      numeric: true,
      sensitivity: "base",
    });
  }
  return direction === "asc" ? result : -result;
}
