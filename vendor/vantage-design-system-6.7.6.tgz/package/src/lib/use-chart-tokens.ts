"use client";

import { useEffect, useState } from "react";

/**
 * Resolve design tokens to literal colours for Recharts.
 *
 * WHY THIS EXISTS
 * Everything else in this kit styles through CSS classes, so it follows the
 * theme for free. Charts cannot: Recharts writes `stroke` and `fill` as SVG
 * presentation attributes and needs a real colour value at render time, not a
 * `var()`. A chart given `var(--sc-chart-1)` renders with no stroke at all in
 * some paths, and — worse — a chart given a literal hex renders the wrong
 * theme's palette after a toggle, silently, with no error.
 *
 * So tokens are read from the computed style of <html> and re-read whenever the
 * theme class changes. The MutationObserver is the whole point of the hook: a
 * one-shot read would freeze the palette at first paint.
 *
 * SSR: `document` does not exist on the server. The hook returns the dark
 * palette's declared values as a first pass and corrects on mount. Chart
 * components should still be imported with `dynamic(..., { ssr: false })` in
 * Next.js, as the Baptist spec requires for anything canvas/SVG-measured.
 */

/** Fallback used before mount and on the server. Matches the dark :root block. */
const SSR_FALLBACK: Record<string, string> = {
  "chart-1": "hsl(173 39% 55%)",
  "chart-2": "hsl(210 9% 66%)",
  "chart-3": "hsl(3 72% 72%)",
  "chart-4": "hsl(32 95% 44%)",
  "chart-5": "hsl(17 4% 66%)",
  "chart-6": "hsl(171 45% 68%)",
  "chart-7": "hsl(3 98% 82%)",
  "chart-8": "hsl(212 7% 55%)",
  "algo-core": "hsl(37 88% 48%)",
  "algo-spam": "hsl(2 69% 67%)",
  "algo-system": "hsl(212 7% 55%)",
  "algo-discover": "hsl(173 47% 47%)",
  "rank-1-3": "hsl(173 47% 47%)",
  "rank-4-10": "hsl(37 88% 48%)",
  "rank-11-19": "hsl(17 76% 61%)",
  "rank-20-plus": "hsl(2 69% 67%)",
  "rank-none": "hsl(27 5% 57%)",
  grid: "#2A2522",
  axis: "#8A837E",
  ink: "#F7F6F5",
  ink2: "#A8A29E",
  ink3: "#8A837E",
  surface: "#1A1512",
  border: "#2A2522",
};

/** Tokens the charts read. `--sc-*` are HSL channels; the rest are hex. */
const SC_TOKENS = [
  "chart-1", "chart-2", "chart-3", "chart-4",
  "chart-5", "chart-6", "chart-7", "chart-8",
  "algo-core", "algo-spam", "algo-system", "algo-discover",
  // Rank bands belong here too: any chart plotting the 4-band law needs them
  // as literals, and a component resolving them privately would duplicate the
  // MutationObserver and could drift from this palette.
  "rank-1-3", "rank-4-10", "rank-11-19", "rank-20-plus", "rank-none",
] as const;

const HEX_TOKENS: Record<string, string> = {
  grid: "--border-subtle",
  axis: "--fg-3",
  ink: "--fg-1",
  ink2: "--fg-2",
  ink3: "--fg-3",
  surface: "--bg-card",
  border: "--border",
};

export type ChartTokens = Record<string, string>;

function read(): ChartTokens {
  if (typeof document === "undefined") return SSR_FALLBACK;
  const cs = getComputedStyle(document.documentElement);
  const out: ChartTokens = {};

  for (const name of SC_TOKENS) {
    const raw = cs.getPropertyValue(`--sc-${name}`).trim();
    // Channels ("175 84% 32%") have to be wrapped; a bare channel string is
    // not a colour and Recharts will render nothing.
    out[name] = raw ? (raw.startsWith("#") ? raw : `hsl(${raw})`) : SSR_FALLBACK[name]!;
  }
  for (const [key, varName] of Object.entries(HEX_TOKENS)) {
    out[key] = cs.getPropertyValue(varName).trim() || SSR_FALLBACK[key]!;
  }
  return out;
}

export function useChartTokens(): ChartTokens {
  const [tokens, setTokens] = useState<ChartTokens>(SSR_FALLBACK);

  useEffect(() => {
    setTokens(read());
    const observer = new MutationObserver(() => setTokens(read()));
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class", "data-theme"],
    });
    return () => observer.disconnect();
  }, []);

  return tokens;
}

/** Token key per rank band, for charts plotting the 4-band law. */
export const RANK_TOKEN = {
  pack: "rank-1-3",
  page1: "rank-4-10",
  page2: "rank-11-19",
  out: "rank-20-plus",
  none: "rank-none",
} as const;

/**
 * Series colours, in order. Capped at 3 by the Baptist rule — beyond three
 * lines a legend stops being readable and the chart should become a small
 * multiple instead. Callers wanting more must say so explicitly.
 */
export const SERIES_ORDER = ["chart-1", "chart-2", "chart-3", "chart-4", "chart-5"] as const;
export const MAX_READABLE_SERIES = 3;

/** Respect the OS reduced-motion setting; Recharts animates by default. */
export function usePrefersReducedMotion(): boolean {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(mq.matches);
    const onChange = (e: MediaQueryListEvent) => setReduced(e.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  return reduced;
}
