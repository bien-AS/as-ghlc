import type { Config } from "tailwindcss";

/**
 * Vantage is DARK-FIRST. `darkMode: "class"` pairs with next-themes
 * (`attribute="class"`, `defaultTheme="dark"`), but note the token files do
 * the real work: :root already carries the dark palette, so `dark:` variants
 * are rarely needed — a component styled through these tokens is correct in
 * both themes with no per-theme classes at all. Reach for `dark:` only when a
 * component needs a genuinely different *structure* in one theme, not a
 * different color.
 *
 * Two token conventions are exposed:
 *   - HSL-channel tokens (tokens.css / shadcn.css) -> support opacity
 *     modifiers, e.g. `bg-primary/10`.
 *   - Hex tokens (colors_and_type.css) -> wrapped in color-mix() by
 *     `hexToken` below, so they accept opacity modifiers too. The explicit
 *     *-soft / *-tint tokens remain the preferred choice for named, measured
 *     pairings; the modifier is for one-off washes.
 */
// The shadcn/Tailwind layer is namespaced `--sc-*` so it cannot collide with
// the design-system layer in colors_and_type.css, which stores the same roles
// as hex. See the namespace note at the top of tokens.css for what that
// collision used to break.
const hsl = (v: string) => `hsl(var(--sc-${v}) / <alpha-value>)`;

/**
 * Wrap a HEX design token so it still accepts an opacity modifier.
 *
 * WHY: `hsl(var(--x) / <alpha-value>)` only works for tokens stored as HSL
 * CHANNELS. The design-system layer stores its tokens as hex, and a bare
 * `var(--cta-teal)` has nowhere to put the alpha — so Tailwind silently emits
 * NOTHING for `bg-teal/5`. No error, no warning, no rule: the element just has
 * no background. Seventeen usages across seven components were rendering
 * untinted because of exactly that.
 *
 * `color-mix()` gives the hex tokens a real alpha channel, so the modifier
 * works and the tokens stay hex.
 */
// Cast to `string`: Tailwind resolves a FUNCTION colour value at runtime, but
// its published types only allow `string | RecursiveKeyValuePair` here. Without
// the cast every consuming app's `tsc --noEmit` fails on a config that is
// correct — and the error points into node_modules, where nobody will look.
const hexToken = (name: string) =>
  ((({ opacityValue }: { opacityValue?: string }) => {
    // Tailwind calls this in two shapes and only ONE carries a real number:
    //   - no modifier  -> opacityValue is undefined, or the literal string
    //                     "var(--tw-text-opacity)". Number() of that is NaN,
    //                     and `color-mix(... NaN%, transparent)` is invalid, so
    //                     the declaration is dropped and the element inherits.
    //                     That produced black-on-black sidebar text in light.
    //   - `/10`        -> opacityValue is "0.1".
    // Anything that is not a finite number returns the plain token.
    if (opacityValue === undefined) return `var(${name})`;
    const alpha = Number(opacityValue);
    if (!Number.isFinite(alpha)) return `var(${name})`;
    return `color-mix(in srgb, var(${name}) ${alpha * 100}%, transparent)`;
  }) as unknown as string);

export default {
  darkMode: "class",
  content: ["./src/**/*.{ts,tsx}", "./demo/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // ---- shadcn semantic layer (HSL channels, opacity-capable) ----
        background: hsl("background"),
        foreground: hsl("foreground"),
        card: { DEFAULT: hsl("card"), foreground: hsl("card-foreground") },
        popover: { DEFAULT: hsl("popover"), foreground: hsl("popover-foreground") },
        primary: { DEFAULT: hsl("primary"), foreground: hsl("primary-foreground") },
        secondary: { DEFAULT: hsl("secondary"), foreground: hsl("secondary-foreground") },
        muted: { DEFAULT: hsl("muted"), foreground: hsl("muted-foreground") },
        accent: { DEFAULT: hsl("accent"), foreground: hsl("accent-foreground") },
        destructive: { DEFAULT: hsl("destructive"), foreground: hsl("destructive-foreground") },
        border: hsl("border"),
        input: hsl("input"),
        ring: hsl("ring"),

        // ---- rank-band law: 1-3 / 4-10 / 11-19 / 20+ ----
        // Never the sole encoding — always pair with the rank number.
        rank: {
          pack: hsl("rank-1-3"),
          page1: hsl("rank-4-10"),
          page2: hsl("rank-11-19"),
          out: hsl("rank-20-plus"),
          none: hsl("rank-none"),
          foreground: hsl("on-rank"),
          // Text sitting ON a band's soft fill — NOT the same as the band
          // colour, which fails on its own tint in light mode.
          "pack-ink": hsl("rank-1-3-ink"),
          "page1-ink": hsl("rank-4-10-ink"),
          "page2-ink": hsl("rank-11-19-ink"),
          "out-ink": hsl("rank-20-plus-ink"),
          "none-ink": hsl("rank-none-ink"),
          // `*-on` = ink for text on the band's SOLID fill (heat-grid cells).
          // `*-ink` = ink for text on the band's SOFT fill (pills). Different
          // grounds, different answers — see the note in tokens.css.
          "pack-on": hsl("rank-1-3-on"),
          "page1-on": hsl("rank-4-10-on"),
          "page2-on": hsl("rank-11-19-on"),
          "out-on": hsl("rank-20-plus-on"),
          "none-on": hsl("rank-none-on"),
        },

        // ---- design-system layer (hex tokens, no opacity modifier) ----
        surface: {
          DEFAULT: hexToken("--bg-card"),
          page: hexToken("--bg-page"),
          hover: hexToken("--bg-card-hover"),
          subtle: hexToken("--bg-subtle"),
          inset: hexToken("--bg-inset"),
          dark: hexToken("--bg-dark"),
        },
        line: {
          DEFAULT: hexToken("--border"),
          strong: hexToken("--border-strong"),
          subtle: hexToken("--border-subtle"),
          field: hexToken("--border-input"),
          // An OPEN disclosure trigger already sits on surface-hover, so it had
          // nowhere to go on hover. The move is on the BORDER, not the fill:
          // the surface ramp in LIGHT is pinned between #FFFFFF and the fixed
          // grey --border-input, so a darker fill drops the control's own
          // boundary to 2.99 and fails WCAG 1.4.11. Darkening the border
          // instead RAISES that contrast (3.23 -> 4.41 light, 3.61 -> 4.51 dark).
          "field-hover": hexToken("--border-input-hover"),
          dark: hexToken("--border-dark"),
        },
        ink: {
          DEFAULT: hexToken("--fg-1"),
          2: hexToken("--fg-2"),
          3: hexToken("--fg-3"),
          4: hexToken("--fg-4"),
          "on-dark": hexToken("--fg-on-dark-1"),
          "on-dark-2": hexToken("--fg-on-dark-2"),
          "on-dark-3": hexToken("--fg-on-dark-3"),
          "on-teal": hexToken("--fg-on-teal"),
        },
        // `*-ink` is the text colour for use ON the matching `*-soft` fill.
        // It is NOT the same as the base colour, which fails on its own tint
        // in light mode. Use `text-teal-ink` on `bg-teal-soft`, never `text-teal`.
        teal: {
          DEFAULT: hexToken("--cta-teal"),
          ink: hsl("teal-ink"),
          // TEXT interaction — darkens, for teal text on a page ground.
          hover: hexToken("--cta-teal-hover"),
          press: hexToken("--cta-teal-press"),
          // FILL interaction — lightens, because a teal fill carries dark ink.
          // Never use `bg-teal-hover`; use `bg-teal-fill-hover`.
          "fill-hover": hexToken("--teal-fill-hover"),
          "fill-press": hexToken("--teal-fill-press"),
          soft: hexToken("--cta-teal-soft"),
        },
        amber: { DEFAULT: hexToken("--amber"), soft: hexToken("--amber-soft"), ink: hsl("amber-ink") },
        danger: { DEFAULT: hexToken("--as-red"), dark: hexToken("--as-red-dark"), soft: hexToken("--danger-soft"), ink: hsl("danger-ink") },
      },
      fontFamily: {
        sans: ["var(--font-sans)"],
        display: ["var(--font-display)"],
        mono: ["var(--font-mono)"],
      },
      fontSize: {
        nano: ["var(--fs-nano)", { lineHeight: "var(--lh-tight)" }],
        micro: ["var(--fs-micro)", { lineHeight: "var(--lh-tight)" }],
        meta: ["var(--fs-meta)", { lineHeight: "var(--lh-snug)" }],
        small: ["var(--fs-small)", { lineHeight: "var(--lh-normal)" }],
        body: ["var(--fs-body)", { lineHeight: "var(--lh-normal)" }],
        display: ["var(--fs-display)", { lineHeight: "var(--lh-tight)" }],
      },
      borderRadius: {
        sm: "var(--r-sm)", md: "var(--r-md)", lg: "var(--r-lg)",
        xl: "var(--r-xl)", "2xl": "var(--r-2xl)", "3xl": "var(--r-3xl)",
      },
      boxShadow: {
        xs: "var(--shadow-xs)", sm: "var(--shadow-sm)", md: "var(--shadow-md)",
        lg: "var(--shadow-lg)", focus: "var(--shadow-focus)",
        "focus-danger": "var(--shadow-focus-danger)",
      },
      transitionTimingFunction: { standard: "var(--ease-standard)", emphasized: "var(--ease-emphasized)" },
      transitionDuration: { fast: "var(--dur-fast)", med: "var(--dur-med)", slow: "var(--dur-slow)" },
    },
  },
  plugins: [],
} satisfies Config;
