# Rules that are not style preferences

Every rule here exists because breaking it has already produced a bug that
**rendered, shipped, and was wrong** — no error, no warning, no failing test.
They are grouped by how the failure shows up.

---

## 1. The two token layers

| File | Format | Prefix | Consumed by |
|---|---|---|---|
| `tokens/colors_and_type.css` | hex | none | components, via `var(--fg-1)` |
| `tokens/tokens.css` | HSL channels | **`--sc-`** | Tailwind, via `hsl(var(--sc-*))` |

**Never define the same name in both files.** The prefix is load-bearing. Before
it existed, both layers defined `--primary`, `--border`, `--accent` and `--ring`;
whichever file loaded last won, so one layer was always silently broken.
`color: var(--primary)` resolved to `"175 84% 32%"` — which is not a colour, so
the declaration was dropped and the element quietly inherited instead.

`tokens/shadcn.css` is the **same layer** as `tokens.css`, kept separately for
apps using shadcn/ui without this kit. Import one or the other, never both.

---

## 2. Theming

**`:root` is DARK.** Vantage is dark-first: an un-themed render is dark, and
`.light` derives from it. There is no `@media (prefers-color-scheme)` block
anywhere — the theme is a class on `<html>`. A component styled through tokens
is correct in both themes with **no `dark:` variants at all**. Reach for `dark:`
only when the two themes need genuinely different *structure*.

**Never use a surface or brand-constant token as a foreground.** `--as-black` is
brand ink and the always-dark sidebar ground — it does not flip. For text use
`--fg-1`. In the source AS system `--fg-1` *is* `--as-black`, so the two look
identical in light, which is exactly why this mistake survives review and only
appears when someone switches to dark.

**Clearing both theme classes does not mean "follow the OS."** In a dark-first
system with no `prefers-color-scheme` block it means *dark, unconditionally*.
`ThemeToggle` resolves the OS preference itself and writes the concrete class.

---

## 3. Colour pairing

**`*-ink` is the text colour for use ON the matching `*-soft` fill.** It is not
the base colour, which measures 2.8–3.9:1 on its own tint in light mode.
`text-teal-ink` on `bg-teal-soft` — never `text-teal`.

**A teal FILL lightens on interaction; teal TEXT darkens.** Teal fills carry AS
Black ink in both themes, so use `bg-teal-fill-hover`. Using `bg-teal-hover` —
the *text* token — drops a pressed fill to 3.05:1.

**`--border-input`, not `--border-strong`,** bounds an interactive control.
`--border-strong` is 1.50:1 on white and fails WCAG 1.4.11.

**An open disclosure trigger changes its BORDER on hover, not its fill.** The
trigger already sits on `--bg-card-hover` while its popover is open, so it has
nowhere left to go on the surface ramp — and in **light** there is genuinely no
room to add a step: the ramp is pinned between `#FFFFFF` and the fixed grey
`--border-input`, so the deepest usable fill drops the control's own boundary to
**2.99** and fails 1.4.11. Darkening the border with `--border-input-hover`
raises that contrast instead (3.23 → 4.41 light, 3.61 → 4.51 dark). This is the
general shape of the problem: **when a state change would push a fill toward a
fixed border colour, move the border.**

**`ink-4` is disabled/placeholder only.** Supporting labels are content — use
`ink-3`.

**Colour is never the only encoding.** Rank pins print their number, status
pills print their label, matrix cells carry a mark and an `sr-only` label. The
four rank hues collapse under deuteranopia.

**No resting shadow on cards.** Elevation is for popovers, modals and toasts.

---

## 4. Sizing

**`1rem` is 14px here, not 16px.** `colors_and_type.css` sets
`html, body { font-size: var(--fs-body) }` with `--fs-body: 14px`, which
rescales *every* rem in the system — Tailwind's whole default spacing and sizing
scale included (`p-4` is 14px, not 16px). It is deliberate: this is a dense
operator dashboard.

But it makes any arbitrary rem value **12.5% smaller than it reads**, and the
failure is quiet — a `w-[21rem]` popover written for 336px renders at 294px and
truncates its own content with no error.

> **Size anything that must hold prose in px** (`w-[336px]`). Keep rem only for
> values that *should* track the text scale — truncation caps, a badge paired
> with a `leading-` of the same token, a skeleton's reserve height.

**Never let a fixed-width child escape its container.** An SVG with a bare
`width` attribute and no `max-width` reports its full width and pushes the whole
page into horizontal scroll, silently. And on a flex item, `shrink-0` floors the
element at its `min-width: auto` — the SVG's attribute width — which defeats a
`max-w-full` on the child. Use `min-w-0`.

**When space runs out, the label is never what you sacrifice.** A tile reading
`PORTFOLIO … / 68 / 100` has lost the measurement while its source badge kept
full width. Clamp to two lines rather than truncating to one.

---

## 5. Data honesty

These are correctness rules, not presentation ones.

**`null` means NOT MEASURED. It never means zero.** A chart that draws a missing
reading as 0 is not a formatting bug, it is a false statement. Every chart in
this kit is verified against a deliberate scan outage on `2026-06-08`.

**A hole in one layer of a stack is indistinguishable from a zero one.** So in
stacked charts an unscanned date must be `null` in *every* band, and the whole
column becomes a gap.

**`null` sorts last in BOTH sort directions** in `DataTable` — not-measured is
not "the smallest value."

**Distinguish empty / filtered / not-connected.** "0 leads" and "CallRail was
never connected" are different facts, and only one of them is about the client.
`EmptyState`'s `variant` prop is required because there is no safe default.

**A rank delta needs a written direction label.** Lower is better for rank and
worse for cost; an arrow alone misreads.

**Never dim a row that a keyboard list still indexes.** A dimmed command-palette
row still takes an index, so Enter lands on nothing and the operator cannot tell
it from a broken palette. Withhold the rows and say why.

---

## 6. Mechanics

**`cn()` is required on every component's className.** It is
`extendTailwindMerge`-configured with this system's custom font sizes. The stock
merger cannot tell `text-meta` (a size) from `text-ink-on-teal` (a colour),
treats them as conflicting, and silently drops the colour — which is how primary
buttons once shipped rendering near-white text on teal at 2.99:1.

**Charts need `useChartTokens()`.** Recharts writes `stroke`/`fill` as SVG
presentation attributes and needs a literal colour at render time, not a
`var()`. A chart given `var(--sc-chart-1)` renders with no stroke; one given a
literal hex renders the *wrong theme's* palette after a toggle. The hook reads
the tokens off `<html>` and re-reads them on theme change.

**Import charts client-side** — `dynamic(..., { ssr: false })`. They are
SVG-measured.

**Measure contrast on a COLD BOOT.** Toggling the theme and measuring in the
same tick reads mid-transition values and reports failures that are not real.
`demo/audit.html` loads each page fresh with the theme applied before first
paint.
