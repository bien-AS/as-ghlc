# Authority Solutions design system — brand source & mapping

Replaces `VANTAGE_DESIGN_SYSTEM_SLOT.md` (quarantined, then deleted 2026-09-02),
which in turn had replaced the original `AS_DESIGN_SYSTEM_SLOT.md`. The build
ships with the **real Authority Solutions brand system already mapped in** —
this is not a placeholder slot waiting for a drop-in. This file documents where
the authoritative brand source lives and how it maps into the app, so the
mapping can be re-run if the brand system is ever updated upstream.

## Where the authoritative source lives

`AS - SaaS Design System/` at the project root. **Treat as read-only — never
edit files inside it.** It contains:

- `colors_and_type.css` — the canonical AS token file (225 lines): the five
  brand hexes, CTA teal, surfaces, borders, foreground ramp, the type scale,
  spacing, radii, shadows, layout dimensions and motion.
- `README.md` — the full written system: company context, content
  fundamentals (voice, casing, numbers, tone), visual foundations, layout
  rules, iconography, and the font-substitution rationale. **Read this before
  designing anything** — a large share of the AS system is prose rules, not
  token values.
- `SKILL.md` — the original agent-invocable skill manifest.
- `assets/logo-main.png`, `assets/logo-icon.png` — the AS wordmark-with-shield
  and the shield mark alone.
- `assets/engines/*.svg` — the **legacy 5-engine** glyph set. Superseded; see
  "What is deliberately NOT reverted" below.
- `preview/*.html` — reference cards for the original token set.
- `uploads/` — the source material: `AS Branding Guide (Updated).pdf`
  (palette with Pantone + HEX, primary/secondary fonts), the logo PNGs, and
  the marketing-site references (`AS_Homepage.pdf`, `AAS_About US.pdf`,
  `AS_Internet Marketing Page.png`).

## How it maps into this app

| Source | Maps into | How |
|---|---|---|
| `colors_and_type.css` brand palette | `design/colors_and_type.css` §1 | The five brand hexes, verbatim |
| `colors_and_type.css` CTA + surfaces + borders + fg | `design/colors_and_type.css` §2–§5 | Verbatim; tint ramps and scrims derived from the same anchors |
| — *(derived, no source equivalent)* | `design/colors_and_type.css` §0 `@theme` | 11-step ramps generated in OKLab from the AS anchors, each anchor pinned onto its step |
| — *(derived, no source equivalent)* | `design/colors_and_type.css` `.dark` | AS-derived dark theme; the source AS system is light-only |
| `colors_and_type.css` typography | `design/colors_and_type.css` §12 + §12.1 | Poppins + JetBrains Mono; AS dashboard type scale |
| the above, as HSL | `design/tokens.css`, `design/shadcn.css` | shadcn/Tailwind `hsl(var(--x))` convention, light + dark |
| the above, as JSON | `design/design_tokens.json` | Machine-readable mirror for build tooling / Style Dictionary / Figma sync. **Generated from the CSS — do not hand-maintain.** |
| `assets/logo-main.png`, `assets/logo-icon.png` | `design/assets/logos/AS_logo-main.png`, `AS_logo-icon.png` | Unmodified copies |
| `README.md` prose rules | `design/README.md`, `design/SKILL.md`, `design/PROJECT_CONTEXT.md` | Carried forward and extended with the v4/v4.5 product vocabulary |

**Legacy token names are preserved.** Every CSS custom-property name from the
prior systems still exists — only the *values* come from Authority Solutions.
Components in `_v45_ui_kit/`, `ui_kits/geo_monitor/`, and every
`preview/*.html` page render correctly with zero code changes. The one
exception: the declaration-only marketing type scale was renamed `--nv-*` →
`--as-*` (the `nv` prefix meant NitroViz); no component consumed it, and the
`_adherence.oxlintrc.json` allowlist was updated to match.

## What is deliberately NOT reverted to the AS source

**The AI surface colors.** `AS - SaaS Design System/colors_and_type.css`
carries the **outdated 5-engine** palette — Perplexity as forest green
`#1A7F64`, Claude as pumpkin `#D97706`, Gemini `#8B5CF6`, and a single
"Google AI" mapped to AS brand red. Those were corrected in v4.5.1 to real
vendor brand spec and split into the 6-surface taxonomy. Reverting them would
**misattribute the vendors on screen**, so the v4.5.1 values stand:

| Surface | Value |
|---|---|
| Perplexity | `#20B8CD` Perplexity Teal |
| ChatGPT | `#0F9F7A` OpenAI Green |
| Gemini | `#9168C0` Gemini Violet (+ brand gradient) |
| Claude | `#D97757` Claude Coral |
| AI Overviews · AI Mode | `#4285F4` Google Blue (+ Google 4-color gradient) |

The same applies to `--data-*` (Ahrefs, Majestic, Apify, Firecrawl,
NeuronWriter, DataForSEO) and `--gsc-blue`. These are product-functional
attribution colors, not Authority Solutions branding. `assets/engines/` in the
source folder is likewise superseded by `design/_v45_assets/surfaces/`.

## Open gaps — logo art

**The AS design system ships PNG logos only.** There is no SVG wordmark or
shield in `AS - SaaS Design System/`. The PNGs are wired in at
`design/assets/logos/` and are fine at the sizes currently used (sidebar mark
26px, preview lockup 320px), but they will soften on high-DPI displays at
large sizes and cannot be recolored via `currentColor`.

- [ ] **Requested: vector (SVG) versions of the AS lockup and shield.**
      Drop them in `design/assets/logos/` as `AS_logo-main.svg` and
      `AS_logo-icon.svg`; the references in `preview/_ds.js`,
      `_v45_ui_kit/Sidebar.jsx` and `ui_kits/geo_monitor/sidebar.jsx` are the
      only three places to update.

An SVG was **not** auto-traced from the PNG on purpose — a trace of a brand
mark is not the brand mark, and the drift would be invisible until it shipped.

**Second gap: there is no reversed (knockout) lockup.** The AS wordmark is dark,
so the full lockup is illegible on every dark surface — the always-dark sidebar,
and everything in dark mode. Dark surfaces therefore fall back to the **shield
mark alone**, which reads against AS Black. This is a fallback, not a design
decision, and it is why the preview header shows the shield rather than the
lockup in dark mode.

- [ ] **Requested: a reversed/knockout lockup** (light wordmark) for dark
      surfaces. Drop it in as `AS_logo-main-reversed.png` (or `.svg`) and point
      the `.logo-dark` image in `design/preview/_ds.js` at it; the
      `.logo-light` / `.logo-dark` swap is already wired in `preview/_ds.css`.

## Dark-first (2026-09-01)

`:root` carries the **dark** palette; `.light` / `[data-theme="light"]` derives
the light one from it. An un-themed render is dark, so the app never flashes
light on first paint. `.dark` is aliased to `:root` so next-themes
(`attribute="class"`, `defaultTheme="dark"`) works in both directions.

This follows the Baptist SaaS, which is dark-first. Per
`capabilities/baptist-saas-patterns.md` — *"structure copy-portable, colours are
not"* — Baptist's layout, density and component anatomy carry over; the palette
stays Authority Solutions.

Consequence worth internalising: **a component styled through tokens is correct
in both themes with no `dark:` variants at all.** Reach for `dark:` only when a
component needs a different *structure* in one theme, never a different colour.

## Running it locally

```
npm --prefix design run dev
```

Serves the whole system at **http://localhost:4321** — landing at `/`, brand
board at `/preview/`, the live component kit at `/kit/demo/`, the dashboard
shell at `/ui_kits/geo_monitor/`. `dev` rebuilds the kit demo first so the
bundle is never stale, and the server sends `no-store`.

`.claude/launch.json` registers it as `design-system`, so the Browser pane can
start it by name.

## Rules for the build agent

- Never hard-code brand hex in components — everything routes through the
  tokens in `colors_and_type.css` / `tokens.css`. (v6.0.0 converted 349
  existing literals; do not reintroduce them. Google/Gemini gradient stops are
  the sole sanctioned exception.)
- If a needed token is missing, add it to `colors_and_type.css` in **both**
  `:root` and `.dark` rather than inlining a color. A token that exists only in
  `:root` silently breaks dark mode.
- **Never define the same token name in both layers.** `colors_and_type.css`
  stores roles as hex; `tokens.css` stores the same roles as HSL channels for
  Tailwind, namespaced `--sc-*`. Before the prefix, both defined `--primary`,
  `--border`, `--accent` and `--ring`, and whichever loaded last won — so one
  layer was always silently broken (`color: var(--primary)` resolved to
  `"175 84% 32%"`, not a colour, declaration dropped, element inherited).
- **`*-ink` is the text colour for use ON a `*-soft` fill**, never the base
  colour, which measures 2.8-3.9:1 on its own tint in light mode.
- **A teal FILL lightens on interaction; teal TEXT darkens.** They are different
  tokens for that reason — `bg-teal-fill-hover` vs `hover:text-teal-hover`.
  Using the text token as a fill drops the pressed state to 3.05:1.
- **Always run a component's className through `cn()`**, which is
  `extendTailwindMerge`-configured with this system's font sizes. The stock
  merger cannot tell `text-meta` (size) from `text-ink-on-teal` (colour) and
  silently drops the colour.
- **Never use a surface/brand-constant token as a foreground.** This is the
  single easiest way to break dark mode here, and it is invisible in light:
  - `--as-black` is brand ink and the always-dark sidebar **ground**. It does
    not flip in dark. For text, use `--fg-1`. (In the source AS system
    `--fg-1: var(--as-black)`, so the two look identical in light — which is
    exactly why this slips through review.)
  - `--bg-page` / `--bg-card` are **grounds** and flip with the theme. Never
    use them as a text color, even to get off-white text on the dark sidebar —
    use `--fg-on-dark-1`, which is intentionally never overridden in `.dark`.
  - Text on always-dark chrome: `--fg-on-dark-1/2/3`. Text on themed surfaces:
    `--fg-1/2/3/4`. Text on a brand fill: `--fg-on-teal` / `--fg-on-red` /
    `--fg-on-amber`, which flip where the fill's contrast demands it.
  - Verify by rendering both themes and measuring, not by reading the diff.
- Use `--border-input` — not `--border-strong` — for the border of any
  interactive control. `--border-strong` is 1.50:1 on white and fails
  WCAG 1.4.11 as a control boundary.
- Contrast: the measured record is in `colors_and_type.css` §5.2. If you add or
  change a color pair, measure it and update that block.
- `design_tokens.json` is generated from the CSS. Change the CSS, then
  regenerate — do not edit the JSON by hand and let the two drift.
- If `AS - SaaS Design System/` is ever updated upstream, re-run the mapping
  table above rather than hand-editing values in `design/`; keep
  `colors_and_type.css`, `tokens.css`, `shadcn.css`, `preview/_ds.css` and
  `design_tokens.json` in sync with each other and with the source.

## Checklist

- [x] AS brand color values (light) — mapped 2026-09-01
- [x] AS dark theme derived + WCAG-AA verified — 2026-09-01
- [x] Poppins / JetBrains Mono type references — mapped 2026-09-01
- [x] Logo assets (PNG lockup + shield) — copied 2026-09-01
- [x] Spacing / radius scale returned to AS values — 2026-09-01
- [x] Component hex literals converted to token refs — 2026-09-01
- [ ] **Vector logo art — outstanding, see "Open gaps" above**
- [ ] **Reversed/knockout lockup for dark surfaces — outstanding**
- [ ] `_ds_bundle.js` `sourceHashes` are stale — rerun the real bundler
- [x] **White on CTA Teal — RESOLVED 2026-09-01 (operator decision).**
      `--fg-on-teal` is AS Black in both themes; teal fills carry dark ink
      (5.20:1 light, 6.04:1 dark). Consequence: teal FILLS now lighten on
      interaction (`--teal-fill-hover` / `-press`), while teal TEXT keeps the AS
      darkening direction (`--cta-teal-hover` / `-press`). Both themes now
      measure 0 failures.
- [ ] If AS publishes a component-level style guide (buttons, forms) beyond
      tokens + logo, map it here on the next update
