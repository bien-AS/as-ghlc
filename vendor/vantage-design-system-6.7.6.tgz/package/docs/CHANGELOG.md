# Authority Solutions Vantage — Changelog

All notable changes to Authority Solutions Vantage (design system, prompt corpus, and product spec) are documented in this file.

**Format:** Inspired by [Keep a Changelog](https://keepachangelog.com/). Versions are anchored to product taxonomy milestones — not calendar releases. Dates are completion dates; multi-phase versions track phase-by-phase progress.

**This file is mirrored in two locations:** the workspace `Phase 1-2 Screen Prompts/` folder and the Claude Design `design/` folder (formerly `geo-monitor-design/`). Keep them in sync.

---

## v6.7.6 — 2026-09-03 · serve.mjs falls forward on a busy port

`EADDRINUSE` was an unhandled `'error'` event, so running the preview while
another copy held the port printed a raw Node stack trace and nothing else.

The quieter failure was the reason to fix it: a second copy of this system on
the same port serves a **different tree at the same URL**. Anyone who skips the
console and just opens `:4321` sees the wrong system with no way to tell — which
is exactly what happened while verifying the launchpad folder, and briefly read
as a broken demo server.

Now retries the next port (up to 12) and announces the port **actually bound**,
read from `server.address()`. The first attempt at this announced the wrong
number: `listen(port, cb)` keeps its callback registered across a failed bind,
so on success every earlier callback fires too.

**v6.7.5 was withdrawn.** It was tagged without bumping the version, so the
published tag contained `"version": "6.7.4"`. Nothing failed — npm installed it
and reported the wrong number, and an app pinned to `#v6.7.5` would have
misreported its design-system version forever. Exactly the class of silent
defect this system exists to prevent, so the tag was deleted rather than left
to be installed.

The guard against a repeat is `tools/check-release.mjs`, run as
`npm run check:release v6.7.6`: it refuses if any `package.json` disagrees with
the tag, and refuses to reuse a tag that already exists.

---

## v6.7.4 — 2026-09-02 · QA sweep: a backwards ramp and six lying comments

A full pass over the system, its bundle, and the two published repos. Three
real defects, all of the same species: **the token layer telling the truth
about the wrong theme.**

**`--cta-teal-press` ran backwards in dark.** The ramp measured base 5.62:1 →
hover 7.88:1 → **press 4.84:1** — the press state read as *less* engaged than
resting. The value was `#0D9488`, the light theme's base teal, left behind by
the v6.1.0 inversion. It ships as `teal-press` in the Tailwind scale, so it was
a live trap for anyone who reached for it; no component had yet. Now `#8AD3C8`
(10.55:1), continuing past hover and matching `--teal-fill-press`.
A sweep now checks **every** base/-hover/-press family in both themes for
monotonicity — the other four are clean.

**Six comments in the `:root` block described the light values.** Written for
light, carried into dark by the inversion, and this file ships to developers as
the source of truth — so it read `--bg-page: #100C0A;  /* Warm off-white */`,
`--fg-1: #F7F6F5;  /* Primary text on light */`, and a `--border-input` note
claiming "3.37:1 on white" when the dark value measures 3.88:1 on `--bg-card`.
Corrected against measured values.

**A dangling path in shipped source.** `icons.ts` pointed at
`design system delete/…/Demo SaaS Screenshots/` for its icon vocabulary — a
folder no consumer of the package has. The registry is authoritative on its
own; the reference now says so instead of pointing into a local archive.

### Also verified, no change needed
- Token parity: all 55 light overrides have a dark declaration — nothing is
  undefined in dark.
- No collisions between the hex layer (312 tokens) and the `--sc-` layer (50).
- Every remaining "NitroViz" mention is deliberate rename history in the
  changelog and brand mapping, not a leftover.
- Contrast: **0 of 1836 nodes below AA** across 12 page/theme combinations,
  min 4.51:1.

---

## v6.7.3 — 2026-09-02 · Actually consumable — five defects a second app found

The bundle was verified end to end and still could not be installed. Building a
real second app against it surfaced five defects, none of which any in-repo
check could have caught, because inside the repo every one of them resolves.

**1. Internal imports used a `@/` alias.** 27 modules imported `@/lib/cn`. That
resolves through the kit's own tsconfig and nowhere else — in a consumer it
fails, or worse binds to the *app's* `@/` and pulls in a different file
entirely. Rewritten to relative paths, with a packaging guard that refuses to
build a bundle containing one.

**2. No `"use client"` anywhere.** App Router compiles every module as a Server
Component by default; 21 kit modules use hooks or DOM handlers and would throw
on import. Marked.

**3. The `exports` map blocked its own documented imports.** An `exports` field
denies every subpath it does not list, so `@vantage/design-system/tailwind.config`
— the exact line in the setup guide — failed to resolve. Added, along with a
`./charts/*` subpath: the bare `./src/*` wildcard resolves at runtime but
TypeScript will not append an extension through an exports map, so the chart
import typechecked as `any` and silently stopped checking props.

**4. `tailwind.config.ts` was never typechecked.** The kit's tsconfig excluded
it, so a consumer was the first thing to ever compile it — and it failed, on a
`hexToken` that returns a function where Tailwind's published types allow only
`string`. Tailwind resolves functions fine at runtime; the types just do not
model it. Cast, and the config is now in the kit's own `include`.

**5. Stored preferences read in `useState` initialisers.** Correct for a
client-only mount, wrong under SSR: the server renders the default while the
client's first render reads `localStorage`, so every consuming Next.js app
logged a hydration mismatch on `aria-checked` and on the "System, currently …"
label. Both now render the server's value first and adopt the stored one in an
effect — which costs nothing visible, because the app's pre-paint bootstrap has
already set the theme class before React exists.

### Also
- `deadclass.mjs` now **ships**. It is the guard that caught the invisible GBP
  dot, and an app writing new components against the kit needs it more than the
  kit does. Verified catching a planted dead class inside the starter.
- `docs/SETUP.md` — the new-app walkthrough, including the pre-paint bootstrap
  (previously documented only inside a demo HTML file and a source comment) and
  the RSC function-prop boundary: `Column.cell`/`value` are functions, and a
  Server Component that builds them fails the *build*, not the render.
- The packaging script no longer deletes `.git` when it wipes the output
  directory. The bundle **is** the distributable repo, so that would have
  destroyed the version history on every repackage — silently.
- `build:demo:css` now touches its output. Tailwind skips the write when the
  CSS is byte-identical, so an edit changing no classes left the staleness gate
  reporting drift that did not exist.

`starters/vantage-next-starter/` is the reference implementation: installed by
tag, typechecks, production-builds, renders in both themes, zero console
warnings, guard wired in.

---

## v6.7.2 — 2026-09-02 · The open-trigger hover, and why it went on the border

Closes the state deliberately left open in v6.7.1. A disclosure trigger whose
popover is **open** already sits on `--bg-card-hover`, so hovering it did
nothing — the control whose state matters most had no affordance.

### The obvious fix does not work in light
The natural move is a third surface step, `--bg-card-press`, continuing the
`base / -hover / -press` convention the teal ramp already uses. It was built and
wired — then measured, and removed.

In **light** the surface ramp is pinned between `#FFFFFF` and the fixed grey
`--border-input` (`#908B88`). Every perceptible darkening step drops the
contrast between the control's own boundary and its fill below WCAG 1.4.11's
3:1. Searched the whole ramp: the best viable light value scored **2.99**. The
system already carries a rule about exactly this criterion — "`--border-input`,
not `--border-strong`, bounds an interactive control" — so shipping a token
whose only documented use breaks it would have been a trap, especially in a
bundle handed to a build team as the source of truth.

Dark had room (`#302722` measured 3.13), but a mechanism that works in one theme
and not the other is how theme-specific bugs get written.

### So the hover moves the BORDER
`--border-input-hover` — `#8A837E` dark, `#7A7471` light. It **raises** boundary
contrast rather than eroding it:

| | fill | boundary before | boundary after |
|---|---|---|---|
| dark | `#221C18` | 3.61 | **4.51** |
| light | `#FBFAF9` | 3.23 | **4.41** |

Applied to `NotificationBell` and to the shared `Popover`, so every disclosure
trigger inherits it — date range, table filters, column visibility — not just
the bell that prompted it. Verified rendering in both themes with a real
pointer, since a hover state is never captured by the contrast sweep: the sweep
can only measure what the page draws, which is the same blind spot that hid the
invisible GSC dot in v6.7.1.

**New rule, in `kit/README.md` and `docs/RULES.md`:** when a state change would
push a fill toward a fixed border colour, move the border.

---

## v6.7.1 — 2026-09-02 · Interaction states, and an invisible status dot

Delivered by the parallel "opacity-modifier drops" session and folded into the
handoff bundle. Bundle regenerated and re-verified in an isolated copy.

### Fixed: the GSC "connected" dot rendered with no background
`bg-[var(--gsc-blue)]/80` compiled to **nothing** — an arbitrary `var()` has no
alpha slot for Tailwind to fill — so the one status the strip exists to show as
healthy displayed no dot at all. `--gsc-blue-80` already existed in the token
file, documented as "the canonical GSC connected dot". This is a different
failure from the `hexToken` fix in v6.5.x: that one restored opacity modifiers
on *token-scale* colours (`bg-teal/5`), which work via `color-mix()`. An
*arbitrary* `var()` still has nowhere to put the alpha, and always will.

The demo only ever rendered `GSCSyncStrip state="reconnect"`, which is exactly
why an invisible dot survived every contrast sweep — the harness can only
measure what the page renders. All three states are in the demo now.

### Fixed: four missing or wrong interaction states
- **`SurfaceSelector`** — a `role="checkbox"` tile, so clicking a *selected*
  tile deselects it, and the selected branch owned no hover at all: the most
  consequential click in the group had no affordance. Selected now deepens its
  own tint rather than borrowing the neutral hover, which would have read as
  "no longer selected."
- **`ThemeToggle`** and **`HeatGrid`** sort — both paint a solid teal fill when
  selected with no hover. `--teal-fill-hover` exists for exactly this ("a teal
  FILL lightens on interaction") and was wired to nothing but the primary Button.
- **`Sidebar`** — the active row was painted with `--bg-dark-`**`hover`**, so
  hovering any inactive row made it pixel-identical to the active one: two
  states, one colour, while `--bg-dark-`**`active`** sat defined and unused. The
  three-token ramp now does its job — `#100C0A` base → `#1F1916` active →
  `#312B28` hover, all distinct.

### Fixed: `deadclass.mjs` skipped every arbitrary utility
Its junk filter rejected any candidate containing parentheses, so the whole
`bg-[var(--x)]` family went unscanned — which is how the invisible dot survived
the guard as well as the sweep. Widening it caught the dot immediately. It now
also strips comments before scanning, because this codebase documents past bugs
by quoting the broken class, and a guard that cries wolf gets ignored.

### Known and deliberate
`NotificationBell`'s trigger drops its hover while the popover is open. Unlike
the others there is nowhere to go: the open state already sits on
`--bg-card-hover`, the brightest surface token, and the feedback for a
disclosure control is the open popover itself.

**Verified:** typecheck · csscheck · deadclass clean; contrast 0 of 1836 nodes
below AA across 12 page/theme combinations, min 4.51:1 — measured on a copy of
the bundle taken out of the tree and served on a clean port.

---

## v6.7.0 — 2026-09-02 · Packaged for handoff, and two dead token layers

The design system is now assembled into a self-contained bundle for the build
team at `deliverables/vantage-design-system/`, generated by
`npm --prefix design run package`. Preparing it surfaced two defects in the
token layer that had been invisible because neither one errors.

### Fixed: 48 palette tokens never resolved
The §0 brand ramps were declared inside `@theme { }` — **Tailwind v4 syntax in a
Tailwind v3.4.14 project**. v3 does not process `@theme` and neither does the
browser, so all 48 steps were inert: `var(--color-primary-500)` resolved to
nothing, silently, and nothing in the kit could have used them. Declared as a
plain `:root` block they now resolve, and the OKLab derivation the header
documents is verifiable — `primary-600 = #0D9488`, `accent-700 = #A52B30`,
`neutral-950 = #312B28`, each anchor pinned exactly onto its step, confirmed
against the live browser. They are raw palette steps, not the semantic layer;
the docs say so.

### Fixed: `--on-rank` existed in one theme only
Declared inside `.light` and nowhere else, so it resolved to nothing in dark.
Nothing consumed it — the live token is the namespaced `--sc-on-rank`, defined
in both themes and read by `tailwind.config.ts`. An unprefixed twin present in
one theme is exactly the collision the `--sc-` namespace exists to prevent, so
it was removed rather than completed.

### Fixed: `design_tokens.json` described the wrong system
It was hand-shipped at v6.0.0 and still listed `bg_page: #F7F6F5` as the base
value — the **light-first** structure, six versions out of date. Vantage
inverted to dark-first at v6.1.0, so that file had been telling every downstream
consumer the wrong base theme. It is now generated by
`tools/gen-tokens-json.mjs` and carries **both** resolved themes per token (361
tokens: 123 themed, 238 constant), cross-checked against the live browser.

### Fixed: the CSS header still announced v6.0.0
A developer opening `colors_and_type.css` would not have learned the system is
dark-first, or that 1rem is 14px. Both now lead the file.

### Fixed: `csscheck.mjs` resolved paths against the shell's cwd
So it silently reported six parse failures when run from anywhere but `kit/`,
and a *missing* file was reported as a parse error reading
"undefined at line undefined". Paths are script-relative now, and a missing file
says so.

### The bundle
`README.md` (open `demo/index.html`, no toolchain needed) · `docs/RULES.md` ·
generated `docs/COMPONENTS.md` (60 components across 27 modules) ·
`docs/CHANGELOG.md` · `docs/BRAND_MAPPING.md` · both token layers plus the
shadcn drop-in and the JSON mirror · `src/` · seven prebuilt demos · `csscheck`
and a static server · brand assets. 10 MB, 67 files.

Assembly is a script, not a copy, because a hand-copied bundle is stale the
moment anyone touches the kit and nothing tells you. It refuses to run if the
prebuilt demos are older than their sources, and every path rewrite is guarded
so a change upstream fails loudly instead of shipping a broken bundle — which
caught three real breakages while it was being written: the `kit.css` token
imports, `csscheck`'s file list, and `serve.mjs` serving `tools/` instead of the
bundle root, which 404'd every demo.

**Verified in an isolated copy**, not just in the repo: all seven demos serve,
all four stylesheets parse, contrast clean.

---

## v6.6.0 — 2026-09-02 · The shell, the panels, and a 14px rem

The chrome an operator drives the app from — `CommandPalette`, `DateRangePicker`,
`ThemeToggle`, `NotificationBell` — plus the four overview panels that sit under
it (`AlertList`, `RoadblockPanel`, `MoversPanel`, `AuditItemCard`) and
`EmptyState`. Demo at `kit/demo/shell.html`, registered in the audit harness.

### Components
- **`CommandPalette`** — groups can declare `requiresScope`, and an unscoped
  palette **withholds** those rows rather than dimming them: a dimmed row in a
  keyboard list still takes an index, so Enter lands on nothing and the operator
  cannot tell the difference from a broken palette. The footer says *why* the
  rows are absent ("3 module commands need a selected client") instead of
  leaving a shorter list unexplained. Matching runs over `keywords` as well as
  the label, so "grout" finds Superior Grouting.
- **`DateRangePicker`** — every preset prints the range it actually resolves to.
  "Last 90 days" is not a date, and an operator comparing two screenshots needs
  to know which 90.
- **`ThemeToggle`** — light / dark / **system** as three real states, not a
  two-way switch. A binary switch has to pick a side the first time it is
  touched, silently overwriting "follow the OS" with a value that no longer
  does; the damage only shows up when the OS flips at sunset. Because this
  system is dark-first with no `prefers-color-scheme` block anywhere, "system"
  resolves the OS preference and writes the concrete class — clearing both
  classes would mean *dark, unconditionally*.
- **`NotificationBell`** — unread is carried by a solid rail, a bold title and
  an `sr-only` word, not a tint. Timestamps are supplied pre-formatted by the
  caller (`timestamp` for display, `datetime` for the machine value): a
  relative-time formatter in the kit would be a second, drifting definition of
  "12m ago".
- **`AlertList` / `RoadblockPanel` / `MoversPanel` / `AuditItemCard` /
  `EmptyState`** — `EmptyState` separates *empty* from *filtered* from **not
  connected**, because "0 leads" and "CallRail was never connected" are
  different facts and only one of them is about the client. `MoversPanel` keeps
  a held position out of both movers columns and says so.

### Fixed
- **`TopBar` collapsed its own title instead of wrapping.** The title column was
  `min-w-0 flex-1`, so it shrank toward zero and the header's `flex-wrap` could
  never fire — at 800px the h1 rendered one word per line while the action
  cluster kept its full width. Now `min-w-[16rem] flex-1`, so the actions drop
  to their own row.
- **`NotificationBell` truncated every title.** Two causes, both fixed: the
  panel was `w-[21rem]` (see below — that is 294px in this system, not 336px),
  and the title was `truncate`. A notification title is a sentence; one line at
  that width cut it at the client name, losing both what happened and who it
  happened to. Now `w-[336px]` and `line-clamp-2`.
- **The audit harness could not pin a theme on a page that owns a
  `ThemeToggle`.** The cold-boot script set the class before first paint, then
  the toggle mounted, read its stored choice and re-applied it — so `?audit=light`
  measured dark twice and reported a clean light pass that never ran. The
  script now seeds the same storage key the toggle reads.

### Documented
- **1rem is 14px in this system, not 16px.** `colors_and_type.css` sets
  `html, body { font-size: var(--fs-body) }` with `--fs-body: 14px`, which
  redefines `rem` for everything — Tailwind's entire default spacing and sizing
  scale included (`p-4` is 14px). Deliberate for a dense dashboard, but it makes
  every arbitrary rem value 12.5% smaller than it reads, with no error when the
  result is too small to hold its content. Rule added to `kit/README.md` and a
  note at the `html` rule itself: **size anything that must hold prose in px.**

### Fixed: `KpiTile` sacrificed the label to keep the badge
`truncate` on the label with `shrink-0` on the source badge, so the label always
lost — the tile rendered "PORTFOLIO … · LIVE DATAFORSEO / 68 / 100", which is a
number with nothing saying what it measures. The label now clamps to two lines
(same call as the notification title); the badge is unchanged. The sparkline in
the same row carried `shrink-0`, which floors a flex item at its `min-width:
auto` — the SVG's attribute width — and would have re-created the overflow the
Sparkline's own `max-w-full` exists to prevent; it is `min-w-0` now.

### Swept: every arbitrary rem in a sizing utility
Twelve values across 11 files were authored as 16px-rem numbers and had been
rendering 12.5% small ever since. Converted to px because each one is sized to
hold content: the `DateRangePicker` panel (`19rem` → 266px, squeezing two
`input[type=date]` to ~118px, at Chromium's intrinsic minimum) is now `304px`;
`CommandPalette`'s `max-w-[36rem]` was capping the dialog 72px under its
designed width; `Popover`'s shared `min-w` floor, the `DataTable` filter panel
(short on *both* axes — `w-64` is also rem), and the `TimeSeries` / `BucketArea`
tooltips that hold explanatory prose. `Sidebar` had `w-60 min-w-[15rem]`, which
is the same value twice, both at 210px.

Four rem values were **kept** and annotated: the HeatGrid label truncation caps
and the SovBars skeleton reserve *should* track the text scale, and the
notification badge is paired with a `leading-` of the identical token so it
stays circular.

### Fixed: `Sparkline` could not shrink
A bare `width` attribute with no `max-width`, so a 200px spark inside a narrower
card pushed the entire page into horizontal scroll — silently, since an
overflowing SVG reports its full width and nothing errors. It also drew its
endpoint dot at `cx = width` under `overflow-visible`, painting 2px outside its
own box. Now `max-w-full` with `preserveAspectRatio="none"` (compress, don't
letterbox, so row height holds) and `vector-effect="non-scaling-stroke"` to keep
the 1.5px stroke true; the plot is inset by the dot radius so nothing is drawn
outside the viewBox at all. **Verified: 0 horizontal page overflow across all 6
demos at 1440 / 1280 / 1024 / 900 / 768.**

**Measured:** 0 of 1828 text nodes below WCAG AA across 6 demo pages × 2 themes,
cold boot, alpha-composited. Minimum ratio 4.51.

---

## v6.5.0 — 2026-09-02 · The chart set completes

`SovBars`, `BucketArea`, `PositionLine`, `DualAxisTraffic`, `KpiTile`,
`ScoreGauge`. With `TimeSeries` and `HeatGrid` this closes the docs/06 data-viz
inventory.

Every demo series carries the same scan outage on `2026-06-08`, so each
component is checked against one question: **can an unmeasured point ever render
as zero?** In all of them, no.

### Components
- **`SovBars`** — hand-rolled divs rather than a Recharts `BarChart`, because a
  vertical bar chart turns the percentages into unselectable SVG text, needs a
  guessed left margin that clips domain names, and — decisively — has no way to
  draw `null` as anything but an absent bar, which is identical to 0%. Bars scale
  to the **whole measured market**, not to the leader, so a 4% share looks like
  4%; scaling to the top competitor makes every chart read as a close race. The
  footer states what share the listed rows actually cover.
- **`BucketArea`** — the 4-band law stacked over time. A stack physically cannot
  draw a hole in one layer, and a missing layer is indistinguishable from a zero
  one, so the contract is: an unscanned date is `null` in EVERY band and the
  whole column becomes a gap. Verified — all six stacked layers break at the
  outage. No legend toggles: hiding one layer of a stack changes every other
  layer's height and the total.
- **`PositionLine`** — `invertY` is set internally and deliberately NOT exposed,
  so no caller can silently mirror a ranking chart. Prints "Position 1 at top ·
  N of M not measured", because a single-series chart renders no legend and the
  inversion would otherwise be unannounced.
- **`DualAxisTraffic`** — both axes stay 0-based; unlike rank, zero is real for
  traffic and a truncated axis exaggerates movement.
- **`KpiTile`** — the delta requires a contextual label. Drops the delta when
  the value is null (a percentage change against a reading we do not have is
  invented) but keeps the sparkline, because the history is real and the gap at
  its end is informative.
- **`ScoreGauge`** — the ring is `aria-hidden`; the number and the threshold word
  carry the reading. `null` renders an empty track and "Not measured", never a
  zero ring.

### Fixed — two duplications that would have drifted
- **`ScoreGauge` had its own copy of the score thresholds** because
  `primitives.tsx` did not export them. `scoreLevel()`, `SCORE_LABEL`,
  `SCORE_TONE` and `SCORE_THRESHOLDS` are now exported and both surfaces use
  them. Left alone, the same score would eventually have read "Strong" in the
  gauge and amber in the badge on the same screen.
- **`BucketArea` had a private token resolver** with its own MutationObserver,
  because `useChartTokens`' token list did not carry the rank ramp. The ramp is
  now in the central list with a `RANK_TOKEN` map, and the private hook is gone.
  Two observers reading the same tokens is how two charts end up on different
  palettes after a toggle.

### Fixed — the demos were never being typechecked
`tsconfig.json` included only `src/**`, so every `npx tsc --noEmit` run this
session had been ignoring `demo/`. The gap surfaced when a demo compiled
"cleanly" and then crashed at runtime with *Cannot read properties of undefined*
— it was passing `values` to a prop named `positions`, plus three other API
mismatches TypeScript would have caught. `demo/**` is now in `include`, which
makes each demo a compile-time test of the public API. Added `npm run check`
(typecheck + CSS parse) as the single gate.

### Added — a standing contrast harness
`/kit/demo/audit.html` loads every demo in an isolated frame, **cold-boots it in
each theme** via `?audit=<theme>` applied before first paint, and measures the
real alpha-composited contrast of every rendered text node.

Cold boot is the point. Toggling the theme and measuring in the same tick reads
mid-transition values: the harness's own first run reported 58 failures that
were all artefacts of exactly that mistake, which is also what produced several
phantom failures earlier in this build.

### Measured
| Page | Dark | Light |
|---|---|---|
| Component kit | 0 / 192 | 0 / 192 |
| DataTable | 0 / 273 | 0 / 273 |
| Charts | 0 / 41 | 0 / 41 |
| HeatGrid | 0 / 159 | 0 / 159 |
| Chart set | 0 / 103 | 0 / 103 |

**0 of 1536 nodes below WCAG AA across 10 page/theme combinations.**

---

## v6.4.0 — 2026-09-02 · HeatGrid

The city × keyword rank matrix (S-06 Local). Deliberately NOT a Recharts
component: a heat grid is a table — sticky headers, row and column summaries,
keyboard traversal, text in every cell — and Recharts has no primitive for that.
Forcing one would cost the semantics that make it readable to a screen reader.
Built as a real `<table>`.

### Choices that are correctness, not styling
- **Every cell prints its rank.** The four band hues collapse under
  deuteranopia and this grid is otherwise nothing but colour. The number is the
  encoding; the fill is the fast scan.
- **Not measured is not rank 20+.** An unscanned cell renders in a hatched
  "none" band with an em-dash. Conflating the two turns a scanner outage into a
  false report of lost rankings — the demo makes this concrete with a whole
  city (Pearland) whose scan failed.
- **Row averages ignore holes, and show the denominator.** `16.2` is printed as
  `16.2  6/7`. An average that silently changes its denominator is how a partial
  scan starts looking like an improvement.
- **Coverage is stated in the toolbar** (`48/56 cells measured, 86%`), so a grid
  that looks sparse because the scanner failed cannot be mistaken for one that
  looks sparse because the rankings are bad.
- **Rows with nothing measured sort last in BOTH directions** — "no data" is
  neither a good result nor a bad one.
- **The Avg column is pinned right**, like the location column is pinned left.
  It carries the measured/total denominator, so it must not be the first thing
  to scroll out of view on a wide grid.

### Added — `--sc-rank-*-on` tokens (ink on the SOLID band fill)
Distinct from `*-ink`, which is ink on the band's *soft* 15% fill. Heat cells
are solid, and the bands span too wide a lightness range for one ink to clear
4.5:1 on all of them: in light, AS Black passes on pack (5.20) and page-one
(6.11) but fails on 20+ (2.77), while white passes on 20+ (7.03) and fails on
pack (3.74). **So the ink is per band, per theme.** All ten pairs measured and
≥ 4.5:1. `RankBandMeta` gains an `onFill` field so callers never pick.

### Fixed
- Legend printed the band label and its range, giving "20+ 20+". Same
  duplication class as the earlier `RankPill` fix.

### Measured
HeatGrid demo, cold boot:

| Theme | Nodes | Below AA | Min ratio | Heat cells | Cell min |
|---|---|---|---|---|---|
| Dark | 158 | **0** | 4.51:1 | 56 | 5.49:1 |
| Light | 158 | **0** | 4.59:1 | 56 | 4.59:1 |

Live at `/kit/demo/heatgrid.html`.

---

## v6.3.0 — 2026-09-02 · TimeSeries + AlgoOverlay

The first chart. docs/06 requires the algorithm-update overlay on EVERY
timeline, so it is built into `TimeSeries` rather than left to callers —
omitting it should be a deliberate act, not an oversight.

### `TimeSeries`
- **AlgoOverlay** — bands from `data/algo-updates.json`, drawn behind the
  series, clipped to the visible window. A rollout that began before the window
  still renders, because it still explains what the chart shows. Confirmed
  updates are solid; **unconfirmed are dashed and labelled**, per the data
  file's own instruction to keep verified versus fabricated.
- **SignalMarkers** — our own activity (deploys, publishes, campaign starts) as
  dashed verticals, so a lift that follows a deploy is not mistaken for an
  algorithm effect.
- **Dual y-axis** — GSC clicks (~250/day) and impressions (~6000/day) on one
  scale flattens clicks into the floor. `axis: "right"` moves a series to the
  right-hand axis; the tooltip marks it. This also delivers `DualAxisTraffic`.
- **7-day rolling mean**, opt-in. The tooltip still reports the RAW measurement,
  so smoothing never hides the actual number behind an average.
- **Inverted axis** (`invertY`) for rank charts, where 1 is best.
- Legend toggles per series; loading and not-connected states.

### Rules encoded
- **`null` is a hole, not zero.** An unmeasured day BREAKS the line rather than
  dropping to the floor. `connectNulls` is off by default. Verified: the
  five-day June gap produces two `M` commands in the path.
- **Never colour alone.** The tooltip prints the value AND the signed change
  versus the previous point, so the reading survives without hue.
- **Max 3 series.** Beyond three a legend stops being readable; the answer is a
  small multiple. Passing more warns and still renders — refusing to draw the
  caller's data is worse.
- **Y starts at zero** unless `zoomY` is passed. A truncated axis exaggerates
  movement, and this is an honesty-first tool.

### Added — `useChartTokens()`
The piece that makes charts theme-aware. Everything else in the kit styles
through classes and follows the theme for free; Recharts cannot, because it
writes `stroke` and `fill` as SVG attributes and needs a literal colour at
render. A chart given `var(--sc-chart-1)` renders with no stroke; one given a
hex renders the wrong theme's palette after a toggle, silently. The hook reads
the computed tokens and **re-reads on a MutationObserver watching the theme
class** — the observer is the whole point, since a one-shot read freezes the
palette at first paint. Verified: strokes, bands, grid and axis text all change
on toggle.

### Added — `--sc-algo-*` tokens
`algo-updates.json` carries a `_meta.type_colors` map, but those are fixed hexes
that cannot flip with the theme and are not AS hues. They are advisory; the
bands render from tokens instead, per theme.

### Fixed — chart tokens' dark comments described the LIGHT hexes
Carried over during the dark-first inversion. Anyone tuning `--sc-chart-3` in
dark would have been reading `#A52B30` while the value was `#EB8984`.

### Fixed — Recharts' line-draw animation STALLS
Caught only by rendering it. The Impressions line sat permanently at
`stroke-dasharray: 38px 3330px` — about 1% drawn — and was simply not there,
with no error. Recharts' entry animation freezes when the component re-renders
mid-flight, and a theme toggle is enough to trigger it because the token hook
re-renders.

Entry animation on data series is now off. That is also what the AS motion spec
already asked for: *"Data updates (numbers counting): cross-fade 200ms, no
tickers or counting animations."* Hover and tooltip motion are unaffected.

### Measured
Charts demo, cold boot, both themes:

| Theme | HTML nodes | Below AA | Min ratio | SVG axis text | Series stroke vs ground |
|---|---|---|---|---|---|
| Dark | 40 | **0** | 4.66:1 | 4.81:1 | — |
| Light | 40 | **0** | 4.97:1 | 5.75:1 | 5.11 / 5.43 (needs 3:1) |

Live at `/kit/demo/charts.html`.

**Next in `components/charts/`:** `PositionLine` (a preset of TimeSeries with
`invertY`), `BucketArea`, `SovBars`, `HeatGrid`, `DualAxisTraffic` (a preset of
the dual-axis path above).

---

## v6.2.0 — 2026-09-01 · DataTable

The component 8+ registry screens are blocked on (S-02, S-04, S-08, S-11, S-14,
S-27, S-38, S-39). Built to the Baptist anatomy, which is already proven against
this kind of data.

### `DataTable<T>`
Generic over the row type, driven by a column config:

- **Debounced search** (300ms) across visible columns that expose a `value`.
- **Filter popover** — multi-select, staged locally and committed on **Apply**,
  so a multi-select does not re-filter the table on every checkbox.
- **Column visibility**, with `locked` columns that cannot be hidden.
- **Density** — Compact / Default / Comfortable, persisted per viewer to
  localStorage (every access try/caught; a table must not crash because it
  could not remember a preference).
- **Selection + bulk bar**, with select-all and an indeterminate header state.
- **Sortable columns**, three-state: asc → desc → cleared. `aria-sort` tracks.
- **Card collapse below `md`**, as a definition list per row.
- **Per-row provenance** via `rowSource` → `SourceBadge`.
- **Sticky header**, zebra rows, tabular figures on numeric columns.

### Three behaviours that are correctness, not styling
1. **`null` is NOT zero.** It means NOT MEASURED and always sorts **last, in
   both directions**. Verified: ascending gives `1,2,4,6,7,9,11,14,18,20+,—,—`
   and descending gives `20+,18,…,1,—,—`. Without this, sorting a rank column
   ascending floats unmeasured rows to the top as if they ranked #1.
2. **Empty has two meanings.** "No rows match" offers *Clear filters*; "nothing
   here yet" offers the primary CTA. Showing the wrong one sends people hunting
   for data that never existed, or for a filter they never set.
3. **Chrome stays at zero rows.** Toolbar and controls remain visible in every
   state, so whatever produced the empty result is still reachable.

Search covers only **visible** columns — matching a hidden one produces a row
with no visible reason to be there. Verified: searching a term that exists only
in a hidden column returns 0 rows, and returns 1 the moment that column is
unhidden.

### Added alongside
- **`Popover` + `CheckRow`** — hand-rolled, no Radix (the scaffold has none).
  Dismisses on outside `pointerdown` (not click, so the first click outside is
  not swallowed) and on Escape. Documented limitation: no collision detection,
  so it can overflow a narrow viewport near the edge.
- **`lib/use-table.ts`** — `useDebouncedValue`, `usePersistentState`,
  `useDismissable`, `compareValues`.

### Fixed
- **`DeltaPill` dropped the sign on negative values** — it rendered "1
  positions" with only the arrow carrying direction. Now uses U+2212 MINUS,
  per the AS rule that deltas use `+/−` and never a hyphen.
- **Dark rank inks were tuned against the card, not the zebra row.** Rank pills
  live in tables, half of whose rows are striped, and the striped ground is
  lighter in dark mode — so pills that passed on the card measured 3.91–4.37:1
  one row down. Retuned against the worse ground.

### Measured
The table demo (S-04 rankings, 12 rows, all states), cold boot:

| Theme | Nodes | Below WCAG AA | Min ratio |
|---|---|---|---|
| Dark | 272 | **0** | 4.51:1 |
| Light | 272 | **0** | 4.61:1 |

Live at `/kit/demo/table.html`.

---

## v6.1.1 — 2026-09-01 · Teal fills take dark ink · design system served locally

### Changed — `--fg-on-teal` is AS Black in BOTH themes *(operator decision)*
White on CTA Teal `#0D9488` measured **3.74:1** in light and **3.22:1** on the
dark teal — it failed either way, so the on-colour no longer flips. A teal fill
always carries dark ink: **5.20:1** in light, **6.04:1** in dark. This clears the
last 8 AA failures and makes the two themes behave identically.

### Added — teal FILL interaction tokens, separate from the text ones
The flip had a consequence worth stating plainly: AS's hover/press states
*darken* (`#0B7E74`, `#0A6B62`), which is right for teal TEXT on a light page but
wrong under dark ink — it dropped hover to **3.94:1** and press to **3.05:1**.

Conflating "teal that is a fill" with "teal that is text" is the actual bug, so
they are now separate tokens:

| Token | Direction | Used for |
|---|---|---|
| `--cta-teal-hover` / `-press` | darkens | teal TEXT on a page ground |
| `--teal-fill-hover` / `-press` | **lightens** | teal FILLS carrying dark ink |

Fill states now climb the primary ramp, so contrast only ever improves from
rest: light `5.20 → 6.04 → 8.47`, dark `6.04 → 8.47 → 11.34`.
Use `bg-teal-fill-hover`, never `bg-teal-hover`.

### Added — the design system runs at a local URL
`design/serve.mjs` + `design/package.json`, plus `.claude/launch.json` so the
Browser pane can start it by name.

```
npm --prefix design run dev     # http://localhost:4321
```

| Route | What |
|---|---|
| `/` | landing page — anchors, rules, links |
| `/preview/` | brand board (colour, type, components, motion) |
| `/kit/demo/` | the live React kit, both themes |
| `/ui_kits/geo_monitor/` | full dashboard shell |

`dev` builds the kit demo first, so the bundle is never stale. The server sends
`no-store`: a cached stylesheet costs more debugging time here than it saves in
load time — several of the phantom contrast readings during the v6.1.0 work were
stale CSS, not real failures.

### Measured — both themes now clean
| Theme | Nodes | Below WCAG AA | Min ratio |
|---|---|---|---|
| Dark (cold boot) | 191 | **0** | 4.51:1 |
| Light (cold boot) | 191 | **0** | 4.55:1 |

---

## v6.1.0 — 2026-09-01 · Dark-first + the kit rewritten in TypeScript

**Why this version exists:** two operator decisions. Vantage is **dark-first**,
matching the Baptist SaaS it descends from; and the component kit moves to the
stack the app actually uses. Brand values are unchanged from v6.0.0 — this is an
architecture change, not a rebrand. Per `capabilities/baptist-saas-patterns.md`
("structure copy-portable, colours are not"), Baptist's layout, density and
component anatomy carry over while the palette stays Authority Solutions.

### Dark-first token architecture
- `:root` now carries the **dark** palette, so an un-themed render is dark and the
  app never flashes light on first paint. `.light` / `[data-theme="light"]`
  re-derives the AS light palette (52 tokens; everything else is inherited, so a
  theme-invariant value has exactly one home).
- `.dark` is aliased to `:root`, so next-themes (`attribute="class"`,
  `defaultTheme="dark"`) works in both directions.

### Added — the rank-band law
`--sc-rank-1-3 / 4-10 / 11-19 / 20-plus`, plus `-soft` fills and `-ink` text
colours, in both themes. The split and the "orange ends at 19, red starts at 20"
boundary come from Baptist; the hues are AS (teal → amber → ember → brand red).
`--rank-none` is deliberately distinct from `--rank-20-plus`: a scan that failed
must never render as a rank-20 result.

**Colour is never the only encoding** — the four hues collapse under
deuteranopia, so `RankPill` always prints its number and `rankLabel()` returns an
em-dash for unmeasured.

### Added — `*-ink` tokens
`--sc-teal-ink`, `--sc-amber-ink`, `--sc-danger-ink` and the five `--sc-rank-*-ink`.
These are the TEXT colour for use on the matching `*-soft` fill. The base colour
on its own tint measures **2.8–3.9:1** in light mode and fails; the ink variants
are darkened to clear 4.5:1 on the real composited ground, measured in the browser
rather than derived on paper.

### Fixed — `--sc-` namespace on the shadcn layer *(latent since v5)*
`colors_and_type.css` (hex) and `tokens.css` / `shadcn.css` (HSL channels) both
defined `--primary`, `--border`, `--accent` and `--ring`. Whichever file loaded
last won, so one layer was **always silently broken**: a component doing
`color: var(--primary)` received `"175 84% 32%"`, which is not a colour, so the
declaration was dropped and the element inherited instead. Nothing errored. The
HSL layer is now namespaced `--sc-*` and the two coexist. 18 collisions removed.

### Fixed — tailwind-merge was dropping colour classes
`cn()` now uses `extendTailwindMerge` with this system's custom font sizes
registered. The stock merger cannot tell `text-meta` (a size) from
`text-ink-on-teal` (a colour), files both under `text-*`, decides they conflict,
and keeps only the last. Primary buttons were losing their text colour entirely
and inheriting the body colour — near-white on a teal fill at **2.99:1** instead
of AS Black at 6.04:1. Silent, and theme-dependent.

### Fixed — assorted
- `--fg-on-dark-3` was 3.39:1 on the always-dark sidebar; lifted to 4.66:1.
- `--engine-claude-dark` was 4.00:1 on its own chip; darkened to 4.66:1. This is
  an AS-chosen dark variant, not Claude's brand colour, so it was ours to adjust.
- Surface badges now take the vendor's **dark** variant for text: the base colour
  on its own soft chip is 2.2–3.7:1. The mark keeps the base colour — it is an
  identity glyph, not text.
- Added `--accent-on-dark` for fixed chrome. The sidebar is dark in both themes,
  so its avatar cannot use the theme-flipping teal (white on the light teal is
  3.74:1).
- `ink-4` (disabled/placeholder) is no longer used for supporting content.
- A multi-line trailing comment split during the token inversion, leaving an
  unterminated `/*` that swallowed the rest of the `.light` block. Every
  declaration comment is now single-line, and the rule is written down.

### The kit — `design/kit/`
14 components rewritten as **10 `.tsx` modules**: TypeScript (strict,
`noUncheckedIndexedAccess`, `noUnusedLocals`), Tailwind, `cva` variants, `cn()`
merging, Lucide icons, real package with a barrel export.

New in the rewrite, because the registry needed consumers: `StatusPill`,
`SourceBadge`, `RunStatePill`, `RankPill`, `SeverityDot`.

- **`lib/icons.ts`** — the icon registry. Callers ask for a *state*
  (`pass`, `collecting`, `dataforseo`), never an icon. Covers the four families
  the Baptist captures use and our 30 loose SVGs could not express: provenance
  (17 sources), audit state, run + citation lifecycle (15 states), geo/scan.
  Lucide only; the 6 vendor surface marks are the one sanctioned exception.
- **`lib/rank.ts`** — the band law, with `rankBand()` / `rankLabel()`.
- **`lib/surfaces.ts`** — the 6-surface metadata as pure data.
- **`DeltaPill` requires a `label`** and takes `goodDirection`, because direction
  alone misreads: "wait time down 8%" is good, and a *lower* rank number is good.
- **`Sidebar` role-gating is omission, not hiding** — gated items never reach the
  DOM. Scope-gating dims with a tooltip instead of vanishing.
- **`AIInsight` cannot render without a `source`** — the citation is structural,
  so the Insight Engine cannot make a claim it cannot attribute.

`design/_v45_ui_kit/` is deprecated (see its `DEPRECATED.md`) and kept for
reference only.

### Measured
Every rendered text node in the live React demo, both themes, alpha composited:

| Theme | Nodes | Below WCAG AA | Min ratio |
|---|---|---|---|
| Dark (cold boot) | 191 | **0** | 4.51:1 |
| Light (cold boot) | 191 | 8 | 3.74:1 |

All 8 light failures are the one inherited AS pairing: **white on CTA Teal
`#0D9488` = 3.74:1**. It clears AA for large/bold text and UI components but not
normal-size text. Left as the AS brand specifies. Flipping `--fg-on-teal` to AS
Black in light would measure **5.20:1** and make light match what dark already
does — a one-line change, but a visible change to the brand's button, so it is
the operator's call.

---

## v6.0.0 — 2026-09-01 · Authority Solutions rebrand (reverts v5.0.0 NitroViz)

**Why this version exists:** the app is built and branded as **Authority Solutions Vantage**. The brand layer reverts from NitroViz to Authority Solutions. Source of truth: `AS - SaaS Design System/` at the project root (colors_and_type.css + README.md + `uploads/AS Branding Guide (Updated).pdf`) — treat that folder as read-only. This is a **brand** change, not a product-taxonomy change: the v4 entity model, the v4.5.1 6-surface AI taxonomy, per-surface pricing, and Viewer-Mode rules are unchanged.

### Brand values restored
| Token | v5.0.0 (NitroViz) | v6.0.0 (Authority Solutions) |
|---|---|---|
| `--as-black` | `#051410` | **`#100C0A`** Primary Black |
| `--as-brown` | `#162A25` | **`#312B28`** Dark Brown |
| `--as-red` | `#C82D45` | **`#A52B30`** Brand Red |
| `--as-red-dark` | `#6E1926` | **`#6A1215`** Dark Red |
| `--as-slate` | `#81908C` | **`#5E6771`** Slate Gray |
| `--cta-teal` | `#00A38C` | **`#0D9488`** CTA Teal |
| `--amber` | `#B28D00` | **`#D97706`** |
| `--bg-page` | `#F1F9F7` | **`#F7F6F5`** warm off-white |
| `--border` | `#CDDDD9` | **`#E8E5E3`** |
| UI / body + headings | Inter + Plus Jakarta Sans | **Poppins** (one family — AS has no separate display face) |

The two-zone signature is back: near-black sidebar `#100C0A` against warm off-white content `#F7F6F5`, with brand red reserved for logo / critical alerts / destructive confirmations and teal as the only primary-action color.

### Changed
- **`@theme` ramps re-derived.** The 11-step primary/secondary/accent/neutral ramps were regenerated in OKLab from the AS anchors on the same lightness ladder, with **each anchor pinned verbatim onto its step**: `primary-600 #0D9488`, `secondary-700 #5E6771`, `accent-700 #A52B30`, `neutral-950 #312B28`. AS Black `#100C0A` (L=0.159) is darker than the ramp floor and is kept as a standalone brand-ink token rather than forced into a step.
- **Dark theme rebuilt as an AS extension.** The source AS system is explicitly light-only ("no dark-mode styling on the content area"); the app ships a light/dark switcher, so dark was derived from the AS anchors — page adopts AS Black, cards lift warm toward Dark Brown, and teal/red climb their own ramps for legibility. Brand red `#A52B30` measures **2.77:1** on AS Black and would fail, so dark mode uses `accent-500 #D46663` (**5.07:1**). `--fg-on-teal` **flips to AS Black** in dark: white on the dark teal fill is **3.22:1** (fails), AS Black on it is **5.92:1**.
- **`--nv-*` → `--as-*`** (the `nv` prefix meant NitroViz). Declaration-only marketing type scale; no component consumed it. `_adherence.oxlintrc.json` allowlist updated.
- **Type scale returns to AS dashboard density:** h1 28→24, h2 24→20, h3 20→16. Radii go the other way: cards 10→12, modals 12→16 (`--r-3xl` 16→20).
- **Shadow tint** returns to AS warm ink `rgba(16,12,10,…)` from NitroViz `rgba(12,25,22,…)`.
- **Preview suite** re-pointed at Poppins, AS logo art, and AS ramps; `colors.html` swatches are now generated from the `@theme` block so the preview cannot drift from the tokens.

### Added
- **`--border-input`** — a form-control border that clears **WCAG 1.4.11 (3:1)** in both themes (`#908B88` light = 3.37:1, `#797370` dark = 3.88:1). AS's `--border-strong` (`#D6D2CF`) is **1.50:1** on white; it is a decorative divider and must never be the boundary of an interactive control. *This token is not in the source AS system.*
- **§5.2 Contrast record** in `colors_and_type.css` — every light and dark pair measured (WCAG 2.1, sRGB), not estimated.
- **`AS_DESIGN_SYSTEM_SLOT.md`** — replaces `VANTAGE_DESIGN_SYSTEM_SLOT.md`; documents the AS brand source, what maps where, and the open vector-logo gap.

### Fixed
- **349 hex literals across `_v45_ui_kit/` and `ui_kits/geo_monitor/` converted to `var(--token)` references.** These violated the project's "no hex literals in components" rule, and — now that a dark theme exists — they were a live bug: hardcoded colors do not respond to the theme toggle, so those components would have rendered light-mode colors on a dark ground. White card backgrounds are now `var(--bg-card)`, and text on brand fills uses `--fg-on-teal` / `--fg-on-red` / `--fg-on-amber` so it flips correctly. Google/Gemini brand **gradient stops** are deliberately left as literals.
- `_ds_bundle.js` given the same conversion (162 literals) so it matches its sources; its `sourceHashes` are now **stale** — rerun the real bundler to refresh.
- Stale pre-v4.5 engine colors (Perplexity forest-green `#1A7F64`, old Gemini `#8B5CF6`, old ChatGPT `#10A37F`) that survived only in the bundle were mapped onto the correct `--engine-*` tokens.
- `preview/_ds.js` and the sidebar components pointed at NitroViz logo files that no longer exist; re-pointed at the AS art.
- **Theme-flipping tokens used as foregrounds** — caught by rendering both themes and measuring every text node, not by inspection:
  - 24 components used `var(--as-black)` as a **text** color. In the source AS system `--fg-1: var(--as-black)`, so the two are identical in light and the reads were harmless. But `--as-black` is a brand constant that deliberately does **not** flip in dark (the always-dark sidebar needs it), so those nodes rendered near-black on a near-black card. All converted to `--fg-1`.
  - The active sidebar nav item used `var(--bg-page)` as its text color — off-white on the dark sidebar in light mode, but `--bg-page` becomes AS Black in dark, so the active item went black-on-brown. Converted to `--fg-on-dark-1`, which is intentionally never overridden in `.dark` because the sidebar is always-dark chrome.
  - `ui_kits/geo_monitor/index.html` set `color: '#100C0A'` as a raw hex on the app-shell root, so **every** descendant inherited a light-mode ink. Tokenized along with its scrollbar and focus-ring hexes.
  - Verified by measuring all 76 rendered text nodes in the live React UI kit: **0 nodes below 3:1 in either theme** (was 10+ in dark before these fixes).
- **The AS lockup has no reversed variant** and its wordmark is dark, so it was illegible on every dark surface — including the preview header. Dark surfaces now use the shield mark alone, which reads; the identity demo pins each card to a real light/dark ground instead of inheriting the theme. Reversed art is requested, not fabricated. See the asset-gap note below.
- `.btn-destructive` in the preview shell hardcoded `color: #fff`; on the dark-mode error fill that is ~2.9:1. Now `var(--on-error)`, which flips.
- The preview components page demoed brand red as a routine "Deploy to edge" action, contradicting the AS rule that red is reserved. Relabelled to a true destructive action and the copy corrected.
- Preview theme storage key renamed `nv-theme` → `as-vantage-theme`.

### Unchanged by design
- **AI surface colors (§6)** — the 6-surface v4.5.1 taxonomy and its vendor-correct hexes (Perplexity `#20B8CD`, ChatGPT `#0F9F7A`, Gemini `#9168C0`, Claude `#D97757`, AI Overviews / AI Mode `#4285F4` + Google gradient). **Deliberately NOT reverted** to the legacy AS values — the old AS system carries outdated surface hexes and a single "Google AI" entry, and reverting would misattribute the vendors.
- Data-platform colors (§7), GSC Google Blue, the spacing scale, z-index scale, and motion durations/easings.

### Asset gaps (outstanding, operator action)
- **No vector logo art.** AS supplied PNG only. Wired in and fine at current sizes; an SVG was deliberately not auto-traced from the PNG, since a trace of a brand mark is not the brand mark.
- **No reversed lockup.** The wordmark is dark, so the full lockup cannot be used on any dark surface. Dark surfaces currently fall back to the shield alone. Both gaps and their drop-in procedure are in `AS_DESIGN_SYSTEM_SLOT.md`.

### Known caveat (inherited from the AS brand)
White on CTA Teal `#0D9488` measures **3.74:1** — clears WCAG AA for large/bold text and UI components (3:1), but **not** normal-size body text (4.5:1). AS specifies teal for buttons and links, so it is left as the brand specifies. Use `--cta-teal-press` (`#0A6B62`, **6.38:1** on white) where teal must carry normal-size text.

### Removed / quarantined
Moved to `design system delete/` (nothing deleted): the `NitroViz Design System/` brand source, the six `NitroViz_*` logo files from `design/assets/logos/`, and `VANTAGE_DESIGN_SYSTEM_SLOT.md`.

---

## v5.1.0 — 2026-08-05 · Preview suite rebuild + shadcn/GSAP integration
- **Rebuilt `preview/` as a cohesive 5-page brand board** (index · colors · type · components · motion) on a shared shell (`_ds.css`/`_ds.js`): Vantage logo lockup in the header (SVG light / cream dark), sticky nav, and a **persistent dark/light theme switcher** on every page (localStorage + system-preference default). Deleted the 19 stale AS-era preview pages.
- **`design/shadcn.css` (new):** Vantage tokens mapped onto shadcn/ui variable names (`--background`, `--foreground`, `--primary`, `--ring`, `--chart-1..5`, plus `--nv-accent`/`--nv-*` extras) — stock shadcn components render on-brand with zero per-component styling. Note: shadcn's `--accent` = hover wash; brand ember lives at `--nv-accent` (one per view).
- **Motion spec (new, `preview/motion.html`):** GSAP 3 presets (card entrance stagger, metric count-up, alert slide-in, chart line draw) with motion tokens (150/250/400/800ms, power2/power3 easing, 60ms stagger) — all reduced-motion aware; presets to ship in `lib/motion.ts`. No shadcn/GSAP repos exist in the project; conventions implemented from the stack spec — drop repos in `docs/` if specific ones should supersede.

## v5.0.0 — 2026-08-05 · Vantage Rebrand

**Status:** Complete. Applies to the `design/` folder of the Vantage project.

**Why this version exists:** The design system's brand identity moved from Authority Solutions' original palette to NitroViz. **Superseded by v6.0.0 (2026-09-01), which reverted the brand layer to Authority Solutions.** This was a **brand** rebrand, not a product-taxonomy change — the v4 entity model, the v4.5 6-surface AI taxonomy, per-surface pricing, and Viewer-Mode rules were unchanged and carried forward.

**Decision:** Every CSS custom property **NAME** is preserved byte-for-byte (`--as-black`, `--cta-teal`, `--fs-h1`, `--engine-chatgpt`, etc.) so every component in `_v45_ui_kit/`, `ui_kits/geo_monitor/`, and every `preview/*.html` page keeps working with zero code changes. Only token **VALUES** for genuine Authority-Solutions-brand tokens changed. AI-surface colors (Perplexity/ChatGPT/Gemini/Claude/AI Overviews/AI Mode) and data-platform colors (Ahrefs/Majestic/Apify/Firecrawl/NeuronWriter/GSC) are real third-party brand colors and were explicitly **left unchanged** — out of scope for an agency brand rebrand.

### Color corrections (Authority Solutions → Vantage)

| Token | Old (AS) | New (Vantage) | Source |
|---|---|---|---|
| `--as-black` (sidebar dark) | `#100c0a` | `#100C0A` | Vantage surface (dark) |
| `--as-brown` (sidebar hover) | `#312b28` | `#312B28` | Vantage surface-muted (dark) |
| `--as-red` / `--danger` | `#a52b30` | `#A52B30` | Vantage error |
| `--as-red-dark` | `#6a1215` | `#6A1215` | Deepened Vantage error |
| `--as-slate` | `#5e6771` | `#5E6771` | Vantage neutral-500 |
| `--cta-teal` (primary) | `#0D9488` | `#0D9488` | Vantage primary-500 |
| `--amber` (warning) | `#d97706` | `#D97706` | Vantage warning |
| `--bg-page` | `#f7f6f5` | `#F7F6F5` | Vantage surface-subtle (light) |
| `--border` | `#e8e5e3` | `#E8E5E3` | Vantage border (light) |
| `--fg-1` (primary text) | `#100c0a` (aliased to `--as-black`) | `#100C0A` | Decoupled — now Vantage's dedicated APCA-verified text-primary (light) |

Full token-by-token mapping in `design_tokens.json` → `vantage_rebrand_2026_08_05`.

### Typography corrections

| Role | Old (AS) | New (Vantage) |
|---|---|---|
| UI / body | Inter | **Poppins** |
| Headings / display | Plus Jakarta Sans | **Poppins** *(alias of sans — AS has no separate display face)* |
| Numbers / data | JetBrains Mono | **JetBrains Mono** *(unchanged — already correct)* |
| Editorial narrative | *(retired)* italic Inter | *(retired)* italic **Poppins** |

### New additions (not present in v4.5.1)

- Tailwind v4 `@theme` block with the full 11-step Vantage ramps (primary/secondary/accent/neutral) + semantic success/warning/error/info
- Canonical "App Semantic Tokens" layer (`--surface`, `--text-primary`, `--primary`, `--accent`, `--success`, `--info`, `--on-*`, etc.) in `colors_and_type.css` §5.1
- A working `.dark` block — the prior system had a permanently-dark sidebar but no app-wide light/dark toggle; Vantage's token set (and the parent Vantage app) both require one
- `--font-display` token (Poppins — alias of `--font-sans`)
- §12.1 canonical marketing/brand type scale (`--nv-display-size`, etc.) — renamed to `--as-*` in v6.0.0
- 6 Vantage logo files (`design/assets/logos/`) — SVG + PNG, transparent + cream — replacing the deferred-SVG Authority Solutions shield + wordmark PNGs
- `VANTAGE_DESIGN_SYSTEM_SLOT.md` — documented how the immutable `NitroViz Design System/` source mapped in *(removed in v6.0.0; `AS_DESIGN_SYSTEM_SLOT.md` restored)*

### Unchanged by design (real third-party brand colors, out of scope)

- All 6 AI-surface colors (`--engine-*`) — Perplexity, ChatGPT, Gemini, Claude, AI Overviews, AI Mode
- All data-platform colors except DataForSEO's slate fallback (`--data-*`)
- GSC Google Blue (`--gsc-blue`), AI Mode's Google-Blue focus ring (`--shadow-focus-google`)
- The entire v4 entity model, v4.5 6-surface AI taxonomy, per-surface pricing, cost-transparency patterns, Viewer-Mode's 9 rules, scope/role pill logic, motion/animation system

### Deletions

- `design/assets/logo-icon.png`, `design/assets/logo-main.png` (Authority Solutions shield + wordmark)
- `design/AS_DESIGN_SYSTEM_SLOT.md` (replaced by `VANTAGE_DESIGN_SYSTEM_SLOT.md`)
- `design/uploads/` — all Authority Solutions brand collateral (branding guide PDFs, AS logo PNGs, AS-branded screenshots) and duplicate hash-suffixed copies of files that already live at their canonical path elsewhere in `design/`. AI-platform engine SVGs and `ai-platform-brand-spec.md` were preserved (moved to `design/assets/engines/` where not already present — product-functional, not AS branding).

### Files updated

`colors_and_type.css` · `design_tokens.json` · `tokens.css` · `styles.css` · `SKILL.md` · `PROJECT_CONTEXT.md` · `README.md` · `CHANGELOG.md` (this entry) · `asset_registry.md` · `_ds_manifest.json` · `_adherence.oxlintrc.json` · `VANTAGE_DESIGN_SYSTEM_SLOT.md` (new) · `_v45_assets/logos/README.md` · component kits (`_v45_ui_kit/*.jsx`, `ui_kits/geo_monitor/*`) · `preview/*.html`

---

## v4.5.1 — 2026-05-28 · Brand Spec Reconciliation

**Status:** Phase 1.5 of 8 complete (foundation file corrections). Phases 2–8 unchanged.

**Why this version exists:** Mid-Phase-1 of v4.5, the AS brand spec doc `brand-icons/ai-platform-brand-spec.md` v1.0 (dated 2026-05-28) was discovered. It explicitly corrects the v3/v4 surface hex values as off-brand and provides authoritative brand-faithful colors. The initial v4.5 handoff prompt used the uncorrected values. v4.5.1 reconciles foundation files with the brand spec before any downstream work (assets, components, screen prompts) locks in the broken values.

**Decision (user, 2026-05-28):** Brand spec v1.0 wins. Both Google search features (AI Overviews, AI Mode) share the Google 4-color gradient and are differentiated by mark, not color. Two icon systems coexist — 48×48 tile (brand fidelity, hero placements) + 24×24 inline (UI moments, currentColor).

### Surface color corrections

| Surface | v4.5 handoff (superseded) | v4.5.1 brand spec | Brand spec rationale |
|---|---|---|---|
| Perplexity | `#1a7f64` forest green | `#20B8CD` Perplexity Teal | Perplexity's actual identity is teal/cyan, not forest green |
| ChatGPT | `#10a37f` | `#0F9F7A` OpenAI Green refined | One step deeper for dark-UI contrast |
| Gemini | `#8b5cf6` generic purple | `#9168C0` Gemini Violet solo + gradient `#4796E3 → #9168C0 → #D96570` | Gemini is a gradient brand, not solid violet |
| Claude | `#d97706` pumpkin orange | `#D97757` Claude Coral | Anthropic uses warm coral, not saturated orange |
| AI Overviews | `#a52b30` red (wrong entirely) | `#4285F4` Google Blue solo + gradient `#4285F4 → #9B72CB → #D96570 → #FBBC04` | Google AI Overview uses Google's 4-color brand sweep, never red |
| AI Mode | `#1E40AF` navy | `#4285F4` Google Blue + same Google gradient | Per user decision: same gradient as AIO, differentiated by mark (AIO=summary bars, AIM=chat+sparkle) |

### Soft variant updates
- Perplexity soft: `#e4f0ec` → `#E6F7FA`
- ChatGPT soft: `#e3f4ee` → `#E6F5F0`
- Gemini soft: `#efe9fc` → `#F1ECF7`
- Claude soft: `#fdf3e7` → `#FBEDE6`
- AI Overviews soft: `#f8e9ea` → `#EEF3FE`
- AI Mode soft: `#dbe4f5` → `#EEF3FE` (same as AI Overviews)

### New tokens
- `--engine-perplexity-dark: #147A8B` — hover/pressed
- `--engine-chatgpt-dark: #0A7558`
- `--engine-gemini-dark: #6E47A0`
- `--engine-claude-dark: #B95A3D`
- `--engine-ai-overviews-dark: #1A65D8`
- `--engine-ai-mode-dark: #1A65D8`
- `--engine-gemini-gradient: linear-gradient(135deg, #4796E3 0%, #9168C0 50%, #D96570 100%)` — brand gradient for 48×48 tile assets
- `--engine-ai-overviews-gradient: linear-gradient(135deg, #4285F4 0%, #9B72CB 35%, #D96570 70%, #FBBC04 100%)` — Google brand sweep
- `--engine-ai-mode-gradient: linear-gradient(...)` — identical to AI Overviews gradient
- `--fg-on-google: #ffffff` — replaces `--fg-on-navy`
- `--shadow-focus-google: 0 0 0 3px rgba(66, 133, 244, 0.22)` — replaces `--shadow-focus-navy`

### Removed tokens
- `--fg-on-navy` (AI Mode no longer navy)
- `--shadow-focus-navy` (AI Mode no longer navy)

### Updated tokens
- `--surface-search-color: var(--as-red)` → `--surface-search-color: #4285F4` (Google Blue groups Google features)
- `--surface-search-tint: var(--danger-tint-04)` → `--surface-search-tint: rgba(66, 133, 244, 0.06)`

### Invalidated v4 design notes (corrected throughout)
- "Claude `#d97706` (intentionally same hex as `--amber`)" — no longer true; Claude is `#D97757`, amber is `#d97706`
- "AI Overviews `#a52b30` (same hex as `--as-red` by design)" — no longer true; AI Overviews is `#4285F4`, as-red is `#a52b30`
- "AI Mode (NEW in v4.5; deep navy)" — superseded; AI Mode uses Google gradient

### Icon system (NEW v4.5.1)
- Dual system documented: 48×48 tile (brand fidelity, hero placements) + 24×24 inline (UI moments, currentColor)
- 48×48 tiles match existing `brand-icons/` style — white mark on color/gradient, 10px corner radius
- 24×24 inline matches Lucide conventions — currentColor stroke, no fill
- Brand-icons folder retroactively becomes canonical source for v4.5.1 tile SVGs

### Files updated
- `colors_and_type_v45.css` — §1 brand palette comments, §5 fg tokens, §6 surface tokens (full rewrite), §6 surface category tokens, §15 focus shadows
- `SKILL.md` — header version, color list (§3), AI Surface identity tables (§3), spacing/chrome focus ring, visual prohibitions (§3), working rule 13 (§9)
- `PROJECT_CONTEXT.md` — header version, color palette (§4), AI Surface identity (§4), §14 master taxonomy table, §15 working rules (added rule 20 + 21)
- `README.md` — header version + companion docs, v4.5 cheat sheet (3 new rows), both category tables, brand non-negotiables (2 new rules), versioning entry
- `design_tokens.json` — surfaces[] color/soft/dark/gradient_stops, surface_categories, v45_migration_notes (NEW reconciliation section)
- `CHANGELOG.md` — this entry

### Phase tracker update

| Phase | Scope | Status |
|---|---|---|
| 1 | Foundation files (initial v4.5 hex values) | Completed 2026-05-28 (corrected by Phase 1.5) |
| **1.5** | **Brand spec reconciliation across all 6 foundation files** | **Completed 2026-05-28** |
| 2 | Asset creation (SVGs, folder reorganization) | Pending |
| 3 | UI kit components (React/JSX) | Pending |
| 4 | Canonical prompt corpus rewrite (per-screen updates) | Pending |
| 5 | Documentation (8 reference docs) | Pending |
| 6 | Workspace folder reorganization | Pending |
| 7 | Preview pages | Pending |
| 8 | Verification checkpoint | Pending |

---

## v4.5 — May 2026 · Google Surface Taxonomy Update

**Status:** Phase 1 of 8 complete (foundation files). Phases 2–8 in progress.

**Why this version exists:** Google's May 2026 rollout split the previously-single "Google AI" tracking surface into three structurally distinct citation surfaces — AI Overviews (top-of-SERP summary), AI Mode (conversational mode in Search), and Gemini (standalone chatbot at gemini.google.com). The prior 5-engine taxonomy collapsed these, obscuring the strategic story. v4.5 corrects the taxonomy, codifies a surface abstraction so v5 additions (Copilot, etc.) are a data change, and makes per-surface cost a first-class UX affordance.

### Taxonomy changes
- AI surfaces tracked: **5 → 6**
- Surfaces reorganized into two structurally distinct categories:
  - **Chatbot Surfaces (4)** — Perplexity, ChatGPT, Gemini, Claude (peer model-direct apps; brand/authority ranking signal)
  - **Google Search AI Features (2)** — AI Overviews, AI Mode (in-SERP surfaces; schema/SEO ranking signal)
- Token `--engine-google-ai` renamed to `--engine-ai-overviews` (hex `#a52b30` unchanged; glyph evolved GAI → AIO)
- NEW token `--engine-ai-mode: #1E40AF` (deep navy, distinct from GSC blue `#4285f4`)
- NEW soft variant `--engine-ai-mode-soft: #dbe4f5`
- Umbrella terminology shift: "5 LLM engines" → "6 AI surfaces"; reserve "engines" for the 4 chatbot surfaces only when distinguishing them from search features
- Brand SOV (Screen 4b) splits into two sub-sections: Chatbot SOV (4 surfaces) + Google Search AI SOV (2 surfaces) — never averaged

### Pricing model (NEW)
Per-surface cost transparency:
- Perplexity, ChatGPT, Gemini, Claude — **$0.015** per call (Research Tools MCP)
- AI Overviews — **$0.005** per call (DataForSEO SERP scraping)
- AI Mode — **$0.020** per call (conversational simulation)
- Default audit configuration: **Perplexity + ChatGPT + AI Overviews** at $0.035/audit/keyword (cheapest meaningful 3-surface mix)
- Per-surface cost displayed on every surface-selection card; per-surface aggregate displayed in N6 Usage & Metering

### Architecture changes
- Surface abstraction: all surface-rendering components iterate over a `surfaces[]` array of arbitrary length. Components never assume `length === 6`. Adding a 7th surface in v5 is a data change, not a code change.
- New tokens: `--surface-chatbots-*` and `--surface-search-*` category tokens for grouping in Brand SOV split and surface category dividers
- New focus ring: `--shadow-focus-navy` for AI Mode interactive elements
- Per-surface cost tokens: `--cost-perplexity`, `--cost-chatgpt`, `--cost-gemini`, `--cost-claude`, `--cost-ai-overviews`, `--cost-ai-mode`

### Asset reorganization
- `assets/engines/` → `assets/surfaces/chatbots/` + `assets/surfaces/search-features/`
- NEW asset folders:
  - `assets/logos/` — promoted from root
  - `assets/data-platforms/` — GSC, Ahrefs, Majestic, DataForSEO, Apify, Firecrawl, NeuronWriter brand marks
  - `assets/icons/` — common UI icons (status, actions, navigation, scope, entity) at 24×24 currentColor
  - `assets/patterns/` — radar-pulse SVG for animations
- NEW SVGs:
  - `surfaces/search-features/ai-overviews.svg` (repurposed from `engines/google-ai.svg`, glyph updated)
  - `surfaces/search-features/ai-mode.svg` (new, navy chat-bubble with sparkle)
  - `logos/logo-main.svg` and `logos/logo-icon.svg` (vector versions generated from PNG sources)

### Design system components (NEW)
Added to `ui_kits/geo_monitor/`:
- `SurfaceBadge.jsx` — pill component for any of the 6 surfaces, accepts surface ID, sizes sm/md/lg, optional cost display
- `SurfaceMatrix.jsx` — LLM Knowledge Matrix heatmap, surfaces-agnostic, N×M grid with category divider
- `SurfaceSelector.jsx` — N-card surface picker with prominent per-call cost on each card
- `CostPreview.jsx` — universal cost preview block (default / saving / warning / over / per-surface variants)
- `ScopeBanner.jsx` — universal scope banner with switcher dropdown
- `ParentDomainStrip.jsx` — universal page → domain pivot strip
- `AIInsightsCard.jsx` — universal teal-left-border insights card with optional surface-tagged tiles
- `GSCSyncStrip.jsx` — universal GSC connection state strip
- `RolePill.jsx` and `ScopePill.jsx` — small reusable pill components

### CSS utility classes (NEW)
- `.surface-pill` with `.is-perplexity` / `.is-chatgpt` / `.is-gemini` / `.is-claude` / `.is-ai-overviews` / `.is-ai-mode` modifiers + `size-sm` / `size-lg` size variants
- `.surface-matrix-cell` with state classes `.is-cited` / `.is-partial` / `.is-not-cited` / `.is-disabled`
- `.surface-selector-card` with `.cost-strip` slot for per-call cost display
- `.surface-category-divider` for the 12px visual gap between chatbot/search-feature groups
- `.surface-category-header` with `.is-chatbots` / `.is-search` (auto-renders category labels via CSS `content:`)
- `.cost-preview.is-per-surface` — grid layout for per-surface cost breakdown rows

### Documentation
- NEW `CHANGELOG.md` (this file) in both workspace and design system folders
- NEW `design_tokens.json` machine-readable token mirror
- NEW reference docs (in `docs/` and workspace `reference/`):
  - `taxonomy.md` — AI surface reference, chatbot vs search-feature distinction
  - `pricing-model.md` — per-surface costs, rationale, default config, billing FAQ
  - `naming-conventions.md` — file/route/variable name patterns
  - `viewer-mode.md` — extracted Viewer-Mode rules as standalone reference
  - `surface-playbooks.md` — per-surface optimization recipes
  - `asset-registry.md` — every asset cataloged with usage notes
  - `routing-table.md` — notification deep-link routing (workspace only)
  - `verification-checklist.md` — pre-ship screen verification (workspace only)
- NEW preview pages:
  - `surface-matrix.html` — live LLM Knowledge Matrix preview
  - `brand-sov-split.html` — Chatbot SOV + Google Search SOV layout
  - `cost-preview-states.html` — all cost preview variants
  - `role-gating-preview.html` — same screen Admin vs Viewer

### Screen prompt corpus (Phase 4 — in progress)
- Canonical screen prompts file: `GEO_Monitor_V4_SOURCE_OF_TRUTH.md` (most recent iteration with added/refined screens during build) → being rewritten as `GEO_Monitor_v45_Claude_Design_Prompts_All_Screens.md`
- v4 versions archived to `_archive/`
- Per-screen changes documented in `GEO_Monitor_v45_Handoff_Prompt.md` § B.2
- New ad-hoc verifier: `Screen_Checker_Prompt.md` — paste any screen prompt to verify v4.5 alignment

### Working rules added
- "AI surfaces" is the umbrella term, not "engines"
- Per-surface cost is a first-class UX affordance — display on every surface-selection card
- Brand SOV renders two sub-sections — never averaged across categories
- All surface-rendering components iterate over `surfaces[]` arrays — never hardcode surface count
- GSC is a data platform, not an AI surface — never participates in the 6-surface taxonomy
- Never collapse AI Overviews + AI Mode + Gemini back into a single "Google AI" surface

### Phase tracker

| Phase | Scope | Status |
|---|---|---|
| 1 | Foundation files (colors_and_type.css, SKILL.md, PROJECT_CONTEXT.md, README.md, CHANGELOG.md, design_tokens.json) | **In progress** — 2026-05-28 |
| 2 | Asset creation (SVGs, folder reorganization) | Pending |
| 3 | UI kit components (React/JSX) | Pending |
| 4 | Canonical prompt corpus rewrite (per-screen updates) | Pending |
| 5 | Documentation (8 reference docs) | Pending |
| 6 | Workspace folder reorganization (archive v3/v4, mirror reference docs) | Pending |
| 7 | Preview pages (HTML inspection surfaces) | Pending |
| 8 | Verification checkpoint (Screen Checker on 5 representative screens) | Pending |

---

## v4.0 — April 2026 · Domain → Tracked Pages Hierarchy

**Why this version exists:** v3's aggregate-root Domain model created ambiguity about what a "page" was, how to score domains independently of their pages, and how to bill an agency with 60 monitored URLs but only 4 client domains. v4 introduced a flat two-level hierarchy, usage-based billing, and explicit scope on every screen.

### Entity model
- Replaced v3 aggregate-root model with **flat two-level hierarchy: `Workspace → Domain → Tracked Pages`**
- A Domain GEO Score is the AVERAGE of its tracked pages — Domains have no intrinsic score
- Pages are NEVER summed with domains in any metric
- Tracked pages cannot exist without a parent Domain; deleting a Domain cascades
- No hard cap on tracked pages — billing is usage-based per API call class

### New screens (6 total — the N-series)
- **N1 Add Tracked Page** — 30-second modal, manual URL entry only (no sitemap import, no auto-suggest)
- **N2 Tracked Pages Management** — sortable/filterable list with bulk actions
- **N3 Page Overview** — page-level hero card with parent domain strip
- **N4 Cross-Page Comparison within Domain** — side-by-side page comparison view
- **N5 Page Lifecycle: Pause/Archive/Delete** — page state transitions with cost impact preview
- **N6 Usage & Metering Dashboard** — usage-based billing transparency layer

### Removed in v4
- Screen 11 (multi-step Add Tracked Page wizard) — merged into N1 30-second modal
- Screen 12 (Add Competitor flow) — merged into Domain Settings → Competitors tab
- Screen 13 (Edit Domain Configuration) — merged into Domain Settings → Configuration tab

### Module reorganization
- 9 module views split by scope: **4 domain-level + 5 page-level**
  - Domain-level (4): Brand SOV, Authority Profile, Site Audit, Domain Competitive Intel
  - Page-level (5): GEO Visibility, Citation Gaps, SERP Intelligence, Technical Health, Page Competitive Intel
- Sidebar gained **scope-aware nav groups**: DOMAIN (visible when domain selected) and PAGE (visible only when tracked page selected)

### Add Domain flow
- Replaced 4-step Add Domain Wizard (Screen 10 v3) with **single-step Add Domain form**
- Inline GSC connect accordion (OAuth-per-domain)
- Cost preview before submission

### Cost transparency layer
- Usage-based billing surfaced at every spending decision:
  1. Per-action cost preview (Add Domain, Add Tracked Page, Launch Audit, Bulk Import)
  2. Per-row cost in tables (Tracked Pages, Run History)
  3. Aggregate spend on Dashboard, Domain Overview, Settings → Usage
  4. Savings callouts when an action saves money
- Cost precision: 3 decimals per-call, 2 decimals monthly

### Viewer-Mode rules (codified)
9-rule transformation pattern for role gating:
1. Hidden vs Disabled — restricted items are HIDDEN entirely
2. Read affordances preserved
3. Notes: read-only
4. Costs: visible, not controllable
5. Exports: allowed
6. Deep-links: full within permitted surfaces
7. Settings: gone entirely
8. Page entity management: hidden
9. Usage & Metering: gone

### Scope indicator patterns
- Scope banner below top bar on every scoped screen
- Parent domain strip on page-scoped screens (universal page → domain pivot)
- Sidebar group state (DOMAIN active/grayed, PAGE visible/hidden)
- Route reflects scope: `/domains/[domain]/pages/[page]/[module]`

### Run system
- Run scope explicit at creation: workspace / domain-full / domain-only / specific pages
- Background indicator + module banners during runs — app stays usable
- First-ever audit gets celebratory variant

### Notifications
- Three scope tiers: Domain-Level / Page-Level / System
- Each notification has scope badge + deep-link destination
- Routing table documented in Screen 36

### Roles
- Three roles enforced client-side: Workspace Owner, Admin, Viewer
- Role pill in sidebar avatar (teal/slate/light-gray)
- Hidden-not-disabled gating throughout

### GSC integration
- Treated as a data platform (not engine)
- Google blue `#4285f4` at 80% opacity, always rendered below engine donuts
- OAuth-per-domain, read-only scope (`sc.readonly`)
- Surfaces in Dashboard, Settings, SERP Intelligence, Site Audit, Technical Health, Add Domain, Run History, Domain Overview

---

## v3.0 — April 2026 · Original 56-Screen Corpus

**Status:** Deprecated by v4.0.

- 18 v2 HTML screens + 38 Phase 1/2 prompts = 56 total
- Aggregate-root Domain model (Domain Detail contained all sub-pages)
- 5-engine taxonomy with conflated "Google AI" surface (later corrected in v4.5)
- Multi-step Add Tracked Page wizard (Screen 11)
- Separate Add Competitor (Screen 12) and Edit Domain Configuration (Screen 13) flows
- 4-step Add Domain Wizard (Screen 10 v3)
- No per-scope navigation in sidebar — single flat module list
- Fixed page count limits per Domain (later removed in v4)
- No usage-based billing transparency layer
- No formal Viewer-Mode rules — Viewers got disabled "ghost" features (later corrected in v4)

---

## Roadmap to v5 (anticipated late 2026 / early 2027)

These are tracked but not committed. The v4.5 surface abstraction is designed to absorb most of these as data changes, not code changes.

### Surface additions
- **Copilot (Microsoft)** — likely adds as the 7th surface in late 2026. GPT-4-powered, Bing-integrated. Category: chatbot.
- **Potential Anthropic search product** — if launched, adds as a chatbot or hybrid surface.
- **Potential Apple Intelligence search** — speculative; would add as a new category if walled-garden.

### Product expansions
- **Multi-workspace support** — Phase 3 SaaS spin-out. Currently single-tenant (Authority Solutions only). Requires workspace-scoped sidebar, billing UI per workspace, white-label theming.
- **API webhooks** — partner integrations (CRM, project management, BI dashboards). N6 Usage can include webhook configuration.
- **Per-surface optimization playbooks as product features** — auto-generated playbook PDFs per surface per page based on detected gaps. `docs/surface-playbooks.md` (v4.5) becomes the data source.

### Architecture
- The v4.5 surface abstraction (components iterate `surfaces[]` arrays) makes adding surface 7 a data change. Surface additions require: new `--engine-{id}` tokens, new `.surface-pill.is-{id}` rule, new SVG, new entry in `WORKSPACE_SURFACES` array. No component refactor.

---

## Change documentation conventions

- Every meaningful change ships with a CHANGELOG entry in the relevant version section.
- v4.5 phase completions are appended to the v4.5 Phase tracker table with completion dates.
- Breaking changes (renamed tokens, removed components, taxonomy shifts) are called out explicitly with the migration path.
- Token renames document both old and new names for at least one minor version cycle.
- New components reference their location in `ui_kits/geo_monitor/`.
- Screen-level changes link to the specific screen number.

When in doubt, add too much detail rather than too little — future-you and future-Claude will thank you.
