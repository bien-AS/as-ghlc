# Component inventory

60 exported components across 27 modules (constant maps and registries are exported too and not listed here). **Generated** from the kit by `tools/gen-components-md.mjs` — each line is the first sentence of that component's own
doc comment, so this file and the source cannot disagree.

Every component is imported from the barrel:

```ts
import { DataTable, KpiTile, AlertList } from "@/design";
```

---

## Primitives, pills & badges

### `components/ai-insights-card.tsx`

- **`AIInsightsSparkle`**
- **`AIInsightTile`**
- **`AIInsightsCard`** — the Insight Engine's surface ("the brain").

### `components/cost-preview.tsx`

- **`CostPreview`** — shown before ANY action that spends money: add domain, add tracked page, launch audit, bulk import, run scan.

### `components/data-table.tsx`

- **`DataTable`** — the most-reused component in the product.

### `components/kpi-tile.tsx`

- **`KpiTile`** — the two ways a single number gets shown.
- **`ScoreGauge`** — the two ways a single number gets shown.

### `components/pills.tsx`

- **`StatusPill`**
- **`SourceBadge`**
- **`RunStatePill`**
- **`RankPill`**
- **`SeverityDot`**
- **`RolePill`**
- **`ScopePill`**
- **`RunScopePill`**

### `components/popover.tsx`

- **`Popover`**
- **`CheckRow`**

### `components/primitives.tsx`

- **`Card`**
- **`CardHeader`**
- **`CardTitle`**
- **`CardFooter`**
- **`Eyebrow`**
- **`Button`**
- **`DeltaPill`**
- **`ScoreBadge`**
- **`Sparkline`**

### `components/sidebar.tsx`

- **`NavRow`**
- **`NavGroupLabel`**
- **`Sidebar`** — always-dark chrome, in BOTH themes.

### `components/strips.tsx`

- **`ScopeBanner`**
- **`ParentDomainStrip`**
- **`GSCSyncStrip`**

### `components/surface-badge.tsx`

- **`SurfaceIcon`**
- **`SurfaceBadge`**
- **`SurfaceDot`**

### `components/surface-matrix.tsx`

- **`SurfaceMatrixCell`**
- **`SurfaceMatrix`** — the "LLM knowledge matrix": entities down, the 6 AI surfaces across.

### `components/surface-selector.tsx`

- **`SurfaceSelectorCard`**
- **`SurfaceCategoryHeader`**
- **`SurfaceSelector`** — pick which AI surfaces a run covers.

### `components/topbar.tsx`

- **`AutoSaveIndicator`**
- **`LastSyncIndicator`**
- **`TopBar`** — TopBar / PageHeader.

---

## App shell

### `components/shell/command-palette.tsx`

- **`CommandPalette`** — the client switcher and global nav (Cmd-K / Ctrl-K).

### `components/shell/date-range-picker.tsx`

- **`DateRangePicker`** — the range control that sits in every TopBar action slot.

### `components/shell/notification-bell.tsx`

- **`NotificationBell`** — the alert feed in the app-shell chrome.

### `components/shell/theme-toggle.tsx`

- **`ThemeToggle`** — light / dark / system, as three real states.

---

## Charts & data viz

### `components/charts/bucket-area.tsx`

- **`BucketArea`** — how many tracked keywords sit in each rank band, over time.

### `components/charts/heat-grid.tsx`

- **`HeatGrid`** — the city × keyword rank matrix.

### `components/charts/presets.tsx`

- **`PositionLine`**
- **`DualAxisTraffic`**

### `components/charts/sov-bars.tsx`

- **`SovBars`** — competitor share of voice, as a horizontal bar list.

### `components/charts/time-series.tsx`

- **`TimeSeries`** — the base timeline, with the AlgoOverlay and SignalMarkers layers.

---

## Domain panels

### `components/domain/alert-list.tsx`

- **`AlertList`** — the anomaly / alert feed (S-15).

### `components/domain/audit-item-card.tsx`

- **`AuditItemCard`** — one row of the Baptist 16-point scorecard.

### `components/domain/empty-state.tsx`

- **`EmptyState`** — the generalised form of `data-table.tsx`'s `StateBlock`.
- **`PanelSkeleton`**
- **`NotMeasured`**

### `components/domain/movers-panel.tsx`

- **`MoversPanel`** — the biggest rank movements this cycle (S-03).

### `components/domain/roadblock-panel.tsx`

- **`RoadblockPanel`** — stalled work that needs a human (S-03 overview).

---

_Regenerate: `node design/tools/gen-components-md.mjs`_
