# Starting a new app on this design system

For a **second app**, install this package as a dependency. Do not copy `src/`
in — a copy forks the system on day one, and the fixes you make in one app never
reach the other. The whole point of the version number is that apps can be
behind it.

A working reference implementation of everything below is a **GitHub template**:

> **https://github.com/Authority-Solutions/vantage-next-starter** — click
> *Use this template*, or `gh repo create <org>/<new-app> --template
> Authority-Solutions/vantage-next-starter --private`

Start there rather than following this by hand. Read on for what each piece
does and why.

---

## 1. Install

```bash
npm i git+ssh://git@github.com/Authority-Solutions/vantage-design-system.git#v6.7.4
npm i class-variance-authority clsx tailwind-merge lucide-react recharts
npm i -D tailwindcss@^3.4 postcss autoprefixer
```

**The repo is private.** `git+ssh` needs your SSH key on your GitHub account
(`ssh -T git@github.com` should greet you by name). On CI, or on a machine
without a key, use a token instead:

```bash
npm i "git+https://${GITHUB_TOKEN}@github.com/Authority-Solutions/vantage-design-system.git#v6.7.4"
```

npm reports a missing-permission failure as a generic "repository not found",
so if the install 404s, check access before you check the URL.

Pin the **tag**, not a branch. An app should move to a new design-system
version deliberately, having read the changelog, not because someone pushed.

> Tailwind **3.x**. This system is not Tailwind 4 — v4 moves theme config into
> CSS and drops the JS `theme.extend` that every token in `tailwind.config.ts`
> is declared through.

---

## 2. Tailwind — use it as a preset

```ts
// tailwind.config.ts
import type { Config } from "tailwindcss";
import vantage from "@vantage/design-system/tailwind.config";

export default {
  presets: [vantage],
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    // REQUIRED. Tailwind only emits classes it can SEE, and the kit's classes
    // live inside node_modules. Omit this line and the app builds clean, boots
    // clean, and renders completely unstyled.
    "./node_modules/@vantage/design-system/src/**/*.{ts,tsx}",
  ],
} satisfies Config;
```

`presets` brings the whole token theme — colours, the type scale, radii,
shadows, motion. Content globs stay yours, because only your app knows where
its own files are.

**Do not hand-roll the theme.** The config carries a `hexToken` helper that
compiles opacity modifiers through `color-mix()`. Without it `bg-teal/10` and
every other modifier compiles to *nothing* — no error, no style.

---

## 3. Stylesheet — import once

```ts
// app/layout.tsx
import "@vantage/design-system/styles";
```

That pulls both token layers plus Tailwind's three directives. Do **not** also
import `tokens/shadcn.css`: it is the same layer as `tokens/tokens.css`, kept
separately for apps using shadcn/ui *without* this kit. Importing both defines
every `--sc-*` twice and the load order decides which wins.

---

## 4. The pre-paint theme bootstrap — do not skip this

This system is **dark-first**: `:root` *is* the dark palette and `.light`
derives from it. There is no `@media (prefers-color-scheme)` block anywhere in
the token layer. Two consequences:

- An un-themed render is **dark**, so there is no white flash — but a
  light-mode operator gets a dark flash before React mounts.
- Worse: `ThemeToggle` defaults to `"system"`, and *removing* both classes does
  not mean "follow the OS" here — it means dark, unconditionally. A light-mode
  operator on "System" is stranded in dark until this script runs.

`ThemeToggle` reconciles **after** mount. It cannot fix the first paint, because
React has not mounted when the document paints. The host app must ship this:

```tsx
// app/layout.tsx — inside <head>, before anything renders
<script
  dangerouslySetInnerHTML={{
    __html: `(function(){try{
      var c = localStorage.getItem('as-vantage-theme') || 'system';
      var t = c === 'system'
        ? (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark')
        : c;
      document.documentElement.className = t;
      document.documentElement.style.colorScheme = t;
    }catch(e){}})();`,
  }}
/>
```

The key is `as-vantage-theme` — exported as `THEME_STORAGE_KEY`. Rename it in
one place and the toggle and the bootstrap stop agreeing, which shows up as a
flash on every load and nowhere else.

Wrap it in `try/catch`. `localStorage` **throws** in private windows and
embedded previews, and a theme preference is never worth crashing a page for.

---

## 5. Charts are client-only

They measure SVG at runtime:

```tsx
const PositionLine = dynamic(
  () => import("@vantage/design-system/charts/presets").then((m) => m.PositionLine),
  { ssr: false },
);
```

Every interactive module in the kit already carries `"use client"`, so you can
import them straight from a Server Component — the boundary is the kit's
problem, not yours. Only the charts need the extra `ssr: false`.

---

## 5b. Function props cannot cross the Server → Client boundary

This is the one that will bite first, and it fails the **build**, not the
render. Several kit APIs take functions — `Column.cell`, `Column.value`,
`rowId`, `onRowClick`, the `format` a chart preset passes internally. React
cannot serialize a function, so a Server Component that builds them and hands
them to a client component dies with:

> Functions cannot be passed directly to Client Components

The fix is not `"use client"` on the whole page. Put the **data** in the server
component and the **function-bearing config** behind the boundary:

```tsx
// app/page.tsx — Server Component. Owns data. Everything passed is serializable.
const ROWS: KeywordRow[] = [ /* plain objects */ ];
export default function Page() { return <KeywordTable rows={ROWS} />; }
```

```tsx
// components/keyword-table.tsx
"use client";
export function KeywordTable({ rows }: { rows: KeywordRow[] }) {
  const columns: Column<KeywordRow>[] = [       // functions live HERE
    { id: "keyword", header: "Keyword", cell: (r) => r.keyword, value: (r) => r.keyword },
  ];
  return <DataTable rows={rows} columns={columns} rowId={(r) => r.keyword} />;
}
```

`ssr: false` is also only legal inside a Client Component, so the same split
covers the charts. `starters/vantage-next-starter/components/` is exactly this,
in two files.

---

## 6. Inherit the guards

Two of this system's bugs were invisible ones — a class that compiled to
nothing, and a status dot with no background. Neither showed an error; both
rendered. `deadclass` is what caught them, and it is worth running against
**your** components too, not just the kit's:

```bash
npx tailwindcss -i app/globals.css -o .next/audit.css --config tailwind.config.ts
node node_modules/@vantage/design-system/tools/deadclass.mjs
```

Wire it into CI. A colour utility that resolves to no rule is the failure mode
this system produces most often, and it is completely silent.

---

## 7. Before you write a component

Read **[RULES.md](RULES.md)**. Every rule in it is there because breaking it
already shipped a bug that rendered and was wrong. The four that bite hardest:

1. **`:root` is DARK.** Style through tokens and a component is correct in both
   themes with no `dark:` variants at all.
2. **`1rem` is 14px.** `html` sets a 14px font-size, rescaling every rem —
   Tailwind's default spacing scale included (`p-4` is 14px, not 16px). Size
   anything that must hold prose in **px**.
3. **`*-ink` is the text colour on a `*-soft` fill** — never the base colour,
   which measures 2.8–3.9:1 on its own tint.
4. **A teal FILL lightens on interaction; teal TEXT darkens.** And when a state
   change would push a fill toward a fixed border colour, move the border.

---

## Upgrading later

```bash
npm i git+ssh://git@github.com/Authority-Solutions/vantage-design-system.git#v6.8.0
```

Read `docs/CHANGELOG.md` first — it records what changed *and why*, including
the things that were built and then removed for failing measurement. Then run
your own `deadclass` pass: a renamed or withdrawn token is exactly the kind of
change that compiles clean and renders wrong.
