# Vantage Design System

The Authority Solutions design system for **Vantage**, packaged for the build
team. Tokens, a TypeScript component library, prebuilt demos you can open with
no toolchain, and the verification tools we use ourselves.

**Version 6.7.6** · dark-first · Tailwind 3.4 + React 18 + TypeScript (strict)

---

## Look at it first — no install needed

```bash
open demo/index.html
```

Every file in `demo/` is prebuilt and self-contained. Open any of them straight
off disk:

| File | What it shows |
|---|---|
| `demo/index.html` | The component kit — every primitive, pill, badge and card |
| `demo/table.html` | `DataTable` with all four data states |
| `demo/charts.html` | `TimeSeries` + the algorithm-update overlay |
| `demo/heatgrid.html` | City × keyword rank matrix |
| `demo/viz.html` | `SovBars`, `BucketArea`, `PositionLine`, `KpiTile`, `ScoreGauge` |
| `demo/shell.html` | Command palette, date range, notifications, overview panels |
| `demo/audit.html` | **The contrast harness — press Run audit** |

Or serve the lot: `node tools/serve.mjs` → http://localhost:4321

---

## Starting a NEW app on this system

Read **[docs/SETUP.md](docs/SETUP.md)** — install as a git dependency, the
Tailwind preset wiring, the pre-paint theme bootstrap, and the guards. A
runnable reference app lives in `starters/vantage-next-starter/`.

The instructions below are the short form, for adding the kit to an app that
already exists.

---

## Install into the app

```bash
npm i class-variance-authority clsx tailwind-merge lucide-react recharts
```

Copy `src/` into your app (we suggest `src/design/`), then point Tailwind at
this config and import the stylesheet **once** at the app root:

```ts
// tailwind.config.ts — extend from ours, or use it directly
export { default } from "./src/design/tailwind.config";
```

```ts
// app/layout.tsx  (or your root)
import "@/design/styles/kit.css";
```

`kit.css` pulls in both token layers and Tailwind's three directives. Do **not**
also import `tokens/shadcn.css` — it is the same layer as `tokens/tokens.css`,
kept separately for apps that use shadcn/ui *without* this kit. Importing both
just defines every `--sc-*` twice.

Charts are SVG-measured, so import them client-side:

```ts
const TimeSeries = dynamic(() => import("@/design/components/charts/time-series"), { ssr: false });
```

---

## What's in the box

```
tokens/       colors_and_type.css   design-system layer — hex, unprefixed
              tokens.css            Tailwind/shadcn layer — HSL channels, --sc- prefixed
              shadcn.css            standalone shadcn drop-in (alternative to tokens.css)
              design_tokens.json    machine-readable mirror, both themes per token
src/          the component library — components/, lib/, styles/kit.css
demo/         prebuilt, openable from disk
docs/         RULES.md · COMPONENTS.md · BRAND_MAPPING.md · CHANGELOG.md
tools/        csscheck.mjs (parse every stylesheet) · serve.mjs (local server)
assets/       AS logos, AI-engine marks
```

---

## Before you write a line of code

Read **[docs/RULES.md](docs/RULES.md)**. It is short, and every rule in it is
there because breaking it has already caused a silent bug — the kind that
renders, ships, and is wrong. The three that bite hardest:

1. **`:root` is DARK.** An un-themed render is dark; `.light` derives from it.
   Style through tokens and a component is correct in both themes with no
   `dark:` variants at all.
2. **`1rem` is 14px, not 16px.** `html` sets a 14px font-size, which rescales
   every rem in the system — Tailwind's whole default spacing scale included
   (`p-4` is 14px). Size anything that must hold prose in **px**.
3. **`*-ink` is the text colour on a `*-soft` fill** — never the base colour,
   which measures 2.8–3.9:1 on its own tint. `text-teal-ink` on `bg-teal-soft`.

---

## Verify it yourself

The contrast audit needs **nothing installed** — it is a page:

```bash
open demo/audit.html         # then press "Run audit"
```

The stylesheet parser needs the dev dependencies (`postcss`):

```bash
npm install && node tools/csscheck.mjs
```

The audit cold-boots all six demo pages in both themes and measures the real
alpha-composited contrast of every rendered text node.

**Current measured state: 0 of 1836 text nodes below WCAG AA.** Minimum ratio
4.51:1. No horizontal page overflow at 1440 / 1280 / 1024 / 900 / 768.

Cold boot is the method, not a detail: toggling the theme and measuring in the
same tick reads mid-transition values and reports failures that are not real.

---

## Keeping in sync

This bundle is **generated**, not hand-assembled. It is rebuilt from the live
design system with:

```bash
npm --prefix design run build && node design/tools/package-ds.mjs
```

If you have been handed a copy and want to be sure it is current, check
`docs/CHANGELOG.md` against the version at the top of this file. Ask before
editing files here directly — changes belong upstream in `design/`, or they are
lost the next time the bundle is regenerated.
